# Checklist uji di perangkat (belum dijalankan — wajib sebelum dibagikan luas)

Perangkat utama: Redmi Note 12 Pro 5G. Bila ada, uji juga satu HP Android 10–12.

- [ ] Instal APK rilis; ikon GP tampil benar (bentuk bulat/kotak).
- [ ] Android 15: konten tidak tertutup status bar & navigation bar; gesture back berfungsi.
- [ ] Beranda: baterai, suhu, thermal, RAM, jaringan terisi; "LIVE" memperbarui tiap 30 dtk tanpa lompat scroll.
- [ ] Banner eFootball & Monster Hunter tampil tinggi ±90dp, tidak membesar.
- [ ] Tombol PLAY membuka eFootball (jp.konami.pesam) dan Monster Hunter Outlanders.
- [ ] Game belum terpasang → muncul GET dan membuka Play Store.
- [ ] Games → "Pilih dari aplikasi terpasang" → game tampil, bisa dibuka, bisa dihapus.
- [ ] Mulai sesi → tutup app → buka lagi → durasi berjalan; selesaikan → muncul di riwayat.
- [ ] Batalkan sesi tidak menambah riwayat.
- [ ] Update dari v0.4 (tanda tangan sama): riwayat lama muncul sebagai "Riwayat lama".
- [ ] Bagikan riwayat membuka share sheet; hapus riwayat meminta konfirmasi.
- [ ] Tombol Back: Games/Sessions/Tools → Beranda → keluar.
- [ ] Putar layar: tidak crash, layout tetap terbaca.
- [ ] TalkBack: navigasi bawah dan logo terbaca.

## Tahap 1 (v1.1.0)
- [ ] Tools → Bersihkan RAM Sekarang: toast RAM sebelum→sesudah muncul, tidak crash.
- [ ] Game terpilih & GamePulse tidak ikut dihentikan.
- [ ] Jangan Ganggu: tanpa izin → ada tombol izin; setelah izin, sesi mulai = DND prioritas, selesai/batal = kembali ke semula.
- [ ] Kesiapan Main: baris Hemat Daya berubah kuning saat hemat daya aktif.
- [ ] Tombol Game Turbo: terbuka di Redmi, atau toast fallback (catat hasilnya).
- [ ] Ukur: RAM tersedia & suhu sebelum vs sesudah optimasi (catat manual 3 kali).

## Shizuku (v1.1.0)
- [ ] Build berhasil (dependensi Shizuku terunduh, R8 tidak error).
- [ ] Tools: status Shizuku benar; tombol izin memunculkan dialog Shizuku.
- [ ] Hentikan paksa: app latar tertutup, game & GamePulse tidak.
- [ ] Resolusi 75%: layar mengecil saat sesi; Reset dan akhir sesi mengembalikan; tutup paksa GamePulse lalu buka lagi memulihkan.
- [ ] Game Mode: catat keluaran toast di Redmi (sintaks bisa gagal).
- [ ] Jika toast "ERROR: NoSuchMethodException": refleksi newProcess gagal -> perlu UserService.

## Boost Sesi (v1.2.0)
- [ ] Build berhasil.
- [ ] Mulai & Buka Game: toast "Refresh rate dikunci N Hz" (N = maksimum layar). Cek Opsi Pengembang → "Tampilkan refresh rate" selama main.
- [ ] Selesaikan/batalkan sesi: refresh rate kembali ke pengaturan semula (Pengaturan → Layar).
- [ ] Tutup paksa GamePulse di tengah sesi, buka lagi, selesaikan: semua kembali normal (tombol Pulihkan).
- [ ] Whitelist: `cmd deviceidle whitelist` memuat game selama sesi, hilang setelahnya (kecuali sudah ada sebelumnya).
- [ ] Bandingkan rasa/gerak: sesi 10 menit dengan dan tanpa opsi; catat suhu puncak & baterai.
