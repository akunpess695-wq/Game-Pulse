# Changelog

## 1.8.0 — Fase 2: pemantauan jujur & ambang suhu (BELUM dikompilasi; hanya tinjauan statis + cek keseimbangan kurung)
- Baru: model sumber data `Reading` (TERUKUR / PERKIRAAN / TIDAK TERSEDIA + alasan) dan `Readings`. Kartu "PEMANTAUAN" di tab Sesi menampilkan suhu baterai, status thermal Android, indeks thermal (perkiraan), FPS game, refresh rate aktif, RAM. Bila FPS tidak bisa diukur, alasannya dijelaskan (Shizuku belum jalan / belum diizinkan / belum ada sesi / menunggu frame) — tidak ada angka karangan.
- Baru: `Thresholds` — ambang suhu hangat (38/40/42 °C) dan panas (42/43/45/47 °C) bisa diatur di Tools → Preferensi; ambang panas selalu > hangat. Dipakai oleh kartu status, Kesiapan Main, peringatan, dan ThermalService. Default tetap 40/43 °C.
- Baru: indeks thermal Android (`getThermalHeadroom`) tersedia dari `DeviceInfo.headroom`; ambang 0,8/0,95 dipindah ke konstanta `Thresholds.HEADROOM_*` (masih perkiraan awal, belum dikalibrasi).
- Baru: tanda "⚠ Pemantauan latar sempat terputus" di sesi aktif, riwayat, dan ekspor bila ada celah >3 menit.
- Baru: peringatan di Ringkasan bila berkas riwayat sebelumnya rusak dan salinan mentahnya disimpan.
- Warna suhu di kartu status mengikuti ambang pengguna. Tanpa izin baru, tanpa perubahan manifest.
- Batasan: suhu tetap suhu BATERAI (bukan CPU/GPU); FPS tetap hanya via Shizuku dan masih belum diverifikasi di HyperOS.

## 1.7.0 — Fase 1: stabilitas & kejujuran (BELUM dikompilasi; hanya tinjauan statis + cek keseimbangan kurung)
Tidak ada perubahan tampilan. Hanya perbaikan perilaku:
- Perbaiki: `ShizukuHelper.exec` kini punya batas waktu 8 dtk (sebelumnya `waitFor()` tanpa batas bisa membuat pengukur FPS macet selamanya). Kegagalan dikembalikan sebagai teks berawalan `ERROR`.
- Perbaiki: pesan "berhasil" palsu. Refresh rate, resolusi, whitelist Doze kini DIBACA ULANG setelah ditulis; pesan menyatakan "terverifikasi" atau "TIDAK terverifikasi". Hentikan paksa hanya melaporkan perintah terkirim/gagal (Android tidak memberi tanda berhasil).
- Perbaiki: pemulihan (`restoreAll`) hanya menghapus penanda bila nilai asli terbukti kembali; bila tidak, penanda tetap ada dan tombol Pulihkan bisa dicoba lagi. Hasil ditampilkan jujur.
- Perbaiki: bila sesi berakhir di luar alur normal, ThermalService memulihkan perubahan Shizuku sebelum berhenti.
- Perbaiki: riwayat rusak tidak lagi menimpa riwayat; salinan mentah disimpan di pref `history_corrupt` dan tidak lagi jatuh ke migrasi lama.
- Baru: deteksi celah pemantauan (detak layanan tiap 15 dtk; jeda >3 mnt menandai sesi `gap`). Belum ditampilkan di UI (Fase 2).
- Perbaiki: pemindaian paket + `killBackgroundProcesses` dipindah dari thread UI ke thread latar.
- Perbaiki: `getThermalHeadroom` dipanggil sekali per siklus (sebelumnya dua kali).
- Ditunda (tidak bisa diverifikasi tanpa kompilator): migrasi `Shizuku.newProcess` (refleksi) ke UserService/AIDL; ambang thermal yang bisa diatur (Fase 2).

## 1.6.0 — Tampilan "Carbon Redline" (belum dikompilasi/diuji)
- Baru: Premium.java (token desain: warna, kartu, tombol, tipografi, warna status suhu/FPS). Hanya tampilan, tanpa logika.
- MainActivity memakai token itu: palet latar #0B0D12 / kartu #151922 / aksen #E5383B; kartu sudut 16dp tepi tipis 1dp tanpa bayangan; tombol utama gradasi merah, tombol lain hanya garis tepi.
- Kartu status perangkat: angka besar tabular (auto-kecil bila sempit), suhu berwarna hijau/kuning/merah.
- Banner Home diberi gradasi gelap di bawah.

## 1.5.0 — Dukungan tablet 144 Hz (Mi Pad 6S Pro) (belum dikompilasi/diuji)
- Baru: DisplayProfile — deteksi otomatis refresh rate yang didukung panel (`Display.getSupportedModes`), jenis HP/tablet. Kunci Hz otomatis = maksimum panel (HP 120, tablet 144), tanpa pengaturan manual.
- Baru: tombol "Target refresh" (Otomatis → tiap Hz yang tersedia) di Mode Shizuku; berguna agar kelipatan frame rata (game 60/120 FPS di 120 Hz, 72/144 FPS di 144 Hz).
- Kunci Hz kini juga menyetel `secure miui_refresh_rate` HANYA bila kunci itu sudah ada (HyperOS), nilai lama disimpan & dipulihkan. BELUM TERVERIFIKASI.
- FpsMeter: histogram 0,1 ms (akurat di 120/144 Hz) dan deteksi celah buffer SurfaceFlinger (±128 frame) agar frame hilang tak dihitung sebagai "stutter" palsu.
- Tablet: lebar isi dibatasi 680dp dan di tengah; layar dihitung ulang saat putar/split-screen.
- Perbaiki teks usang "tidak mengukur FPS". Tanpa izin baru.

## 1.4.0 — Tahap 3a: pengukur FPS via Shizuku (belum dikompilasi/diuji)
- Baru: FpsMeter membaca timestamp frame game dari SurfaceFlinger (`dumpsys SurfaceFlinger --latency`), sampel tiap 5 dtk selama sesi. Menghasilkan FPS rata-rata, 1% low, dan jitter (simpangan waktu-antar-frame); tampil di notifikasi, layar Sesi aktif, dan riwayat/bagikan.
- Perkiraan berbasis sampel (bukan kontinu); bisa berbeda dari Scene/overlay game. Status diagnosis tampil di notifikasi bila gagal (layar game tak ditemukan, Shizuku gagal).
- Toggle baru di Mode Shizuku: "Ukur FPS selama sesi" (default aktif). Tanpa izin baru.

## 1.3.0 — Tahap 2: pemantau suhu di latar (belum dikompilasi/diuji)
- Baru: ThermalService (foreground service, tipe specialUse) aktif hanya selama sesi: memperbarui suhu puncak sungguhan walau GamePulse tidak dibuka, notifikasi status (game, durasi, suhu, thermal, indeks thermal API 30+), dan peringatan "HP mulai panas" (jeda minimal 3 menit).
- Baru: toggle "Pantau suhu di latar" (default aktif) + tombol izin notifikasi (Android 13+).
- Baru (opsional, default mati, perlu Shizuku): turunkan resolusi 75% otomatis sekali saat panas; dipulihkan saat sesi selesai/dibatalkan.
- Izin baru: FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE, POST_NOTIFICATIONS.
- Layanan berhenti sendiri bila sesi tidak aktif; dilanjutkan bila app dibuka lagi di tengah sesi.

## 1.2.0 — Boost Sesi via Shizuku (belum dikompilasi/diuji)
- Baru: kunci refresh rate layar ke maksimum yang didukung selama sesi (settings system peak/min_refresh_rate). Nilai lama disimpan dan dikembalikan saat sesi selesai/dibatalkan/app dibuka ulang. Pada HyperOS pengaturan bawaan bisa menimpa; hasil harus dicek di HP.
- Baru: cegah game dibatasi Doze/standby (cmd deviceidle whitelist + am set-standby-bucket active). Whitelist hanya dicabut bila GamePulse yang menambahkannya.
- Baru: tombol "Pulihkan pengaturan layar & sistem" memulihkan resolusi, refresh rate, dan whitelist sekaligus.
- Dua opsi baru di Mode Shizuku, default aktif, bisa dimatikan.

## 1.1.0 — Tahap 1 + 4a optimasi (belum dikompilasi/diuji)
- Baru: Mode Shizuku opsional — hentikan paksa app latar (am force-stop), turunkan resolusi 75% selama sesi (wm size, otomatis reset + pemulihan saat app dibuka ulang), Game Mode Performance eksperimental (keluaran asli ditampilkan).
- Dependensi baru: dev.rikka.shizuku api/provider 13.1.5 (Apache-2.0). Shizuku.newProcess dipanggil lewat refleksi.
- Baru: Tools → "Optimasi Pra-Main": Bersihkan RAM (killBackgroundProcesses, hanya app non-sistem, tanpa GamePulse & game terpilih) + laporan RAM sebelum→sesudah.
- Baru: opsi otomatis saat "Mulai & Buka Game"; Jangan Ganggu mode prioritas selama sesi (izin pengguna), dikembalikan saat sesi selesai/dibatalkan.
- Baru: Kesiapan Main memeriksa Hemat Daya; tombol Game Turbo Xiaomi (komponen belum terverifikasi, ada fallback).
- Izin baru: KILL_BACKGROUND_PROCESSES, ACCESS_NOTIFICATION_POLICY.

## 1.0.0 — Rilis penuh
### Tampilan
- Kartu game ringkas dengan ikon asli aplikasi, status titik, dan aksen terpilih.
- Navigasi bawah memakai ikon vektor.
- Palet lebih tenang: merah hanya untuk aksi utama.

### Baru
- Ikon adaptif (Android 8+) dengan logo GP.
- Daftar game fleksibel (maks 12 pilihan): deteksi game otomatis atau pilih manual dari aplikasi terpasang; hapus per game.
- Profil per jenis game (MOBA, strategi, sepak bola, Monster Hunter, battle royale, umum) dengan tips.
- Kartu "Kesiapan Main": baterai, suhu, RAM, jaringan.
- Tombol Info Aplikasi per game (baterai/izin).
- Status "TERPASANG / BELUM TERPASANG" per game; tombol GET membuka Play Store bila belum terpasang.
- Peringatan panas & baterai rendah di Beranda (dari status thermal Android dan suhu baterai).
- Indikator pengisian daya, suhu tertinggi yang terpantau selama sesi, dan tombol batalkan sesi.
- Ringkasan sesi: total sesi, total waktu, rata-rata pemakaian baterai per jam.
- Riwayat terstruktur (maks 100 sesi), bagikan sebagai teks, hapus dengan konfirmasi.
- Pengaturan: refresh otomatis dapat dimatikan.
- Tombol Back kembali ke Beranda sebelum keluar.

### Diperbaiki
- Monster Hunter Outlanders kini ditemukan walau namanya di launcher "MHOutlanders" (dicocokkan tanpa spasi/simbol; "MHGU" tidak ikut cocok).
- Banner game kini tinggi tetap (sebelumnya mengikuti ukuran asli gambar sehingga terlalu tinggi).
- Tampilan tidak lagi tertimpa status bar / navigation bar pada Android 15 (edge-to-edge, targetSdk 35).
- Riwayat tidak lagi berupa satu teks yang membesar tanpa batas.
- Target sentuh tombol minimal 48dp; deskripsi aksesibilitas untuk logo dan navigasi.
- Pembuka pengaturan notifikasi menyertakan paket aplikasi agar langsung ke halaman yang benar.
- "Mulai & Buka Game" tidak memulai sesi bila game tidak ditemukan.

### Rilis & build
- Build release dengan R8 (minify + shrink resources).
- Penandatanganan lewat secrets GitHub (`GP_KEYSTORE_*`); workflow pembuat kunci disertakan.
- Output: APK rilis + AAB (Play Store).
- Riwayat v0.3/v0.4 dimigrasikan otomatis (namespace preferensi sama).

## 0.4.0
Status perangkat nyata, checklist gaming, tombol Mulai Sesi & Buka Game.
