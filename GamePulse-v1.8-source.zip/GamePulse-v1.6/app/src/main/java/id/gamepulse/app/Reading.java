package id.gamepulse.app;

/**
 * Satu pembacaan pemantauan beserta sumbernya. Tujuannya: pengguna selalu tahu apakah angka itu
 * TERUKUR (dibaca langsung dari API Android), PERKIRAAN (sampel/prakiraan), atau TIDAK TERSEDIA
 * (tidak ada angka; alasan dijelaskan). Tidak pernah ada angka karangan.
 */
final class Reading {
    enum Kind { MEASURED, ESTIMATED, UNAVAILABLE }

    final Kind kind;
    final String value;
    final String note;

    private Reading(Kind kind, String value, String note) {
        this.kind = kind;
        this.value = value;
        this.note = note == null ? "" : note;
    }

    static Reading measured(String value, String note) { return new Reading(Kind.MEASURED, value, note); }
    static Reading estimated(String value, String note) { return new Reading(Kind.ESTIMATED, value, note); }
    static Reading unavailable(String reason) { return new Reading(Kind.UNAVAILABLE, "N/A", reason); }

    String tag() {
        switch (kind) {
            case MEASURED: return "TERUKUR";
            case ESTIMATED: return "PERKIRAAN";
            default: return "TIDAK TERSEDIA";
        }
    }
}
