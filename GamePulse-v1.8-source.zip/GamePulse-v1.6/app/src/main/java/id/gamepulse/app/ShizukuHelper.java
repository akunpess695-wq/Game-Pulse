package id.gamepulse.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import rikka.shizuku.Shizuku;

/** Perintah setingkat ADB lewat Shizuku (opsional, tanpa root). Semua pemanggilan dibungkus agar tidak membuat app crash. */
final class ShizukuHelper {
    private ShizukuHelper() {}

    static final int REQ = 4101;
    private static final String K_RES = "res_changed";

    static boolean running() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    static boolean granted() {
        try { return running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    static void requestPermission() {
        try { Shizuku.requestPermission(REQ); } catch (Throwable ignored) { }
    }

    static final long EXEC_TIMEOUT_MS = 8000L;

    /** True bila hasil exec() adalah kegagalan eksekusi (bukan keluaran perintah). */
    static boolean isError(String s) { return s != null && s.startsWith("ERROR"); }

    /**
     * Jalankan perintah shell lewat Shizuku (BLOKIR: panggil dari thread latar). Mengembalikan keluaran gabungan,
     * atau teks berawalan "ERROR" bila gagal/timeout (8 dtk) agar thread pemanggil tidak pernah menggantung.
     */
    static String exec(String cmd) {
        Process p = null;
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null});
            final Process proc = p;
            final StringBuilder sb = new StringBuilder();
            Thread reader = new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()))) {
                    String line;
                    while ((line = r.readLine()) != null) { synchronized (sb) { sb.append(line).append('\n'); } }
                } catch (java.io.IOException ignored) { /* proses ditutup */ }
            }, "gp-exec");
            reader.setDaemon(true);
            reader.start();
            reader.join(EXEC_TIMEOUT_MS);
            if (reader.isAlive()) {
                proc.destroy();
                return "ERROR: timeout";
            }
            proc.waitFor(2, java.util.concurrent.TimeUnit.SECONDS);
            synchronized (sb) { return sb.toString().trim(); }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (p != null) p.destroy();
            return "ERROR: interrupted";
        } catch (Throwable t) {
            if (p != null) { try { p.destroy(); } catch (Throwable ignored) { } }
            Throwable c = (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) ? t.getCause() : t;
            return "ERROR: " + c.getClass().getSimpleName();
        }
    }

    private static boolean settingValue(String v) { return v != null && v.matches("null|[0-9]+(\\.[0-9]+)?"); }

    private static boolean sameHz(String v, int hz) {
        try { return Math.abs(Float.parseFloat(v.trim()) - hz) < 0.5f; } catch (Exception e) { return false; }
    }

    /** Kirim perintah hentikan paksa. Android tidak memberi tanda berhasil, jadi yang dilaporkan hanya perintah terkirim/gagal. */
    static String forceStop(List<String> pkgs) {
        int sent = 0, fail = 0;
        for (String p : pkgs) {
            if (!p.matches("[A-Za-z0-9._]+")) continue;
            if (isError(exec("am force-stop " + p))) fail++; else sent++;
        }
        return "Perintah hentikan paksa dikirim ke " + sent + " aplikasi" + (fail > 0 ? " (" + fail + " gagal)" : "") + ".";
    }

    /** Turunkan resolusi ke persen tertentu dengan rasio tetap, lalu baca ulang untuk memverifikasi. */
    static String lowerResolution(SharedPreferences prefs, int percent) {
        String out = exec("wm size");
        Matcher m = Pattern.compile("Physical size:\\s*(\\d+)x(\\d+)").matcher(out);
        if (!m.find()) return "Gagal membaca ukuran layar: " + out;
        int w = even(Integer.parseInt(m.group(1)) * percent / 100);
        int h = even(Integer.parseInt(m.group(2)) * percent / 100);
        prefs.edit().putBoolean(K_RES, true).apply(); // tandai dulu agar bisa dipulihkan walau app tertutup
        String r = exec("wm size " + w + "x" + h);
        Matcher o = Pattern.compile("Override size:\\s*(\\d+)x(\\d+)").matcher(exec("wm size"));
        if (o.find() && Integer.parseInt(o.group(1)) == w && Integer.parseInt(o.group(2)) == h) return "Resolusi diubah ke " + w + "x" + h + " (terverifikasi).";
        return "Resolusi TIDAK terverifikasi berubah" + (r.isEmpty() ? "." : ": " + r);
    }

    /** Reset resolusi; penanda dihapus hanya bila override benar-benar hilang. Mengembalikan true bila bersih. */
    static boolean resetResolution(SharedPreferences prefs) {
        exec("wm size reset");
        String after = exec("wm size");
        if (isError(after) || after.contains("Override size")) return false;
        prefs.edit().remove(K_RES).apply();
        return true;
    }

    private static int even(int v) { return v - (v % 2); }

    static boolean resolutionChanged(SharedPreferences prefs) {
        return prefs.getBoolean(K_RES, false);
    }

    /** Eksperimental: sintaks berbeda antar versi Android; keluaran asli ditampilkan agar bisa diperiksa. */
    static String gameModePerformance(String pkg) {
        String a = exec("cmd game set --mode performance --user 0 " + pkg);
        if (a.isEmpty() || !a.toLowerCase().contains("error") && !a.toLowerCase().contains("unknown")) return a.isEmpty() ? "OK (tanpa keluaran)" : a;
        return exec("cmd game mode performance " + pkg);
    }

    private static final String K_HZ = "hz_prev";
    private static final String K_IDLE = "idle_pkg";

    private static final String MIUI_KEY = "miui_refresh_rate";

    /** Set pengaturan refresh rate (min & puncak, plus kunci Xiaomi bila ada) ke hz; nilai lama disimpan untuk dipulihkan. */
    static String lockRefreshRate(SharedPreferences prefs, int hz) {
        if (hz < 30 || hz > 240) return "Refresh rate tidak valid";
        if (!prefs.contains(K_HZ)) {
            String pk = exec("settings get system peak_refresh_rate");
            String mn = exec("settings get system min_refresh_rate");
            String mi = exec("settings get secure " + MIUI_KEY);
            if (!settingValue(pk) || !settingValue(mn)) return "Gagal membaca pengaturan refresh rate saat ini; tidak ada yang diubah.";
            if (!mi.matches("[0-9]+(\\.[0-9]+)?")) mi = "-"; // kunci tidak ada: jangan disentuh
            prefs.edit().putString(K_HZ, pk + "|" + mn + "|" + mi).apply(); // simpan dulu agar bisa dipulihkan walau app tertutup
        }
        exec("settings put system peak_refresh_rate " + hz);
        exec("settings put system min_refresh_rate " + hz);
        String saved = prefs.getString(K_HZ, "");
        if (saved.split("\\|", -1).length > 2 && !saved.endsWith("|-")) exec("settings put secure " + MIUI_KEY + " " + hz);
        String rp = exec("settings get system peak_refresh_rate"), rm = exec("settings get system min_refresh_rate");
        if (sameHz(rp, hz) && sameHz(rm, hz)) return "Pengaturan refresh rate diset ke " + hz + " Hz (sistem bisa menimpa; cek Hz aktif).";
        return "Pengaturan refresh rate TIDAK terverifikasi (terbaca peak=" + rp + ", min=" + rm + ").";
    }

    /** Kembalikan refresh rate. Penanda dihapus hanya bila semua nilai terbukti kembali. */
    static boolean restoreRefreshRate(SharedPreferences prefs) {
        String s = prefs.getString(K_HZ, null);
        if (s == null) return true;
        String[] v = s.split("\\|", -1);
        boolean ok = putOrDelete("system", "peak_refresh_rate", v.length > 0 ? v[0] : "");
        ok &= putOrDelete("system", "min_refresh_rate", v.length > 1 ? v[1] : "");
        if (v.length > 2 && !v[2].equals("-")) ok &= putOrDelete("secure", MIUI_KEY, v[2]);
        if (ok) prefs.edit().remove(K_HZ).apply();
        return ok;
    }

    /** Tulis nilai (atau hapus bila asli kosong/"null"), lalu baca ulang. True bila hasil sesuai. */
    private static boolean putOrDelete(String ns, String key, String val) {
        boolean numeric = val.matches("[0-9]+(\\.[0-9]+)?");
        exec(numeric ? "settings put " + ns + " " + key + " " + val : "settings delete " + ns + " " + key);
        String now = exec("settings get " + ns + " " + key);
        if (isError(now)) return false;
        if (!numeric) return now.equals("null");
        try { return Math.abs(Float.parseFloat(now.trim()) - Float.parseFloat(val)) < 0.01f; } catch (Exception e) { return false; }
    }

    /** Cegah game dibatasi Doze/standby: whitelist hemat daya + bucket aktif. Hanya dicatat bila kita yang menambahkan. */
    static String boostApp(SharedPreferences prefs, String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z0-9._]+")) return "Paket game tidak valid; Doze tidak diubah.";
        String cur = exec("cmd deviceidle whitelist");
        if (isError(cur)) return "Gagal membaca whitelist Doze: " + cur;
        if (!cur.contains("," + pkg + ",")) {
            prefs.edit().putString(K_IDLE, pkg).apply(); // catat dulu agar bisa dipulihkan
            exec("cmd deviceidle whitelist +" + pkg);
        }
        boolean wl = exec("cmd deviceidle whitelist").contains("," + pkg + ",");
        exec("am set-standby-bucket " + pkg + " active");
        return wl ? "Game masuk whitelist Doze (terverifikasi)." : "Whitelist Doze TIDAK terverifikasi.";
    }

    /** Cabut whitelist yang kita tambahkan. True bila bersih. */
    static boolean unboostApp(SharedPreferences prefs) {
        String pkg = prefs.getString(K_IDLE, null);
        if (pkg == null) return true;
        exec("cmd deviceidle whitelist -" + pkg);
        String now = exec("cmd deviceidle whitelist");
        if (isError(now) || now.contains("," + pkg + ",")) return false;
        prefs.edit().remove(K_IDLE).apply();
        return true;
    }

    static boolean pendingRestore(SharedPreferences prefs) {
        return prefs.getBoolean(K_RES, false) || prefs.contains(K_HZ) || prefs.contains(K_IDLE);
    }

    /** Kembalikan semua perubahan Shizuku dan baca ulang hasilnya. Panggil dari thread latar. Mengembalikan ringkasan jujur. */
    static String restoreAll(SharedPreferences prefs) {
        StringBuilder bad = new StringBuilder();
        if (prefs.getBoolean(K_RES, false) && !resetResolution(prefs)) bad.append("resolusi ");
        if (!restoreRefreshRate(prefs)) bad.append("refresh-rate ");
        if (!unboostApp(prefs)) bad.append("whitelist-Doze ");
        return bad.length() == 0 ? "Semua pengaturan dipulihkan (terverifikasi)."
                : "Pemulihan belum lengkap: " + bad.toString().trim() + ". Coba tekan Pulihkan lagi.";
    }
}
