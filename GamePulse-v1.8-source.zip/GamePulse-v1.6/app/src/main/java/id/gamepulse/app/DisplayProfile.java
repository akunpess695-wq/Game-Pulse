package id.gamepulse.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.Display;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Deteksi layar otomatis: daftar refresh rate yang benar-benar didukung panel (60/90/120/144 Hz dst.),
 * jenis perangkat (HP/tablet), dan pemilihan target Hz. Memakai API resmi Display.getSupportedModes (tanpa izin).
 */
final class DisplayProfile {
    private DisplayProfile() {}

    static final String PREF_TARGET = "hz_target"; // 0 = otomatis (maksimum panel)

    /** Refresh rate yang didukung pada ukuran fisik layar saat ini, urut menurun, dibulatkan. Tidak pernah kosong. */
    static List<Integer> rates(Activity a) {
        TreeSet<Integer> set = new TreeSet<>(Collections.reverseOrder());
        try {
            Display d = a.getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode();
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()) {
                    set.add(Math.round(m.getRefreshRate()));
                }
            }
            if (set.isEmpty()) set.add(Math.round(d.getRefreshRate()));
        } catch (Throwable ignored) { }
        if (set.isEmpty()) set.add(60);
        return new ArrayList<>(set);
    }

    static int maxHz(Activity a) { return rates(a).get(0); }

    static int currentHz(Activity a) {
        try { return Math.round(a.getWindowManager().getDefaultDisplay().getRefreshRate()); }
        catch (Throwable t) { return -1; }
    }

    static boolean tablet(Context c) {
        return c.getResources().getConfiguration().smallestScreenWidthDp >= 600;
    }

    /** Target Hz: pilihan pengguna bila masih didukung panel ini, selain itu maksimum panel (HP 120, tablet 144). */
    static int target(Activity a, SharedPreferences p) {
        List<Integer> r = rates(a);
        int want = p.getInt(PREF_TARGET, 0);
        return (want > 0 && r.contains(want)) ? want : r.get(0);
    }

    /** Putar pilihan: otomatis -> tiap rate (menurun) -> otomatis. */
    static void cycle(Activity a, SharedPreferences p) {
        List<Integer> r = rates(a);
        int want = p.getInt(PREF_TARGET, 0);
        int next = 0;
        if (want == 0) next = r.size() > 1 ? r.get(1) : 0; // dari otomatis (=maks) langsung ke nilai di bawahnya
        else {
            int i = r.indexOf(want);
            if (i >= 0 && i + 1 < r.size()) next = r.get(i + 1);
        }
        p.edit().putInt(PREF_TARGET, next).apply();
    }

    static String targetLabel(Activity a, SharedPreferences p) {
        int want = p.getInt(PREF_TARGET, 0);
        int t = target(a, p);
        return (want == t && want > 0) ? t + " Hz (manual)" : "Otomatis (" + t + " Hz)";
    }

    static String summary(Activity a) {
        List<Integer> r = rates(a);
        StringBuilder sb = new StringBuilder(tablet(a) ? "Tablet" : "HP");
        sb.append(" · maks ").append(r.get(0)).append(" Hz · tersedia ");
        for (int i = r.size() - 1; i >= 0; i--) sb.append(r.get(i)).append(i > 0 ? "/" : "");
        int cur = currentHz(a);
        if (cur > 0) sb.append(String.format(Locale.US, " · aktif %d Hz", cur));
        return sb.toString();
    }
}
