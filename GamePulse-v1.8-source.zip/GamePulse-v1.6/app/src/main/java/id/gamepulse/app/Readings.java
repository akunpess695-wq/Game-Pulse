package id.gamepulse.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/** Pembentuk {@link Reading} dari sumber-sumber pemantauan. Menjelaskan alasan bila suatu nilai tidak tersedia. */
final class Readings {
    private Readings() {}

    static Reading temp(Context c) {
        float t = DeviceInfo.tempC(c);
        if (Float.isNaN(t)) return Reading.unavailable("Perangkat tidak melaporkan suhu baterai");
        return Reading.measured(DeviceInfo.tempText(t), "sensor baterai, bukan CPU/GPU");
    }

    static Reading thermal(Context c) {
        if (DeviceInfo.thermalStatus(c) < 0) return Reading.unavailable("Status thermal Android tidak dapat dibaca");
        return Reading.measured(DeviceInfo.thermalText(c), "status resmi Android");
    }

    static Reading headroom(Context c) {
        float hr = DeviceInfo.headroom(c);
        if (Float.isNaN(hr)) return Reading.unavailable("Butuh Android 11+ dan dukungan produsen");
        return Reading.estimated(String.format(Locale.US, "%.0f%%", hr * 100f), "prakiraan 10 dtk; 100% = throttling berat");
    }

    static Reading refresh(Activity a) {
        int cur = DisplayProfile.currentHz(a);
        if (cur <= 0) return Reading.unavailable("Refresh rate layar tidak dapat dibaca");
        return Reading.measured(cur + " Hz", "maks panel " + DisplayProfile.maxHz(a) + " Hz");
    }

    static Reading ram(Context c) {
        double g = DeviceInfo.ramAvailGb(c);
        if (g < 0) return Reading.unavailable("Info memori tidak tersedia");
        return Reading.measured(DeviceInfo.ram(c), "dibaca dari sistem");
    }

    /** FPS hanya bisa diukur lewat Shizuku (dumpsys SurfaceFlinger); app biasa tidak diberi akses ke frame game. */
    static Reading fps(SharedPreferences p, boolean sessionActive) {
        if (!p.getBoolean("sz_fps", true)) return Reading.unavailable("Pengukuran FPS dimatikan di pengaturan");
        if (!ShizukuHelper.running()) return Reading.unavailable("Butuh Shizuku (belum berjalan): Android tidak memberi app biasa akses ke frame game");
        if (!ShizukuHelper.granted()) return Reading.unavailable("Izin Shizuku belum diberikan");
        if (!sessionActive) return Reading.unavailable("Mulai sesi dan buka game untuk mengukur");
        float live = FpsMeter.live;
        if (live < 0) {
            String s = FpsMeter.status;
            return Reading.unavailable(s == null || s.isEmpty() ? "Menunggu frame game" : s.replaceFirst("^FPS: ", ""));
        }
        float low = p.getFloat("fps_low", -1f);
        String v = String.format(Locale.US, "%.0f", live) + (low >= 0 ? String.format(Locale.US, " · 1%% low %.0f", low) : "");
        return Reading.estimated(v, "sampel tiap 5 dtk, belum diverifikasi di HyperOS");
    }
}
