# Kebijakan Privasi — GamePulse

GamePulse tidak mengumpulkan, mengirim, atau membagikan data apa pun.

- Tidak ada izin internet; hanya `ACCESS_NETWORK_STATE` untuk membaca jenis jaringan (Wi-Fi/seluler).
- Selama sesi bermain, layanan latar membaca suhu/status thermal dan menampilkan notifikasi (izin notifikasi & layanan latar); berhenti saat sesi selesai. Data tetap di perangkat.
- Mode Shizuku (opsional) menjalankan perintah sistem atas izin Anda; tidak ada data dikirim keluar. Perintah yang dipakai: `am force-stop`, `wm size`, `settings get/put/delete` (peak/min_refresh_rate, miui_refresh_rate), `cmd deviceidle whitelist`, `am set-standby-bucket`, `dumpsys SurfaceFlinger` (hanya untuk FPS), dan `cmd game` (eksperimental). Nilai asli pengaturan disimpan lokal agar bisa dipulihkan.
- Bila berkas riwayat rusak, GamePulse menyimpan salinan mentahnya secara lokal; dihapus oleh "Hapus riwayat".
- Tidak ada iklan, analitik, atau pelacakan.
- Catatan sesi (waktu, baterai, suhu) disimpan hanya di penyimpanan lokal aplikasi dan terhapus bila aplikasi dihapus.
- Fitur "Bagikan riwayat" hanya mengirim teks ke aplikasi yang Anda pilih sendiri.
- Daftar aplikasi terpasang dibaca di perangkat hanya untuk menemukan game dan fitur "Game lain"; tidak disimpan di luar nama dan paket game yang Anda pilih.

Kontak: isi dengan email/URL pengembang sebelum publikasi ke Play Store.
