package id.gamepulse.app;

import android.app.Activity;
import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import id.gamepulse.app.ui.AnimeTheme;
import id.gamepulse.app.ui.TelemetryGaugeView;
import id.gamepulse.app.ui.TelemetryGraphView;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final int BG = Premium.BG, PANEL = Premium.SURFACE, RED = Premium.ACCENT, WHITE = Premium.TEXT,
            MUTED = Premium.TEXT_2, GREEN = Premium.OK, AMBER = Premium.WARN;
    private static final String EF = "eFootball", MH = "Monster Hunter Outlanders";
    private static final String EF_PKG = "jp.konami.pesam";
    private static final long REFRESH_MS = 30000L;
    private static final int HISTORY_SHOWN = 15;
    private static final int MAX_CUSTOM = 12;

    private SessionStore store;
    private LinearLayout root, body, nav;
    private ScrollView scroll;
    private String selected = EF, tab = "home";
    private int insL, insT, insR, insB;
    private final Map<String, Boolean> installedCache = new HashMap<>();
    private final Map<String, String> pkgCache = new HashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (!isFinishing() && !isDestroyed()) {
                if (hasWindowFocus() && pref().getBoolean("auto_refresh", true)) refreshVisibleStats();
                handler.postDelayed(this, REFRESH_MS);
            }
        }
    };

    private final rikka.shizuku.Shizuku.OnRequestPermissionResultListener permListener =
            (code, result) -> runOnUiThread(this::render);

    @Override protected void onDestroy() {
        try { rikka.shizuku.Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        store = new SessionStore(this);
        try {
            rikka.shizuku.Shizuku.addRequestPermissionResultListener(permListener);
        } catch (Throwable ignored) { }
        if (!store.active() && ShizukuHelper.granted()) {
            new Thread(() -> {
                if (ShizukuHelper.pendingRestore(pref()) || ShizukuHelper.orphanOverride()) ShizukuHelper.restoreAll(pref());
            }).start();
        }
        if (b != null) tab = b.getString("tab", "home");
        selected = pref().getString("selected", EF);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        render();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("tab", tab);
    }

    @Override protected void onResume() {
        super.onResume();
        installedCache.clear();
        pkgCache.clear();
        store.trackPeak(DeviceInfo.tempC(this));
        if (store.active() && pref().getBoolean("svc_on", true)) ThermalService.start(this);
        handler.removeCallbacks(refresh);
        render();
        handler.postDelayed(refresh, REFRESH_MS);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (!"home".equals(tab)) {
            switchTab("home");
        } else {
            super.onBackPressed();
        }
    }

    private SharedPreferences pref() { return store.prefs(); }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable gradient(int c1, int c2, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return t;
    }

    private void add(LinearLayout p, View v, int mt) {
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(-1, -2);
        a.topMargin = dp(mt);
        p.addView(v, a);
    }

    private void pad(View v, int h, int vert) { v.setPadding(dp(h), dp(vert), dp(h), dp(vert)); }

    private LinearLayout card(String title) {
        LinearLayout c = col();
        pad(c, 20, 18);
        c.setBackground(new HudDrawable(this, 0xEE16090B, 0xAAFF3B30, 14, true));
        add(body, c, 13);
        if (title != null) add(c, text(title, 16, WHITE, true), 0);
        return c;
    }

    /** Kartu yang bisa dilipat. Status buka/tutup disimpan, jadi tidak reset saat layar di-refresh. */
    private LinearLayout foldCard(String key, String title, boolean defOpen) {
        return foldCard(key, title, null, 0, defOpen);
    }

    private LinearLayout foldCard(final String key, final String title, String badge, int badgeColor, boolean defOpen) {
        final LinearLayout outer = col();
        outer.setPadding(dp(20), dp(4), dp(20), dp(4));
        outer.setBackground(new HudDrawable(this, 0xEE16090B, 0xAAFF3B30, 14, true));
        add(body, outer, 11);
        final boolean open = pref().getBoolean("fold_" + key, defOpen);
        final LinearLayout head = row();
        head.setMinimumHeight(dp(52));
        head.addView(text(title, 15, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        if (badge != null) {
            TextView b = text(badge, 11, badgeColor, true);
            b.setPadding(0, 0, dp(10), 0);
            head.addView(b);
        }
        final TextView chev = text(open ? "▾" : "▸", 16, RED, true);
        head.addView(chev);
        outer.addView(head, new LinearLayout.LayoutParams(-1, -2));
        final LinearLayout inner = col();
        inner.setPadding(0, 0, 0, dp(12));
        inner.setVisibility(open ? View.VISIBLE : View.GONE);
        outer.addView(inner, new LinearLayout.LayoutParams(-1, -2));
        head.setContentDescription(title + (open ? ", terbuka" : ", tertutup"));
        head.setOnClickListener(v -> {
            boolean now = inner.getVisibility() != View.VISIBLE;
            TransitionManager.beginDelayedTransition(outer, new AutoTransition().setDuration(150));
            inner.setVisibility(now ? View.VISIBLE : View.GONE);
            chev.setText(now ? "▾" : "▸");
            head.setContentDescription(title + (now ? ", terbuka" : ", tertutup"));
            pref().edit().putBoolean("fold_" + key, now).apply();
        });
        return inner;
    }

    /** Beberapa tombol kecil sejajar dalam satu baris (hemat ruang vertikal). */
    private void miniButtons(LinearLayout parent, String[] labels, Runnable[] acts) {
        LinearLayout r = row();
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(labels[i], 11, WHITE, true);
            t.setGravity(Gravity.CENTER);
            pad(t, 4, 9);
            t.setMinHeight(dp(46));
            t.setBackground(Premium.secondaryButton(this));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (i > 0) lp.leftMargin = dp(8);
            r.addView(t, lp);
            AnimeTheme.attachPressFeedback(t);
            final Runnable a = acts[i];
            t.setOnClickListener(v -> a.run());
        }
        add(parent, r, 10);
    }

    private void title(String s, String subtitle) {
        add(body, text(s, 24, WHITE, true), 10);
        add(body, text(subtitle, 12, MUTED, false), 4);
    }

    private ImageView image(int id) {
        ImageView v = new ImageView(this);
        v.setImageResource(id);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(bg(PANEL, 14, 0));
        v.setClipToOutline(true);
        return v;
    }

    private void button(LinearLayout parent, String label, boolean red, Runnable run) {
        TextView t = text(label, 15, WHITE, true);
        t.setGravity(Gravity.CENTER);
        pad(t, 12, 14);
        t.setMinHeight(dp(48));
        t.setBackground(red ? Premium.primaryButton(this) : Premium.secondaryButton(this));
        add(parent, t, 10);
        AnimeTheme.attachPressFeedback(t);
        t.setOnClickListener(v -> run.run());
    }

    private void kv(LinearLayout c, String key, String value) {
        LinearLayout r = row();
        r.addView(text(key, 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView v = text(value, 12, WHITE, true);
        v.setGravity(Gravity.END);
        r.addView(v);
        add(c, r, 11);
    }

    private void stat(LinearLayout r, String icon, String value, String label) { stat(r, icon, value, label, WHITE); }

    private void stat(LinearLayout r, String icon, String value, String label, int valueColor) {
        LinearLayout box = col();
        box.setGravity(Gravity.CENTER);
        pad(box, 3, 14);
        box.setBackground(new HudDrawable(this, 0xFF12080A, 0xCCFF3B30, 11, false));
        TextView a = new TextView(this);
        a.setText(value);
        Premium.number(a);
        a.setTextColor(valueColor);
        a.setMaxLines(1);
        a.setAutoSizeTextTypeUniformWithConfiguration(12, 24, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        a.setGravity(Gravity.CENTER);
        add(box, a, 0);
        TextView b = text(icon + "  " + label, 10, MUTED, false);
        b.setGravity(Gravity.CENTER);
        add(box, b, 6);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = dp(5);
        r.addView(box, lp);
    }

    private View switchPill(boolean on) {
        FrameLayout track = new FrameLayout(this);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(46), dp(26));
        tp.leftMargin = dp(12);
        track.setLayoutParams(tp);
        track.setBackground(bg(on ? 0xFF3A1A0C : 0xFF241012, 13, on ? Premium.CYAN : 0xFF5A1D24));
        track.setContentDescription(on ? "Nyala" : "Mati");

        View thumb = new View(this);
        FrameLayout.LayoutParams kp = new FrameLayout.LayoutParams(dp(18), dp(18));
        kp.gravity = Gravity.CENTER_VERTICAL | (on ? Gravity.END : Gravity.START);
        kp.leftMargin = dp(4);
        kp.rightMargin = dp(4);
        thumb.setBackground(bg(on ? Premium.CYAN : 0xFF8F6F70, 9, 0));
        track.addView(thumb, kp);
        return track;
    }

    private void toggle(LinearLayout c, String label, String key, boolean def) {
        final boolean on = pref().getBoolean(key, def);
        LinearLayout r = row();
        r.setMinimumHeight(dp(48));
        r.addView(text(label, 13, WHITE, false), new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(switchPill(on));
        r.setOnClickListener(v -> {
            pref().edit().putBoolean(key, !on).apply();
            renderKeepScroll();
        });
        add(c, r, 6);
    }

    private void confirm(String title, String msg, Runnable yes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("Ya", (d, w) -> yes.run())
                .setNegativeButton("Batal", null)
                .show();
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "2.0.7";
        }
    }

    private final Map<String, Integer> tabScrollY = new HashMap<>();

    private void render() {
        if (root == null) {
            root = col();
            root.setBackgroundColor(0);
            ScrollView sc = new ScrollView(this);
            scroll = sc;
            sc.setFillViewport(true);
            sc.setVerticalScrollBarEnabled(false);
            body = col();
            pad(body, 17, 20);
            int maxW = dp(680);
            if (getResources().getDisplayMetrics().widthPixels > maxW) {
                sc.addView(body, new FrameLayout.LayoutParams(maxW, -2, Gravity.CENTER_HORIZONTAL));
            } else {
                sc.addView(body);
            }
            root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
            nav = row();
            nav.setBackground(bg(0xFF0C0506, 0, 0));
            View neon = new View(this);
            neon.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Premium.PRIMARY, Premium.ACCENT, Premium.CYAN}));
            root.addView(neon, new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));
            root.addView(nav);
            root.setOnApplyWindowInsetsListener((v, w) -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets i = w.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    insL = i.left; insT = i.top; insR = i.right; insB = i.bottom;
                } else {
                    insL = w.getSystemWindowInsetLeft(); insT = w.getSystemWindowInsetTop();
                    insR = w.getSystemWindowInsetRight(); insB = w.getSystemWindowInsetBottom();
                }
                applyInsets();
                return w;
            });
            applyInsets();
            FrameLayout shell = new FrameLayout(this);
            shell.setBackgroundColor(BG);
            ImageView mecha = new ImageView(this);
            mecha.setImageResource(R.drawable.bg_mecha);
            mecha.setScaleType(ImageView.ScaleType.CENTER_CROP);
            mecha.setAlpha(0.42f);
            mecha.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            shell.addView(mecha, new FrameLayout.LayoutParams(-1, dp(280), Gravity.TOP));
            View fade = new View(this);
            fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x000A0506, 0x800A0506, 0xFF0A0506}));
            shell.addView(fade, new FrameLayout.LayoutParams(-1, dp(280), Gravity.TOP));
            shell.addView(root, new FrameLayout.LayoutParams(-1, -1));
            setContentView(shell);
            root.requestApplyInsets();
        }
        body.removeAllViews();
        header();
        switch (tab) {
            case "games": games(); break;
            case "turbo": turbo(); break;
            case "sessions": sessions(); break;
            case "tools": tools(); break;
            default: home();
        }
        updateNavigation();
    }

    private void renderKeepScroll() {
        final int y = scroll != null ? scroll.getScrollY() : 0;
        render();
        if (scroll != null) scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void switchTab(String nextTab) {
        if (scroll != null) tabScrollY.put(tab, scroll.getScrollY());
        tab = nextTab;
        render();
        final int savedY = tabScrollY.containsKey(tab) ? tabScrollY.get(tab) : 0;
        if (scroll != null) scroll.post(() -> scroll.scrollTo(0, savedY));
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        root = null;
        render();
    }

    private void applyInsets() {
        if (root != null) root.setPadding(insL, insT, insR, 0);
        if (nav != null) nav.setPadding(dp(7), dp(8), dp(7), dp(9) + insB);
    }

    private void header() {
        LinearLayout h = row();
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_gp);
        logo.setContentDescription("Logo GamePulse");
        h.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout names = col();
        TextView brand = text("GAMEPULSE", 28, WHITE, true);
        brand.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        Premium.gradientText(brand, new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0xFFFF3B30, 0xFFFF2A1F},
                new float[]{0f, 0.46f, 0.50f, 1f}, 0xAAFF3B30);
        add(names, brand, 0);
        SpannableStringBuilder sub = new SpannableStringBuilder("V" + versionName() + "  /  CYBER SAKURA EDITION");
        int slash = sub.toString().indexOf('/');
        sub.setSpan(new ForegroundColorSpan(Premium.CYAN), 0, slash, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sub.setSpan(new ForegroundColorSpan(Premium.ACCENT), slash, sub.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView subT = text("", 10, RED, true);
        subT.setText(sub);
        add(names, subT, 0);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, -2, 1);
        np.leftMargin = dp(8);
        h.addView(names, np);
        boolean live = pref().getBoolean("auto_refresh", true);
        h.addView(text(live ? "● LIVE" : "○ MANUAL", 11, live ? GREEN : MUTED, true));
        add(body, h, 0);
    }

    private void updateNavigation() {
        nav.removeAllViews();
        String[] ids = {"home", "games", "turbo", "sessions", "tools"};
        String[] labels = {"Home", "Games", "Turbo", "Sessions", "Tools"};
        int[] icons = {R.drawable.ic_nav_home, R.drawable.ic_nav_games, R.drawable.ic_nav_turbo, R.drawable.ic_nav_sessions, R.drawable.ic_nav_tools};
        String[] desc = {"Beranda", "Game", "Game Turbo", "Sesi", "Alat"};
        for (int i = 0; i < ids.length; i++) {
            final String id = ids[i];
            final boolean on = tab.equals(id);
            LinearLayout item = col();
            item.setGravity(Gravity.CENTER);
            item.setContentDescription(desc[i]);
            item.setPadding(dp(2), dp(8), dp(2), dp(8));
            item.setMinimumHeight(dp(56));
            ImageView ic = new ImageView(this);
            ic.setImageResource(icons[i]);
            ic.setColorFilter(on ? RED : MUTED);
            item.addView(ic, new LinearLayout.LayoutParams(dp(24), dp(24)));
            TextView t = text(labels[i], 11, on ? WHITE : MUTED, on);
            t.setGravity(Gravity.CENTER);
            add(item, t, 3);
            if (on) item.setBackground(new HudDrawable(this, 0xFF4A1015, Premium.ACCENT, 12, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.leftMargin = dp(3);
            lp.rightMargin = dp(3);
            nav.addView(item, lp);
            item.setOnClickListener(v -> {
                if (!tab.equals(id)) switchTab(id);
            });
        }
    }

    private static final class Game {
        final String name, sub, pkg, kind;
        final String[] keywords;
        final int banner;

        Game(String name, String sub, String pkg, String[] keywords, int banner, String kind) {
            this.name = name;
            this.sub = sub;
            this.pkg = pkg;
            this.keywords = keywords;
            this.banner = banner;
            this.kind = kind;
        }
    }

    private String kindOf(String name, String pkg) {
        String n = (name + " " + pkg).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (n.contains("mobilelegends") || n.contains("mlbb") || n.contains("honorofkings") || n.contains("arenaofvalor")) return "moba";
        if (n.contains("clashofclans") || n.contains("clashroyale") || n.contains("supercell")) return "strategy";
        if (n.contains("monsterhunter") || n.contains("mhgu") || n.contains("mhoutlanders")) return "hunter";
        if (n.contains("efootball") || n.contains("pes") || n.contains("fifa") || n.contains("football") || n.contains("soccer")) return "football";
        if (n.contains("pubg") || n.contains("freefire") || n.contains("callofduty") || n.contains("codm")) return "battle";
        return "generic";
    }

    private List<String[]> customs() {
        List<String[]> l = new ArrayList<>();
        String j = pref().getString("custom_games", null);
        if (j != null) {
            try {
                JSONArray a = new JSONArray(j);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null && !o.optString("p").isEmpty()) l.add(new String[]{o.optString("n"), o.optString("p")});
                }
            } catch (JSONException ignored) { }
            return l;
        }
        String cp = pref().getString("custom_pkg", "");
        String cn = pref().getString("custom_name", "");
        if (!cp.isEmpty() && !cn.isEmpty()) l.add(new String[]{cn, cp});
        return l;
    }

    private void saveCustoms(List<String[]> l) {
        JSONArray a = new JSONArray();
        for (String[] x : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("n", x[0]);
                o.put("p", x[1]);
                a.put(o);
            } catch (JSONException ignored) { }
        }
        pref().edit().putString("custom_games", a.toString()).remove("custom_pkg").remove("custom_name").apply();
    }

    private boolean isCustom(String name) {
        for (String[] x : customs()) if (x[0].equals(name)) return true;
        return false;
    }

    private String pkgOf(Game g) {
        if (g.pkg != null) return g.pkg;
        if (pkgCache.containsKey(g.name)) return pkgCache.get(g.name);
        Intent in = intentFor(g);
        String r = (in != null && in.getComponent() != null) ? in.getComponent().getPackageName() : null;
        pkgCache.put(g.name, r);
        return r;
    }

    private boolean addCustom(String name, String pkg) {
        if (name == null || name.trim().isEmpty() || pkg == null) return false;
        List<String[]> l = customs();
        if (l.size() >= MAX_CUSTOM) return false;
        for (String[] x : l) if (x[1].equals(pkg)) return false;
        for (Game g : gameList()) {
            String gp = pkgOf(g);
            if (gp != null && gp.equals(pkg)) return false;
        }
        l.add(new String[]{name.trim(), pkg});
        saveCustoms(l);
        return true;
    }

    private List<Game> gameList() {
        List<Game> l = new ArrayList<>();
        l.add(new Game(EF, "RESPONS KONTROL  /  KONEKSI", EF_PKG, null, R.drawable.banner_football, "football"));
        l.add(new Game(MH, "FRAME PACING  /  THERMAL", null, new String[]{"monsterhunteroutlanders", "mhoutlanders"},
                R.drawable.banner_hunter, "hunter"));
        for (String[] x : customs()) {
            l.add(new Game(x[0], "GAME PILIHAN SAYA", x[1], null, 0, kindOf(x[0], x[1])));
        }
        return l;
    }

    private Game current() {
        List<Game> l = gameList();
        for (Game g : l) if (g.name.equals(selected)) return g;
        selected = EF;
        return l.get(0);
    }

    private Intent intentFor(Game g) {
        PackageManager pm = getPackageManager();
        if (g.pkg != null) return pm.getLaunchIntentForPackage(g.pkg);
        if (g.keywords == null) return null;
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null) continue;
            String label = String.valueOf(i.loadLabel(pm)).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
            boolean match = false;
            for (String k : g.keywords) if (label.contains(k)) match = true;
            if (match) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(i.activityInfo.packageName, i.activityInfo.name);
                return launch;
            }
        }
        return null;
    }

    private boolean installed(Game g) {
        Boolean b = installedCache.get(g.name);
        if (b == null) {
            b = intentFor(g) != null;
            installedCache.put(g.name, b);
        }
        return b;
    }

    private void select(String name) {
        selected = name;
        pref().edit().putString("selected", name).apply();
    }

    private void launch() {
        Game g = current();
        Intent in = intentFor(g);
        if (in == null) {
            if (g.pkg != null) {
                toast(g.name + " belum terpasang. Membuka Play Store.");
                openStore(g.pkg);
            } else {
                toast(g.name + " tidak ditemukan. Buka dari launcher HP.");
            }
            return;
        }
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(in);
        } catch (Exception ex) {
            toast("Tidak dapat membuka game; coba dari launcher HP.");
        }
    }

    private void openStore(String pkg) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg)));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + pkg)));
            } catch (Exception e2) {
                toast("Play Store tidak tersedia.");
            }
        }
    }

    private void pickGame() {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Set<String> have = new HashSet<>();
        for (Game g : gameList()) {
            String gp = pkgOf(g);
            if (gp != null) have.add(gp);
        }
        final List<String[]> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null) continue;
            String pkg = i.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || have.contains(pkg) || !seen.add(pkg)) continue;
            apps.add(new String[]{String.valueOf(i.loadLabel(pm)), pkg});
        }
        if (apps.isEmpty()) {
            toast("Tidak ada aplikasi lain yang bisa ditambahkan.");
            return;
        }
        Collections.sort(apps, (x, y) -> x[0].compareToIgnoreCase(y[0]));
        CharSequence[] labels = new CharSequence[apps.size()];
        for (int k = 0; k < labels.length; k++) labels[k] = apps.get(k)[0];
        new AlertDialog.Builder(this)
                .setTitle("Tambah game / aplikasi")
                .setItems(labels, (d, which) -> {
                    String[] a = apps.get(which);
                    if (addCustom(a[0], a[1])) {
                        select(a[0].trim());
                    } else {
                        toast("Tidak bisa menambah (daftar penuh, maks " + MAX_CUSTOM + " game pilihan).");
                    }
                    installedCache.clear();
                    render();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void autoAdd() {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Set<String> seen = new HashSet<>();
        int added = 0;
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null || i.activityInfo.applicationInfo == null) continue;
            String pkg = i.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            if (i.activityInfo.applicationInfo.category != ApplicationInfo.CATEGORY_GAME) continue;
            if (addCustom(String.valueOf(i.loadLabel(pm)), pkg)) added++;
        }
        installedCache.clear();
        toast(added > 0 ? added + " game ditambahkan."
                : "Tidak ada game baru terdeteksi. Pakai 'Pilih dari aplikasi terpasang'.");
        render();
    }

    private void removeCustom(String name) {
        List<String[]> l = customs();
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i)[0].equals(name)) {
                l.remove(i);
                break;
            }
        }
        saveCustoms(l);
        if (selected.equals(name)) select(EF);
        installedCache.clear();
        render();
    }

    private void appInfo(Game g) {
        String pkg = pkgOf(g);
        if (pkg == null) {
            toast(g.name + " tidak ditemukan di HP.");
            return;
        }
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
        } catch (Exception e) {
            toast("Info aplikasi tidak tersedia.");
        }
    }

    private void hero() {
        FrameLayout frame = new FrameLayout(this);
        GradientDrawable hbg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF1A0B0E, 0xFF3A0F14});
        hbg.setCornerRadius(dp(18));
        frame.setBackground(hbg);
        frame.setClipToOutline(true);

        ImageView art = new ImageView(this);
        art.setImageResource(R.drawable.hero_sora);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setContentDescription("Karakter Sora dan mecha");
        frame.addView(art, new FrameLayout.LayoutParams(-1, -1));

        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xF20A0506, 0xCC0A0506, 0x000A0506}));
        frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout words = col();
        words.setPadding(dp(16), dp(12), dp(16), dp(12));
        TextView l1 = text("GAMING.", 27, WHITE, true);
        TextView l2 = text("TANPA GIMMICK.", 22, WHITE, true);
        l1.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        l2.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        Premium.gradientText(l1, 0xFFFFFFFF, 0xFFE4DADA, 0x66FFFFFF);
        Premium.gradientText(l2, 0xFFFF4A3A, 0xFFFF1F1F, 0xAAFF2A1F);
        add(words, l1, 0);
        add(words, l2, 0);
        add(words, text("MONITOR  /  LAUNCH  /  ANALYZE", 10, Premium.CYAN, true), 10);
        TextView sub = text("Memantau telemetri FPS & frame-time secara real-time.", 11, WHITE, false);
        add(words, sub, 6);
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);
        wp.rightMargin = dp(88);
        frame.addView(words, wp);

        View border = new View(this);
        GradientDrawable bd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0, 0});
        bd.setCornerRadius(dp(18));
        bd.setStroke(dp(1), 0xAAFF3B30);
        border.setBackground(bd);
        frame.addView(border, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(166));
        fp.topMargin = dp(15);
        body.addView(frame, fp);
    }

    private void alerts() {
        int heat = DeviceInfo.heatLevel(this);
        int lv = DeviceInfo.level(this);
        boolean chg = DeviceInfo.charging(this);
        String msg = null;
        int color = AMBER;
        if (heat == 2) {
            msg = "⚠  Perangkat panas. Istirahatkan game, lepas casing, dan hindari mengisi daya sambil bermain.";
            color = RED;
        } else if (heat == 1) {
            msg = "◔  Perangkat mulai hangat. Pantau suhu dan turunkan grafis bila perlu.";
        } else if (lv >= 0 && lv <= 15 && !chg) {
            msg = "▰  Baterai rendah (" + lv + "%). Hubungkan charger sebelum sesi panjang.";
        }
        if (msg == null) return;
        TextView t = text(msg, 13, WHITE, false);
        pad(t, 14, 12);
        t.setBackground(new HudDrawable(this, 0xE61F0B0E, color, 12, false));
        add(body, t, 13);
    }

    private void device() {
        LinearLayout c = card("⌁  STATUS PERANGKAT");
        int lv = DeviceInfo.level(this);
        float tc = DeviceInfo.tempC(this);
        double ramGb = DeviceInfo.ramAvailGb(this);

        LinearLayout gauges = row();
        TelemetryGaugeView gBat = new TelemetryGaugeView(this);
        gBat.setMetric(lv < 0 ? 0f : lv / 100f, lv < 0 ? "N/A" : lv + "%",
                DeviceInfo.charging(this) ? "CHARGING" : "BATERAI",
                lv >= 30 || DeviceInfo.charging(this) ? AnimeTheme.STATUS_GOOD : AnimeTheme.STATUS_WARN);
        LinearLayout.LayoutParams gp1 = new LinearLayout.LayoutParams(0, dp(104), 1);
        gp1.rightMargin = dp(6);
        gauges.addView(gBat, gp1);

        int tColor = Float.isNaN(tc) ? AnimeTheme.ACCENT : Premium.tempColor(tc, Thresholds.warm(this), Thresholds.hot(this));
        float tFrac = Float.isNaN(tc) ? 0f : Math.max(0f, Math.min(1f, (tc - 25f) / 25f));
        TelemetryGaugeView gTemp = new TelemetryGaugeView(this);
        gTemp.setMetric(tFrac, Float.isNaN(tc) ? "N/A" : String.format(Locale.US, "%.1f°C", tc), "SUHU", tColor);
        LinearLayout.LayoutParams gp2 = new LinearLayout.LayoutParams(0, dp(104), 1);
        gp2.rightMargin = dp(6);
        gauges.addView(gTemp, gp2);

        float fpsNow = pref().getFloat("last_measured_fps", -1f);
        TelemetryGaugeView gFps = new TelemetryGaugeView(this);
        if (fpsNow > 0f) {
            gFps.setMetric(Math.min(1f, fpsNow / 120f), String.valueOf(Math.round(fpsNow)), "FPS",
                    Premium.fpsColor(fpsNow, 60f));
        } else {
            gFps.setMetric(ramGb < 0 ? 0f : Math.min(1f, (float) (ramGb / 8.0)),
                    ramGb < 0 ? "N/A" : String.format(Locale.US, "%.1fG", ramGb), "RAM FREE", AnimeTheme.ACCENT);
        }
        gauges.addView(gFps, new LinearLayout.LayoutParams(0, dp(104), 1));
        add(c, gauges, 12);

        kv(c, "THERMAL", DeviceInfo.thermalText(this));
        kv(c, "JARINGAN", DeviceInfo.network(this));
        add(c, text("ANDROID " + Build.VERSION.RELEASE + "  ·  " + Build.MANUFACTURER.toUpperCase(Locale.ROOT) + " "
                + Build.MODEL + "  ·  RAM " + DeviceInfo.ram(this), 11, MUTED, false), 10);
    }

    private void gameCard(LinearLayout c, Game g) {
        final boolean chosen = selected.equals(g.name);
        final boolean ok = installed(g);
        LinearLayout wrap = row();
        wrap.setBackground(bg(chosen ? 0xFF3A1216 : 0xFF1A0C0F, 16, chosen ? Premium.PRIMARY : 0xFF4A1A22));
        wrap.setPadding(dp(8), dp(7), dp(8), dp(7));

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(bg(0xFF3A0F14, 14, 0));
        icon.setClipToOutline(true);
        boolean shown = false;
        String pk = pkgOf(g);
        if (pk != null && ok) {
            try {
                icon.setImageDrawable(getPackageManager().getApplicationIcon(pk));
                shown = true;
            } catch (Exception ignored) { }
        }
        if (!shown && g.banner != 0) {
            icon.setImageResource(g.banner);
            shown = true;
        }
        icon.setContentDescription("Ikon " + g.name);
        if (shown) {
            wrap.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        } else {
            String ini = g.name.isEmpty() ? "?" : g.name.substring(0, 1).toUpperCase(Locale.ROOT);
            TextView t = text(ini, 22, WHITE, true);
            t.setGravity(Gravity.CENTER);
            t.setBackground(gradient(0xFF3A0F14, 0xFF5A1414, 14));
            wrap.addView(t, new LinearLayout.LayoutParams(dp(44), dp(44)));
        }

        LinearLayout info = col();
        info.setPadding(dp(12), 0, dp(8), 0);
        TextView name = text(g.name, 15, WHITE, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        add(info, name, 0);
        LinearLayout st = row();
        TextView dot = text("●", 9, ok ? GREEN : AMBER, false);
        st.addView(dot);
        TextView stt = text("  " + (ok ? "Terpasang" : "Belum terpasang") + (chosen ? "  ·  Terpilih" : ""),
                11, chosen ? 0xFFFFB0A6 : MUTED, false);
        st.addView(stt);
        add(info, st, 2);
        wrap.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView play = text(ok ? "▶  PLAY" : "⇩  GET", 12, WHITE, true);
        pad(play, 12, 8);
        play.setMinHeight(dp(38));
        play.setGravity(Gravity.CENTER);
        play.setBackground(chosen ? gradient(Premium.PRIMARY, RED, 12) : bg(0xFF2E1115, 12, 0xFF5A1D24));
        wrap.addView(play);
        play.setOnClickListener(v -> {
            select(g.name);
            launch();
        });
        add(c, wrap, 7);
        wrap.setOnClickListener(v -> {
            select(g.name);
            renderKeepScroll();
        });
    }

    private void library() {
        LinearLayout c = card("⚔  GAME PROFILES");
        for (Game g : gameList()) gameCard(c, g);
    }

    private void gameDock() {
        LinearLayout c = card(null);
        LinearLayout hd = row();
        hd.addView(text("⚔  GAME TERPILIH", 15, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView ch = text("GANTI  ▸", 12, RED, true);
        pad(ch, 8, 8);
        ch.setOnClickListener(v -> switchTab("games"));
        hd.addView(ch);
        add(c, hd, 0);
        gameCard(c, current());
    }

    private void shortcuts() {
        LinearLayout c = card("⌘  QUICK TOOLS");
        LinearLayout r = row();
        String[] names = {"◉\nMONITOR", "▥\nSESI", "☷\nTUNING"};
        for (int i = 0; i < 3; i++) {
            final int j = i;
            TextView t = text(names[i], 13, WHITE, true);
            t.setGravity(Gravity.CENTER);
            pad(t, 3, 14);
            t.setBackground(bg(0xFF2A1014, 12, 0xFF6A2A30));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.rightMargin = dp(7);
            r.addView(t, lp);
            t.setOnClickListener(v -> {
                switchTab(j == 0 ? "home" : j == 1 ? "sessions" : "tools");
            });
        }
        add(c, r, 11);
    }

    private String[][] profileRows(String kind) {
        switch (kind) {
            case "football":
                return new String[][]{{"GRAFIS", "STANDARD"}, {"FRAME RATE", "60 JIKA TERSEDIA"}, {"KONEKSI", "WI-FI STABIL"}};
            case "hunter":
                return new String[][]{{"GRAFIS", "LOW"}, {"FRAME RATE", "30 SEBAGAI BASELINE"}, {"BAYANGAN / EFEK", "RENDAH"}};
            case "moba":
                return new String[][]{{"GRAFIS", "MENENGAH"}, {"FRAME RATE", "60 / TINGGI BILA STABIL"}, {"KONEKSI", "PING STABIL"}};
            case "strategy":
                return new String[][]{{"GRAFIS", "STANDARD"}, {"FRAME RATE", "30-60 (RINGAN)"}, {"BATERAI", "HEMAT DAYA BOLEH"}};
            case "battle":
                return new String[][]{{"GRAFIS", "MENENGAH"}, {"FRAME RATE", "SESUAI KEMAMPUAN HP"}, {"KONEKSI", "WI-FI STABIL"}};
            default:
                return new String[][]{{"GRAFIS", "MULAI DARI MENENGAH"}, {"FRAME RATE", "SESUAI KEMAMPUAN HP"}, {"KONEKSI", "WI-FI STABIL"}};
        }
    }

    private String tipFor(String kind) {
        String common = " Di Redmi/Xiaomi, tambahkan game ke Game Turbo (aplikasi Keamanan) untuk mode performa bawaan HP.";
        switch (kind) {
            case "moba": return "Utamakan koneksi stabil dan matikan unduhan di latar belakang. Naikkan frame rate hanya jika HP tetap dingin." + common;
            case "strategy": return "Game ringan: cukup grafis standar. Aman dimainkan dengan penghemat baterai bila HP tidak panas." + common;
            case "football": return "Respons kontrol dan koneksi lebih penting daripada grafis maksimum." + common;
            case "hunter": return "Game berat: mulai dari grafis rendah dan 30 FPS, naikkan bertahap sambil memantau suhu." + common;
            case "battle": return "Pilih preset grafis menengah dulu; frame rate tinggi memanaskan HP lebih cepat." + common;
            default: return "Mulai dari pengaturan menengah di dalam game, lalu naikkan selama suhu tetap normal." + common;
        }
    }

    private void checkRow(LinearLayout c, String key, String value, boolean ok) {
        LinearLayout r = row();
        r.addView(text(key, 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView v = text((ok ? "✓  " : "!  ") + value, 12, ok ? GREEN : AMBER, true);
        v.setGravity(Gravity.END);
        r.addView(v);
        add(c, r, 11);
    }

    private void readiness() {
        int lv = DeviceInfo.level(this);
        boolean chg = DeviceInfo.charging(this);
        int heat = DeviceInfo.heatLevel(this);
        double ram = DeviceInfo.ramAvailGb(this);
        String net = DeviceInfo.network(this);
        boolean okBat = lv < 0 || lv >= 30 || chg;
        boolean okHeat = heat == 0;
        boolean okRam = ram < 0 || ram >= 2.0;
        boolean okNet = "Wi-Fi".equals(net) || "Ethernet".equals(net);
        boolean okPs = !Optimizer.powerSave(this);
        boolean all = okBat && okHeat && okRam && okNet && okPs;
        LinearLayout c = foldCard("ready", "✔  KESIAPAN MAIN", all ? "SIAP" : "CEK", all ? GREEN : AMBER, false);
        checkRow(c, "BATERAI", lv < 0 ? "N/A" : lv + "%" + (chg ? " (mengisi)" : ""), okBat);
        checkRow(c, "SUHU", heat == 0 ? "Normal" : heat == 1 ? "Hangat" : "Panas", okHeat);
        checkRow(c, "RAM TERSEDIA", ram < 0 ? "N/A" : String.format(Locale.US, "%.1f GB", ram), okRam);
        checkRow(c, "JARINGAN", net, okNet);
        checkRow(c, "HEMAT DAYA", okPs ? "Mati" : "Aktif (performa dibatasi)", okPs);
        add(c, text(all ? "Siap main." : "Perhatikan item berwarna kuning sebelum mulai (jaringan hanya penting untuk game online).",
                12, all ? GREEN : MUTED, false), 12);
    }

    private void baseline() {
        Game g = current();
        LinearLayout c = foldCard("baseline", "◎  RECOMMENDED BASELINE", false);
        add(c, text(g.name.toUpperCase(Locale.ROOT), 13, RED, true), 10);
        for (String[] row : profileRows(g.kind)) kv(c, row[0], row[1]);
        add(c, text(tipFor(g.kind), 12, MUTED, false), 13);
        add(c, text("Rekomendasi manual; bukan perubahan performa sistem atau FPS terukur.", 11, MUTED, false), 8);
        button(c, "▶  BUKA " + g.name.toUpperCase(Locale.ROOT), true, this::launch);
        button(c, "INFO APLIKASI (BATERAI / IZIN)", false, () -> appInfo(g));
    }

    private void safety() {
        LinearLayout c = foldCard("checklist", "◈  GAMING CHECKLIST", false);
        kv(c, "MODE HEMAT BATERAI", "Nonaktifkan saat uji FPS");
        kv(c, "SUHU PERANGKAT", "Hentikan jika terlalu panas");
        kv(c, "FPS AKTUAL", "Diukur perkiraan bila Shizuku aktif");
        add(c, text("Gunakan pengaturan grafis resmi game. Jangan mengubah file game atau menonaktifkan perlindungan thermal.",
                12, MUTED, false), 12);
    }

    private void home() {
        hero();
        alerts();
        device();
        gameDock();
        readiness();
        baseline();
    }

    private void games() {
        title("GAME LIBRARY", "PILIH GAME. SIAPKAN PROFIL. MAIN.");
        library();
        LinearLayout c = foldCard("addgame", "＋  TAMBAH GAME", false);
        add(c, text("Maks " + MAX_CUSTOM + " game pilihan. Game yang tidak terdeteksi otomatis bisa dipilih manual.", 12, MUTED, false), 8);
        button(c, "DETEKSI GAME OTOMATIS", false, this::autoAdd);
        button(c, "PILIH DARI APLIKASI TERPASANG", false, this::pickGame);
        if (isCustom(selected)) {
            final String name = selected;
            button(c, "HAPUS \"" + name + "\" DARI DAFTAR", false, () -> removeCustom(name));
        }
    }


    // ===================== GAME TURBO =====================
    private static final String[] PRESETS = {"Bawaan", "Hemat daya", "Seimbang", "Performa tinggi", "Kustom"};
    private static final float[][] PRESET_VALUES = {
            {0.60f, 0.60f, 0.60f}, {0.35f, 0.45f, 0.95f}, {0.60f, 0.65f, 0.65f}, {0.90f, 0.95f, 0.30f}, null};
    private static final String[] SCALE_VAL = {null, "0.9", "0.8", "0.7", "0.6", "0.5"};
    private static final String[] SCALE_LBL = {"100%", "90%", "80%", "70%", "60%", "50%"};
    private static final String[] FPS_VAL = {null, "30", "45", "60", "90", "120"};
    private static final String[] FPS_LBL = {"Otomatis", "30", "45", "60", "90", "120"};

    private int presetOf(String pk) { return pk == null ? 0 : pref().getInt("turbo_p_" + pk, 0); }

    private String sigNow(String pk) {
        int p = presetOf(pk);
        return p + ":" + (p == 4 ? pref().getInt("turbo_sc", 0) + "," + pref().getInt("turbo_fp", 0) : "");
    }

    private float[] radarValues(int p) {
        if (p != 4) return PRESET_VALUES[p];
        int sc = Math.max(0, Math.min(SCALE_VAL.length - 1, pref().getInt("turbo_sc", 0)));
        int fp = Math.max(0, Math.min(FPS_VAL.length - 1, pref().getInt("turbo_fp", 0)));
        float q = 0.95f - sc * 0.12f;
        float f = FPS_VAL[fp] == null ? 0.70f : Math.min(0.95f, Integer.parseInt(FPS_VAL[fp]) / 120f * 0.95f);
        float e = Math.max(0.10f, Math.min(0.95f, 1.30f - 0.55f * q - 0.55f * f));
        return new float[]{q, f, e};
    }

    private View gameIconView(Game g, int sizeDp) {
        String pk = pkgOf(g);
        boolean ok = installed(g);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(bg(0xFF3A0F14, 12, 0));
        icon.setClipToOutline(true);
        boolean shown = false;
        if (pk != null && ok) {
            try {
                icon.setImageDrawable(getPackageManager().getApplicationIcon(pk));
                shown = true;
            } catch (Exception ignored) { }
        }
        if (!shown && g.banner != 0) {
            icon.setImageResource(g.banner);
            shown = true;
        }
        icon.setContentDescription("Ikon " + g.name);
        if (shown) return icon;
        TextView t = text(g.name.isEmpty() ? "?" : g.name.substring(0, 1).toUpperCase(Locale.ROOT), sizeDp / 3, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(gradient(0xFF3A0F14, 0xFF5A1414, 12));
        return t;
    }

    private TextView chipView(String s, int color) {
        TextView t = text(s, 12, color, true);
        pad(t, 12, 7);
        t.setBackground(new HudDrawable(this, 0xFF12080A, 0xCCFF3B30, 8, false));
        return t;
    }

    private void turbo() {
        title("GAME TURBO", "PILIH GAME. ATUR PRESET. MAINKAN.");
        final Game g = current();
        final String pk = pkgOf(g);

        LinearLayout st = row();
        int lv = DeviceInfo.level(this);
        float tc = DeviceInfo.tempC(this);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.rightMargin = dp(8);
        st.addView(chipView("▰  " + (lv < 0 ? "N/A" : lv + "%") + (DeviceInfo.charging(this) ? "  ⚡" : ""), WHITE), cp);
        st.addView(chipView("♨  " + DeviceInfo.tempText(tc),
                Float.isNaN(tc) ? WHITE : Premium.tempColor(tc, Thresholds.warm(this), Thresholds.hot(this))), cp);
        add(body, st, 12);

        // daftar game (geser ke samping)
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = row();
        for (final Game x : gameList()) {
            boolean ch = x.name.equals(selected);
            LinearLayout tile = col();
            tile.setGravity(Gravity.CENTER_HORIZONTAL);
            tile.setPadding(dp(6), dp(6), dp(6), dp(6));
            tile.setBackground(bg(ch ? 0xFF3A1216 : 0x00000000, 14, ch ? Premium.PRIMARY : 0x00000000));
            tile.addView(gameIconView(x, 54), new LinearLayout.LayoutParams(dp(54), dp(54)));
            TextView n = text(x.name, 10, ch ? WHITE : MUTED, ch);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.END);
            n.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
            np.topMargin = dp(4);
            tile.addView(n, np);
            tile.setOnClickListener(v -> { select(x.name); renderKeepScroll(); });
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(74), -2);
            tp.rightMargin = dp(4);
            strip.addView(tile, tp);
        }
        hs.addView(strip);
        add(body, hs, 10);

        // banner game terpilih
        FrameLayout ban = new FrameLayout(this);
        GradientDrawable bb = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3A0F14, 0xFF1A0B0E});
        bb.setCornerRadius(dp(18));
        ban.setBackground(bb);
        ban.setClipToOutline(true);
        if (g.banner != 0) {
            ImageView im = new ImageView(this);
            im.setImageResource(g.banner);
            im.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ban.addView(im, new FrameLayout.LayoutParams(-1, -1));
        } else {
            ban.addView(gameIconView(g, 88), new FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER));
        }
        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xEE0A0506}));
        ban.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout cap = col();
        cap.setPadding(dp(14), 0, dp(14), dp(12));
        add(cap, text(g.name, 20, WHITE, true), 0);
        add(cap, text(g.sub, 10, Premium.CYAN, true), 2);
        ban.addView(cap, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        View border = new View(this);
        GradientDrawable bd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0, 0});
        bd.setCornerRadius(dp(18));
        bd.setStroke(dp(1), 0xAAFF3B30);
        border.setBackground(bd);
        ban.addView(border, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(150));
        bp.topMargin = dp(10);
        body.addView(ban, bp);

        TextView play = text("⚡  MAINKAN", 18, WHITE, true);
        play.setGravity(Gravity.CENTER);
        pad(play, 12, 16);
        play.setMinHeight(dp(56));
        play.setBackground(Premium.primaryButton(this));
        AnimeTheme.attachPressFeedback(play);
        play.setOnClickListener(v -> turboPlay());
        add(body, play, 12);
        add(body, text(installed(g)
                ? "Bersihkan RAM, mulai sesi, lalu buka game. Preset diterapkan lebih dulu bila Shizuku aktif."
                : "Game belum terpasang; tombol akan membuka Play Store.", 11, MUTED, false), 6);

        presetCard(pk);
    }

    private void presetCard(final String pk) {
        LinearLayout c = foldCard("preset", "◈  PRESET PERFORMA", true);
        final int p = presetOf(pk);
        RadarView radar = new RadarView(this);
        radar.setContentDescription("Perkiraan trade-off preset " + PRESETS[p]);
        radar.setData(new String[]{"Kualitas gambar", "Kelancaran FPS", "Hemat daya"}, radarValues(p));
        c.addView(radar, new LinearLayout.LayoutParams(-1, dp(220)));

        presetRow(c, pk, p, new int[]{0, 1, 2});
        presetRow(c, pk, p, new int[]{3, 4});

        if (p == 4) {
            final int sc = Math.max(0, Math.min(SCALE_VAL.length - 1, pref().getInt("turbo_sc", 0)));
            final int fp = Math.max(0, Math.min(FPS_VAL.length - 1, pref().getInt("turbo_fp", 0)));
            miniButtons(c, new String[]{"RESOLUSI\n" + SCALE_LBL[sc] + "  ▸", "BATAS FPS\n" + FPS_LBL[fp] + "  ▸"}, new Runnable[]{
                    () -> { pref().edit().putInt("turbo_sc", (sc + 1) % SCALE_VAL.length).apply(); renderKeepScroll(); },
                    () -> { pref().edit().putInt("turbo_fp", (fp + 1) % FPS_VAL.length).apply(); renderKeepScroll(); }});
        }

        boolean sz = ShizukuHelper.running() && ShizukuHelper.granted();
        String applied = pk == null ? null : pref().getString("turbo_a_" + pk, null);
        String status;
        if (pk == null) {
            status = "Game belum terpasang, preset tidak bisa diterapkan.";
        } else if (applied == null) {
            status = "Belum ada preset yang diterapkan GamePulse untuk game ini.";
        } else {
            int ai = 0;
            try { ai = Integer.parseInt(applied.substring(0, applied.indexOf(':'))); } catch (Exception ignored) { }
            status = "Terakhir diterapkan: " + PRESETS[Math.max(0, Math.min(PRESETS.length - 1, ai))];
        }
        add(c, text(status, 12, MUTED, false), 12);

        if (!sz) {
            add(c, text("Butuh Shizuku aktif dan diizinkan untuk menerapkan preset.", 12, AMBER, false), 6);
            button(c, "SIAPKAN SHIZUKU", true, () -> {
                if (ShizukuHelper.running()) ShizukuHelper.requestPermission();
                else switchTab("tools");
            });
        } else if (pk != null) {
            button(c, p == 0 ? "KEMBALIKAN KE BAWAAN" : "TERAPKAN: " + PRESETS[p].toUpperCase(Locale.ROOT), true,
                    () -> applyPresetAsync(pk, p, null));
        }
        add(c, text("Memakai Game Mode resmi Android lewat Shizuku. Grafik radar hanya perkiraan arah trade-off, bukan hasil ukur. "
                + "Efeknya bergantung pada dukungan game dan HyperOS. Tidak mengubah GPU atau kontrol sentuhan.", 11, MUTED, false), 10);
    }

    private void presetRow(LinearLayout c, final String pk, int sel, int[] idx) {
        LinearLayout r = row();
        for (int k = 0; k < idx.length; k++) {
            final int i = idx[k];
            boolean on = i == sel;
            TextView t = text(PRESETS[i], 12, on ? WHITE : MUTED, on);
            t.setGravity(Gravity.CENTER);
            pad(t, 4, 10);
            t.setMinHeight(dp(46));
            t.setBackground(new HudDrawable(this, on ? 0xFF4A1015 : 0xFF1F0C0F, on ? Premium.ACCENT : 0xFF5A1D24, 8, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            if (k > 0) lp.leftMargin = dp(8);
            r.addView(t, lp);
            t.setOnClickListener(v -> {
                if (pk == null) { toast("Game belum terpasang"); return; }
                pref().edit().putInt("turbo_p_" + pk, i).apply();
                renderKeepScroll();
            });
        }
        add(c, r, 10);
    }

    private String runPreset(String pk, int p, int sc, int fp) {
        switch (p) {
            case 1: return ShizukuHelper.applyGameMode(pk, "battery", null, null);
            case 2: return ShizukuHelper.applyGameMode(pk, "standard", null, null);
            case 3: return ShizukuHelper.applyGameMode(pk, "performance", null, null);
            case 4: return ShizukuHelper.applyGameMode(pk, "performance", SCALE_VAL[sc], FPS_VAL[fp]);
            default: return ShizukuHelper.resetGameMode(pk);
        }
    }

    private void applyPresetAsync(final String pk, final int p, final Runnable after) {
        if (pk == null) {
            toast("Game belum terpasang");
            if (after != null) after.run();
            return;
        }
        final int sc = Math.max(0, Math.min(SCALE_VAL.length - 1, pref().getInt("turbo_sc", 0)));
        final int fp = Math.max(0, Math.min(FPS_VAL.length - 1, pref().getInt("turbo_fp", 0)));
        final String sig = sigNow(pk);
        new Thread(() -> {
            final String r = runPreset(pk, p, sc, fp);
            final boolean ok = !ShizukuHelper.isError(r);
            runOnUiThread(() -> {
                if (ok) pref().edit().putString("turbo_a_" + pk, sig).apply();
                toast(ok ? "Preset " + PRESETS[p] + " dikirim ke Game Mode Android"
                        : "Gagal: " + r.replace("ERROR: ", ""));
                if (after != null) after.run(); else renderKeepScroll();
            });
        }, "gp-preset").start();
    }

    private void turboPlay() {
        final Game g = current();
        final String pk = pkgOf(g);
        final int p = presetOf(pk);
        boolean sz = ShizukuHelper.running() && ShizukuHelper.granted();
        String ap = pk == null ? null : pref().getString("turbo_a_" + pk, null);
        boolean need = pk != null && sz && ((p > 0 && !sigNow(pk).equals(ap)) || (p == 0 && ap != null && !ap.startsWith("0:")));
        if (need) applyPresetAsync(pk, p, this::startAndLaunch);
        else startAndLaunch();
    }

    private void startAndLaunch() {
        if (intentFor(current()) == null) {
            launch();
            return;
        }
        optimizeNow(false);
        start();
        launch();
    }

    private void optimizeNow(boolean manual) {
        if (manual || pref().getBoolean("auto_clean", true)) {
            final Game g = current();
            final String keep = pkgOf(g);
            final double before = DeviceInfo.ramAvailGb(this);
            new Thread(() -> {
                final int n = Optimizer.cleanRam(getApplicationContext(), keep);
                if (manual) {
                    handler.postDelayed(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        double after = DeviceInfo.ramAvailGb(this);
                        toast(String.format(Locale.US, "Diminta hentikan %d aplikasi latar. RAM tersedia %.1f → %.1f GB (hasil bergantung sistem).", n, before, after));
                        render();
                    }, 1500);
                }
            }, "gp-clean").start();
        }
        if (!manual && ShizukuHelper.granted()) {
            final String gp = pkgOf(current());
            final boolean kill = pref().getBoolean("sz_kill", true), res = pref().getBoolean("sz_res", false),
                    gm = pref().getBoolean("sz_gm", false),
                    hz = pref().getBoolean("sz_hz", true), idle = pref().getBoolean("sz_idle", true);
            final int hzTarget = DisplayProfile.target(this, pref());
            new Thread(() -> {
                String msg = "";
                if (kill) msg += ShizukuHelper.forceStop(Optimizer.userPackages(getApplicationContext(), gp)) + "\n";
                if (res) msg += ShizukuHelper.lowerResolution(pref(), 75) + "\n";
                if (hz) msg += ShizukuHelper.lockRefreshRate(pref(), hzTarget) + "\n";
                if (idle) msg += ShizukuHelper.boostApp(pref(), gp) + "\n";
                if (gm && gp != null) msg += "Game Mode: " + ShizukuHelper.gameModePerformance(gp);
                final String m = msg.trim();
                if (!m.isEmpty()) runOnUiThread(() -> toast(m));
            }).start();
        }
        if (pref().getBoolean("auto_dnd", false)) {
            if (!Optimizer.dndOn(this, pref())) toast("Izin Jangan Ganggu belum diberikan (Tools → Optimasi).");
        }
    }

    private void sessions() {
        title("SESSION LOG", "CATAT PERUBAHAN BATERAI DAN SUHU.");
        LinearLayout c = card("◷  ACTIVE SESSION");
        if (!store.active()) {
            add(c, text("Belum ada sesi aktif. Game terpilih: " + selected + ".", 13, MUTED, false), 10);
            button(c, "▶  MULAI SESI", true, this::start);
            button(c, "▶  MULAI & BUKA GAME", false, this::startAndLaunch);
        } else {
            add(c, text(store.activeGame() + "  /  " + store.activeMinutes() + " MENIT", 19, WHITE, true), 12);
            float peak = store.prefs().getFloat("peak", -1f);
            if (peak >= 0) {
                add(c, text("Suhu tertinggi terpantau: " + DeviceInfo.tempText(peak), 12, MUTED, false), 6);
            }
            if (store.prefs().getBoolean("gap", false)) {
                add(c, text("⚠ Pemantauan latar sempat terputus; suhu tertinggi/FPS mungkin tidak lengkap.", 12, AMBER, false), 6);
            }
            float fa = store.prefs().getFloat("fps_avg", -1f);
            if (fa >= 0 && store.prefs().getInt("fps_n", 0) >= 30) {
                add(c, text(String.format(Locale.US, "FPS rata-rata %.1f · 1%% low %.1f · jitter %.1f ms", fa,
                        store.prefs().getFloat("fps_low", -1f), store.prefs().getFloat("fps_jit", -1f)), 12, MUTED, false), 6);
            }
            button(c, "■  SELESAIKAN SESI", true, this::end);
            button(c, "▶  BUKA GAME", false, this::launch);
            button(c, "BATALKAN SESI (TANPA SIMPAN)", false, () ->
                    confirm("Batalkan sesi?", "Sesi aktif akan dibuang dan tidak masuk riwayat.", () -> {
                        store.discardActive();
                        ThermalService.stop(this);
                        OverlayService.stop(this);
                        Optimizer.dndOff(this, pref());
                        restoreScreen();
                        render();
                    }));
        }
        monitorCard();
        statsCard();
        historyCards();
    }

    private void monitorCard() {
        LinearLayout c = foldCard("monitor", "◉  PEMANTAUAN", true);
        float tc = DeviceInfo.tempC(this);
        float baseT = Float.isNaN(tc) ? 35f : tc;
        List<Float> trend = new ArrayList<>();
        trend.add(baseT - 0.6f);
        trend.add(baseT - 0.3f);
        trend.add(baseT - 0.4f);
        trend.add(baseT - 0.1f);
        trend.add(baseT + 0.1f);
        trend.add(baseT);
        TelemetryGraphView graph = new TelemetryGraphView(this);
        graph.setRange(25f, 52f, Float.isNaN(tc) ? AnimeTheme.ACCENT : Premium.tempColor(tc, Thresholds.warm(this), Thresholds.hot(this)));
        graph.setSamples(trend);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, dp(64));
        glp.topMargin = dp(10);
        c.addView(graph, glp);
        readingRow(c, "SUHU BATERAI", Readings.temp(this));
        readingRow(c, "THERMAL ANDROID", Readings.thermal(this));
        readingRow(c, "INDEKS THERMAL", Readings.headroom(this));
        readingRow(c, "FPS GAME", Readings.fps(pref(), store.active()));
        readingRow(c, "REFRESH RATE", Readings.refresh(this));
        readingRow(c, "RAM TERSEDIA", Readings.ram(this));
        add(c, text("TERUKUR = dibaca langsung dari API Android. PERKIRAAN = sampel/prakiraan. TIDAK TERSEDIA = tidak ada angka; alasannya ditampilkan.", 11, MUTED, false), 12);
    }

    private void readingRow(LinearLayout c, String label, Reading r) {
        LinearLayout box = col();
        LinearLayout line = row();
        line.addView(text(label, 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView v = text(r.value, 12, r.kind == Reading.Kind.UNAVAILABLE ? MUTED : WHITE, true);
        v.setGravity(Gravity.END);
        line.addView(v);
        box.addView(line, new LinearLayout.LayoutParams(-1, -2));
        int tagColor = r.kind == Reading.Kind.MEASURED ? GREEN : r.kind == Reading.Kind.ESTIMATED ? AMBER : MUTED;
        box.addView(text(r.tag() + (r.note.isEmpty() ? "" : " · " + r.note), 10, tagColor, false));
        add(c, box, 11);
    }

    private void statsCard() {
        SessionStore.Stats s = store.stats();
        LinearLayout c = foldCard("stats", "◔  RINGKASAN", false);
        kv(c, "TOTAL SESI", String.valueOf(s.count));
        kv(c, "TOTAL WAKTU", s.minutes / 60 + " j " + s.minutes % 60 + " m");
        kv(c, "RATA-RATA BATERAI", s.drainPerHour < 0 ? "Belum cukup data"
                : String.format(Locale.US, "%.1f%% / jam", s.drainPerHour));
        add(c, text("Rata-rata dihitung dari sesi \u2265 10 menit tanpa pengisian daya.", 11, MUTED, false), 12);
        if (store.historyRecovered()) {
            add(c, text("⚠ Berkas riwayat sebelumnya rusak; salinan mentahnya disimpan di perangkat (dihapus oleh Hapus riwayat).", 11, AMBER, false), 8);
        }
    }

    private void historyCards() {
        List<JSONObject> h = store.history();
        LinearLayout head = foldCard("history", "▥  SESSION HISTORY", false);
        if (h.isEmpty()) {
            add(head, text("Belum ada riwayat sesi.", 13, MUTED, false), 12);
            return;
        }
        add(head, text(h.size() + " sesi tersimpan (maks " + SessionStore.MAX_HISTORY + ").", 12, MUTED, false), 8);
        for (int i = 0; i < h.size() && i < HISTORY_SHOWN; i++) {
            TextView t = text(describe(h.get(i)), 13, WHITE, false);
            pad(t, 12, 11);
            t.setBackground(bg(0xFF1F0C0F, 12, 0xFF5A1D24));
            add(head, t, 10);
        }
        if (h.size() > HISTORY_SHOWN) {
            add(head, text("+ " + (h.size() - HISTORY_SHOWN) + " sesi lebih lama (ikut terekspor).", 11, MUTED, false), 10);
        }
        button(head, "BAGIKAN RIWAYAT", false, this::exportHistory);
        button(head, "HAPUS RIWAYAT", false, () ->
                confirm("Hapus riwayat?", "Semua riwayat sesi akan dihapus permanen dari perangkat ini.", () -> {
                    store.clearHistory();
                    render();
                }));
    }

    private void restoreScreen() {
        if (ShizukuHelper.pendingRestore(pref()) && ShizukuHelper.granted()) {
            new Thread(() -> ShizukuHelper.restoreAll(pref())).start();
        }
    }

    private void shizukuCard() {
        boolean run0 = ShizukuHelper.running(), ok0 = ShizukuHelper.granted();
        LinearLayout z = foldCard("shizuku", "⛓  MODE SHIZUKU (OPSIONAL)", ok0 ? "AKTIF" : run0 ? "IZIN?" : "OFF", ok0 ? GREEN : MUTED, false);
        boolean run = ShizukuHelper.running(), ok = ShizukuHelper.granted();
        add(z, text(!run ? "Shizuku belum berjalan. Buka aplikasi Shizuku lalu mulai lewat Wireless Debugging."
                : ok ? "Shizuku aktif & diizinkan." : "Shizuku berjalan, izin belum diberikan.", 13, ok ? GREEN : MUTED, false), 6);
        add(z, text("Layar: " + DisplayProfile.summary(this), 12, MUTED, false), 6);
        if (run && !ok) button(z, "BERI IZIN SHIZUKU", true, ShizukuHelper::requestPermission);
        if (ok) {
            toggle(z, "Hentikan paksa app latar saat Mulai & Buka Game", "sz_kill", true);
            toggle(z, "Turunkan resolusi layar ke 75% selama sesi", "sz_res", false);
            toggle(z, "Turunkan resolusi otomatis hanya saat HP panas (game bisa memuat ulang)", "sz_autores", false);
            toggle(z, "Game Mode Performance saat sesi (eksperimental; menimpa preset Turbo)", "sz_gm", false);
            toggle(z, "Kunci refresh rate layar ke maksimum selama sesi", "sz_hz", true);
            button(z, "TARGET REFRESH: " + DisplayProfile.targetLabel(this, pref()).toUpperCase(Locale.ROOT) + "  ▸", false, () -> {
                DisplayProfile.cycle(this, pref());
                renderKeepScroll();
            });
            add(z, text("Otomatis = refresh tertinggi panel. Bila game dikunci 60/120 FPS, pilih Hz kelipatannya (mis. 120 Hz untuk 60 atau 120 FPS) agar frame rata; 144 Hz cocok untuk 72/144 FPS.", 11, MUTED, false), 8);
            toggle(z, "Cegah game dibatasi Doze/standby selama sesi", "sz_idle", true);
            toggle(z, "Ukur FPS selama sesi (perkiraan)", "sz_fps", true);
            toggle(z, "FPS akurat: sampel ±tiap 1 detik (lebih boros baterai; mati = tiap 5 detik)", "fps_acc", true);
            button(z, "PULIHKAN PENGATURAN LAYAR & SISTEM", false, () -> new Thread(() -> {
                final String res = ShizukuHelper.restoreAll(pref());
                runOnUiThread(() -> toast(res));
            }).start());
            add(z, text("Semua perubahan (resolusi, refresh rate, whitelist) otomatis dikembalikan saat sesi selesai/dibatalkan. Bila layar terasa janggal, tekan Pulihkan.", 12, MUTED, false), 8);
        }
    }

    private void openGameTurbo() {
        try {
            Intent in = new Intent();
            in.setClassName("com.miui.securitycenter", "com.miui.gamebooster.ui.GameBoosterRealMainActivity");
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(in);
        } catch (Exception e) {
            toast("Game Turbo tidak ditemukan di HP ini. Cari di aplikasi Keamanan/Pengaturan.");
        }
    }

    private void tools() {
        title("CONTROL CENTER", "SHORTCUT PENGATURAN ANDROID.");
        LinearLayout o = foldCard("opt", "⚡  OPTIMASI PRA-MAIN", true);
        button(o, "BERSIHKAN RAM SEKARANG", true, () -> optimizeNow(true));
        toggle(o, "Bersihkan RAM otomatis saat Mulai & Buka Game", "auto_clean", true);
        toggle(o, "Jangan Ganggu (prioritas) selama sesi", "auto_dnd", false);
        toggle(o, "Pantau suhu di latar selama sesi", "svc_on", true);
        toggle(o, "Kapsul Overlay FPS & Suhu (HUD) di atas game", "hud_on", true);

        List<String> pl = new ArrayList<>();
        List<Runnable> pa = new ArrayList<>();
        if (!Optimizer.dndGranted(this)) {
            pl.add("IZIN\nJANGAN GANGGU");
            pa.add(() -> setting(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        }
        if (!OverlayService.canDraw(this)) {
            pl.add("IZIN\nOVERLAY");
            pa.add(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    toast("Buka Pengaturan → Aplikasi → GamePulse → Tampilkan di atas aplikasi lain");
                }
            });
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pl.add("IZIN\nNOTIFIKASI");
            pa.add(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7101));
        }
        if (!pl.isEmpty()) {
            add(o, text("Izin yang masih dibutuhkan:", 12, MUTED, false), 12);
            miniButtons(o, pl.toArray(new String[0]), pa.toArray(new Runnable[0]));
        }

        List<String> ql = new ArrayList<>();
        List<Runnable> qa = new ArrayList<>();
        if (OverlayService.canDraw(this)) {
            ql.add(OverlayService.isRunning ? "SEMBUNYIKAN\nKAPSUL HUD" : "TAMPILKAN\nKAPSUL HUD");
            qa.add(() -> {
                if (OverlayService.isRunning) {
                    OverlayService.stop(this);
                    toast("Kapsul HUD disembunyikan");
                } else {
                    pref().edit().putString("active_pkg", pkgOf(current())).apply();
                    OverlayService.start(this);
                    toast("Kapsul HUD FPS ditampilkan di pojok atas layar");
                }
                handler.postDelayed(this::render, 200);
            });
        }
        ql.add("GAME TURBO\n(XIAOMI)");
        qa.add(this::openGameTurbo);
        miniButtons(o, ql.toArray(new String[0]), qa.toArray(new Runnable[0]));
        add(o, text("Tanpa root. Tidak mengubah CPU/GPU/FPS.", 11, MUTED, false), 10);

        shizukuCard();

        LinearLayout c = foldCard("tuning", "☷  SAFE TUNING", false);
        miniButtons(c, new String[]{"LAYAR", "BATERAI"}, new Runnable[]{
                () -> setting(Settings.ACTION_DISPLAY_SETTINGS),
                () -> setting(Settings.ACTION_BATTERY_SAVER_SETTINGS)});
        miniButtons(c, new String[]{"NOTIFIKASI", "JARINGAN"}, new Runnable[]{
                () -> setting(Settings.ACTION_APP_NOTIFICATION_SETTINGS),
                () -> setting(Settings.ACTION_WIRELESS_SETTINGS)});
        miniButtons(c, new String[]{"REFRESH MONITOR"}, new Runnable[]{this::render});

        LinearLayout s = foldCard("prefs", "⚙  PREFERENSI", false);
        toggle(s, "Refresh otomatis tiap 30 detik", "auto_refresh", true);
        button(s, "AMBANG HANGAT: " + Thresholds.warm(this) + "°C  ▸", false, () -> { Thresholds.cycleWarm(this); renderKeepScroll(); });
        button(s, "AMBANG PANAS: " + Thresholds.hot(this) + "°C  ▸", false, () -> { Thresholds.cycleHot(this); renderKeepScroll(); });
        add(s, text("Ambang memakai suhu baterai (bukan CPU/GPU). Peringatan juga memakai status thermal Android: Sedang = hangat, Berat = panas.", 11, MUTED, false), 8);

        LinearLayout a = foldCard("about", "ⓘ  ABOUT", false);
        add(a, text("GamePulse v" + versionName(), 14, WHITE, true), 6);
        add(a, text("Pembersihan RAM memakai API resmi Android tanpa root. Hanya proses latar aplikasi non-sistem yang diminta berhenti; Android bisa menjalankannya lagi. Tidak mengubah CPU/GPU/FPS.",
                12, MUTED, false), 8);
        add(a, text("GamePulse tidak melakukan overclock, menghapus batas thermal, atau membuka batas FPS game. FPS hanya diukur (perkiraan) bila Shizuku aktif.",
                12, MUTED, false), 8);
        add(a, text("Privasi: tanpa izin internet, iklan, analitik, atau pelacakan. Semua catatan sesi disimpan lokal di perangkat dan hilang jika aplikasi dihapus.",
                12, MUTED, false), 8);
        safety();
    }

    private void start() {
        if (store.active()) {
            toast("Sesi masih aktif");
            return;
        }
        float t = DeviceInfo.tempC(this);
        store.start(selected, DeviceInfo.level(this), t);
        FpsMeter.reset(pref());
        pref().edit().putString("active_pkg", pkgOf(current())).apply();
        if (pref().getBoolean("svc_on", true)) ThermalService.start(this);
        if (pref().getBoolean("hud_on", true) && OverlayService.canDraw(this)) OverlayService.start(this);
        render();
    }

    private void end() {
        ThermalService.stop(this);
        OverlayService.stop(this);
        Optimizer.dndOff(this, pref());
        restoreScreen();
        if (store.finish(DeviceInfo.level(this), DeviceInfo.tempC(this), DeviceInfo.thermalText(this))) {
            toast("Sesi disimpan ke riwayat");
        }
        render();
    }

    private String tempOrNa(double v) {
        return v < 0 ? "N/A" : String.format(Locale.US, "%.1f°C", v);
    }

    private String describe(JSONObject o) {
        String legacy = o.optString("legacy", "");
        if (!legacy.isEmpty()) return "Riwayat lama (v0.3 / v0.4)\n" + legacy;
        StringBuilder sb = new StringBuilder();
        sb.append(new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID")).format(new Date(o.optLong("end", 0))));
        sb.append("\n").append(o.optString("game", "?")).append(" / ").append(o.optLong("min", 0)).append(" menit");
        int b0 = o.optInt("b0", -1);
        int b1 = o.optInt("b1", -1);
        sb.append("\nBaterai: ").append(b0 < 0 ? "N/A" : b0 + "%").append(" → ").append(b1 < 0 ? "N/A" : b1 + "%");
        sb.append("\nSuhu: ").append(tempOrNa(o.optDouble("t0", -1))).append(" → ").append(tempOrNa(o.optDouble("t1", -1)));
        double pk = o.optDouble("peak", -1);
        if (pk >= 0) sb.append("\nSuhu tertinggi terpantau: ").append(tempOrNa(pk));
        double fa = o.optDouble("fpsAvg", -1);
        if (fa >= 0) {
            sb.append(String.format(Locale.US, "\nFPS: rata-rata %.1f · 1%% low %.1f · jitter %.1f ms", fa,
                    o.optDouble("fpsLow", -1), o.optDouble("fpsJit", -1)));
        }
        sb.append("\nThermal akhir: ").append(o.optString("th", "N/A"));
        if (o.optBoolean("gap", false)) sb.append("\n⚠ Pemantauan latar sempat terputus (suhu tertinggi/FPS mungkin tidak lengkap)");
        return sb.toString();
    }

    private void exportHistory() {
        List<JSONObject> h = store.history();
        if (h.isEmpty()) {
            toast("Belum ada riwayat untuk dibagikan");
            return;
        }
        StringBuilder sb = new StringBuilder("Riwayat sesi GamePulse\n\n");
        for (JSONObject o : h) sb.append(describe(o)).append("\n\n");
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_SUBJECT, "Riwayat GamePulse");
        s.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        try {
            startActivity(Intent.createChooser(s, "Bagikan riwayat"));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membagikan.");
        }
    }

    private void setting(String action) {
        try {
            startActivity(new Intent(action).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
        } catch (Exception e) {
            toast("Pengaturan tidak tersedia");
        }
    }

    private void refreshVisibleStats() {
        if (!"home".equals(tab) && !"sessions".equals(tab)) return;
        if (scroll == null) return;
        store.trackPeak(DeviceInfo.tempC(this));
        final int y = scroll.getScrollY();
        render();
        if (scroll != null) scroll.post(() -> scroll.scrollTo(0, y));
    }
}
