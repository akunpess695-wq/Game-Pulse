package id.gamepulse.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.util.Locale;

/**
 * Layanan latar (foreground) yang hanya hidup selama sesi bermain aktif.
 * Memantau suhu baterai + status thermal, mencatat suhu puncak, dan menampilkan peringatan panas.
 * Berhenti sendiri saat sesi selesai/dibatalkan. Tanpa jaringan.
 */
public final class ThermalService extends Service {
    private static final String CH_RUN = "gp_session", CH_ALERT = "gp_alert";
    private static final int ID_RUN = 7001, ID_ALERT = 7002;
    private static final long TICK_MS = 15000L, ALERT_GAP_MS = 180000L;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SessionStore store;
    private long lastAlert;
    private boolean resApplied;

    static void start(Context c) {
        try {
            c.startForegroundService(new Intent(c, ThermalService.class));
        } catch (Exception ignored) {
            // dilarang sistem (mis. pembatasan latar): sesi tetap jalan tanpa pemantau latar
        }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, ThermalService.class)); } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        store = new SessionStore(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CH_RUN, "Pemantau sesi", NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Peringatan panas", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        Notification n = runNotification("Memantau suhu…");
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(ID_RUN, n);
        h.removeCallbacks(tick);
        h.post(tick);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(tick);
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!store.active()) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
                return;
            }
            float t = DeviceInfo.tempC(ThermalService.this);
            store.trackPeak(t);
            int heat = heatNow(t);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(ID_RUN, runNotification(summary(t)));
            if (heat == 2) onHot(t, nm);
            h.postDelayed(this, TICK_MS);
        }
    };

    /** 0 aman, 1 hangat, 2 panas. Menambahkan indeks thermal Android (API 30+) ke aturan DeviceInfo. */
    private int heatNow(float t) {
        int lvl = DeviceInfo.heatLevel(this);
        float hr = headroom();
        if (!Float.isNaN(hr) && hr >= 0.95f) return 2;
        if (!Float.isNaN(hr) && hr >= 0.8f) return Math.max(lvl, 1);
        return lvl;
    }

    /** Indeks thermal perkiraan 10 detik ke depan (1.0 = batas throttling berat), atau NaN bila tak tersedia. */
    private float headroom() {
        if (Build.VERSION.SDK_INT < 30) return Float.NaN;
        try {
            PowerManager pm = getSystemService(PowerManager.class);
            return pm == null ? Float.NaN : pm.getThermalHeadroom(10);
        } catch (Throwable e) {
            return Float.NaN;
        }
    }

    private String summary(float t) {
        StringBuilder sb = new StringBuilder();
        sb.append(store.activeGame()).append(" · ").append(store.activeMinutes()).append(" mnt · ")
                .append(DeviceInfo.tempText(t)).append(" · Thermal ").append(DeviceInfo.thermalText(this));
        float hr = headroom();
        if (!Float.isNaN(hr)) sb.append(String.format(Locale.US, " · indeks %.0f%%", hr * 100f));
        return sb.toString();
    }

    private void onHot(float t, NotificationManager nm) {
        long now = System.currentTimeMillis();
        if (nm != null && now - lastAlert >= ALERT_GAP_MS) {
            lastAlert = now;
            Notification a = new Notification.Builder(this, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_nav_tools)
                    .setContentTitle("HP mulai panas")
                    .setContentText(DeviceInfo.tempText(t) + " · Thermal " + DeviceInfo.thermalText(this)
                            + ". Turunkan grafis, lepas casing, jeda sebentar.")
                    .setStyle(new Notification.BigTextStyle().bigText(DeviceInfo.tempText(t) + " · Thermal "
                            + DeviceInfo.thermalText(this) + ". Turunkan grafis/FPS di game, lepas casing, "
                            + "hentikan pengisian daya, atau jeda beberapa menit."))
                    .setContentIntent(openApp())
                    .setAutoCancel(true)
                    .build();
            nm.notify(ID_ALERT, a);
        }
        // Opsional (default mati): turunkan resolusi sekali saat panas. Dipulihkan otomatis saat sesi berakhir.
        if (!resApplied && store.prefs().getBoolean("sz_autores", false) && ShizukuHelper.granted()
                && !ShizukuHelper.resolutionChanged(store.prefs())) {
            resApplied = true;
            new Thread(() -> ShizukuHelper.lowerResolution(store.prefs(), 75)).start();
        }
    }

    private PendingIntent openApp() {
        Intent in = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, in, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification runNotification(String text) {
        return new Notification.Builder(this, CH_RUN)
                .setSmallIcon(R.drawable.ic_nav_tools)
                .setContentTitle("GamePulse memantau sesi")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp())
                .build();
    }
}
