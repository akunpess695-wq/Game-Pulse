package id.gamepulse.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final int BG = 0xFF07070A, PANEL = 0xFF141418, RED = 0xFFFF2948, WHITE = 0xFFF7F7F9,
            MUTED = 0xFF9B9AA5, GREEN = 0xFF75E0A9, AMBER = 0xFFFFB84D;
    private static final String EF = "eFootball", MH = "Monster Hunter Outlanders";
    private static final String EF_PKG = "jp.konami.pesam";
    private static final long REFRESH_MS = 30000L;
    private static final int HISTORY_SHOWN = 15;

    private SessionStore store;
    private LinearLayout root, body, nav;
    private ScrollView scroll;
    private String selected = EF, tab = "home";
    private int insL, insT, insR, insB;
    private final Map<String, Boolean> installedCache = new HashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (!isFinishing() && !isDestroyed()) {
                if (hasWindowFocus() && pref().getBoolean("auto_refresh", true)) refreshVisibleStats();
                handler.postDelayed(this, REFRESH_MS);
            }
        }
    };

    // ------------------------------------------------------------------ siklus hidup

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        store = new SessionStore(this);
        if (b != null) tab = b.getString("tab", "home");
        selected = pref().getString("selected", EF);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        render();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("tab", tab);
    }

    @Override protected void onResume() {
        super.onResume();
        installedCache.clear();
        store.trackPeak(DeviceInfo.tempC(this));
        handler.removeCallbacks(refresh);
        render();
        handler.postDelayed(refresh, REFRESH_MS);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (!"home".equals(tab)) {
            tab = "home";
            render();
        } else {
            super.onBackPressed();
        }
    }

    // ------------------------------------------------------------------ helper UI

    private SharedPreferences pref() { return store.prefs(); }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable gradient(int c1, int c2, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return t;
    }

    private void add(LinearLayout p, View v, int mt) {
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(-1, -2);
        a.topMargin = dp(mt);
        p.addView(v, a);
    }

    private void pad(View v, int h, int vert) { v.setPadding(dp(h), dp(vert), dp(h), dp(vert)); }

    private LinearLayout card(String title) {
        LinearLayout c = col();
        pad(c, 15, 16);
        c.setBackground(bg(PANEL, 19, 0xFF3D2027));
        add(body, c, 13);
        if (title != null) add(c, text(title, 16, WHITE, true), 0);
        return c;
    }

    private void title(String s, String subtitle) {
        add(body, text(s, 28, WHITE, true), 16);
        add(body, text(subtitle, 12, MUTED, false), 4);
    }

    private ImageView image(int id) {
        ImageView v = new ImageView(this);
        v.setImageResource(id);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(bg(PANEL, 14, 0));
        v.setClipToOutline(true);
        return v;
    }

    private void button(LinearLayout parent, String label, boolean red, Runnable run) {
        TextView t = text(label, 15, WHITE, true);
        t.setGravity(Gravity.CENTER);
        pad(t, 12, 14);
        t.setMinHeight(dp(48));
        t.setBackground(red ? gradient(0xFFBE102B, RED, 13) : bg(0xFF24242B, 13, 0xFF3B343D));
        add(parent, t, 10);
        t.setOnClickListener(v -> run.run());
    }

    private void kv(LinearLayout c, String key, String value) {
        LinearLayout r = row();
        r.addView(text(key, 12, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView v = text(value, 12, WHITE, true);
        v.setGravity(Gravity.END);
        r.addView(v);
        add(c, r, 11);
    }

    private void stat(LinearLayout r, String icon, String value, String label) {
        LinearLayout box = col();
        box.setGravity(Gravity.CENTER);
        pad(box, 3, 12);
        box.setBackground(bg(0xFF202025, 13, 0xFF39262C));
        TextView a = text(icon + "  " + value, 16, WHITE, true);
        a.setGravity(Gravity.CENTER);
        add(box, a, 0);
        TextView b = text(label, 10, MUTED, false);
        b.setGravity(Gravity.CENTER);
        add(box, b, 4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = dp(5);
        r.addView(box, lp);
    }

    private void toggle(LinearLayout c, String label, String key, boolean def) {
        final boolean on = pref().getBoolean(key, def);
        LinearLayout r = row();
        r.setMinimumHeight(dp(48));
        r.addView(text(label, 13, WHITE, false), new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(text(on ? "AKTIF" : "MATI", 12, on ? GREEN : MUTED, true));
        r.setOnClickListener(v -> {
            pref().edit().putBoolean(key, !on).apply();
            render();
        });
        add(c, r, 6);
    }

    private void confirm(String title, String msg, Runnable yes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("Ya", (d, w) -> yes.run())
                .setNegativeButton("Batal", null)
                .show();
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.0.0";
        }
    }

    // ------------------------------------------------------------------ rangka layar

    private void render() {
        root = col();
        root.setBackgroundColor(BG);
        ScrollView sc = new ScrollView(this);
        scroll = sc;
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        body = col();
        pad(body, 17, 20);
        sc.addView(body);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        header();
        switch (tab) {
            case "games": games(); break;
            case "sessions": sessions(); break;
            case "tools": tools(); break;
            default: home();
        }
        navigation();
        root.setOnApplyWindowInsetsListener((v, w) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = w.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                insL = i.left; insT = i.top; insR = i.right; insB = i.bottom;
            } else {
                insL = w.getSystemWindowInsetLeft(); insT = w.getSystemWindowInsetTop();
                insR = w.getSystemWindowInsetRight(); insB = w.getSystemWindowInsetBottom();
            }
            applyInsets();
            return w;
        });
        applyInsets();
        setContentView(root);
        root.requestApplyInsets();
    }

    private void applyInsets() {
        if (root != null) root.setPadding(insL, insT, insR, 0);
        if (nav != null) nav.setPadding(dp(7), dp(8), dp(7), dp(9) + insB);
    }

    private void header() {
        LinearLayout h = row();
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setContentDescription("Logo GamePulse");
        h.addView(logo, new LinearLayout.LayoutParams(dp(45), dp(45)));
        LinearLayout names = col();
        add(names, text("GAMEPULSE", 23, WHITE, true), 0);
        add(names, text("V" + versionName() + "  /  REDLINE EXTREME", 10, RED, true), 0);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, -2, 1);
        np.leftMargin = dp(8);
        h.addView(names, np);
        boolean live = pref().getBoolean("auto_refresh", true);
        h.addView(text(live ? "● LIVE" : "○ MANUAL", 11, live ? GREEN : MUTED, true));
        add(body, h, 0);
    }

    private void navigation() {
        nav = row();
        nav.setBackground(bg(0xFF101014, 0, 0));
        String[] ids = {"home", "games", "sessions", "tools"};
        String[] labels = {"⌂\nHOME", "♧\nGAMES", "▥\nSESSIONS", "⚙\nTOOLS"};
        String[] desc = {"Beranda", "Game", "Sesi", "Alat"};
        for (int i = 0; i < ids.length; i++) {
            final String id = ids[i];
            TextView t = text(labels[i], 11, tab.equals(id) ? RED : MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setContentDescription(desc[i]);
            pad(t, 2, 10);
            t.setMinHeight(dp(48));
            if (tab.equals(id)) t.setBackground(bg(0xFF3A101A, 13, 0xFF68202E));
            nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            t.setOnClickListener(v -> {
                tab = id;
                render();
            });
        }
        root.addView(nav);
    }

    // ------------------------------------------------------------------ data game

    private static final class Game {
        final String name, sub, pkg;
        final String[] keywords;
        final int banner;

        Game(String name, String sub, String pkg, String[] keywords, int banner) {
            this.name = name;
            this.sub = sub;
            this.pkg = pkg;
            this.keywords = keywords;
            this.banner = banner;
        }
    }

    private List<Game> gameList() {
        List<Game> l = new ArrayList<>();
        l.add(new Game(EF, "RESPONS KONTROL  /  KONEKSI", EF_PKG, null, R.drawable.banner_football));
        l.add(new Game(MH, "FRAME PACING  /  THERMAL", null, new String[]{"monster hunter", "outlanders"},
                R.drawable.banner_hunter));
        String cp = pref().getString("custom_pkg", "");
        String cn = pref().getString("custom_name", "");
        if (!cp.isEmpty() && !cn.isEmpty() && !cp.equals(EF_PKG)) {
            l.add(new Game(cn, "GAME PILIHAN SAYA", cp, null, 0));
        }
        return l;
    }

    private Game current() {
        List<Game> l = gameList();
        for (Game g : l) if (g.name.equals(selected)) return g;
        selected = EF;
        return l.get(0);
    }

    private Intent intentFor(Game g) {
        PackageManager pm = getPackageManager();
        if (g.pkg != null) return pm.getLaunchIntentForPackage(g.pkg);
        if (g.keywords == null) return null;
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null) continue;
            String label = String.valueOf(i.loadLabel(pm)).toLowerCase(Locale.ROOT);
            boolean all = true;
            for (String k : g.keywords) if (!label.contains(k)) all = false;
            if (all) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(i.activityInfo.packageName, i.activityInfo.name);
                return launch;
            }
        }
        return null;
    }

    private boolean installed(Game g) {
        Boolean b = installedCache.get(g.name);
        if (b == null) {
            b = intentFor(g) != null;
            installedCache.put(g.name, b);
        }
        return b;
    }

    private void select(String name) {
        selected = name;
        pref().edit().putString("selected", name).apply();
    }

    private void launch() {
        Game g = current();
        Intent in = intentFor(g);
        if (in == null) {
            if (g.pkg != null) {
                toast(g.name + " belum terpasang. Membuka Play Store.");
                openStore(g.pkg);
            } else {
                toast(g.name + " tidak ditemukan. Buka dari launcher HP.");
            }
            return;
        }
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(in);
        } catch (Exception ex) {
            toast("Tidak dapat membuka game; coba dari launcher HP.");
        }
    }

    private void openStore(String pkg) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg)));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + pkg)));
            } catch (Exception e2) {
                toast("Play Store tidak tersedia.");
            }
        }
    }

    private void pickGame() {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        final List<String[]> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null) continue;
            String pkg = i.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new String[]{String.valueOf(i.loadLabel(pm)), pkg});
        }
        if (apps.isEmpty()) {
            toast("Tidak ada aplikasi yang bisa dipilih.");
            return;
        }
        Collections.sort(apps, (x, y) -> x[0].compareToIgnoreCase(y[0]));
        CharSequence[] labels = new CharSequence[apps.size()];
        for (int k = 0; k < labels.length; k++) labels[k] = apps.get(k)[0];
        new AlertDialog.Builder(this)
                .setTitle("Pilih game / aplikasi")
                .setItems(labels, (d, which) -> {
                    String[] a = apps.get(which);
                    pref().edit().putString("custom_name", a[0]).putString("custom_pkg", a[1]).apply();
                    select(a[0]);
                    installedCache.clear();
                    render();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // ------------------------------------------------------------------ bagian layar

    private void hero() {
        FrameLayout frame = new FrameLayout(this);
        ImageView im = image(R.drawable.hero_redline);
        im.setContentDescription("Banner GamePulse");
        frame.addView(im, new FrameLayout.LayoutParams(-1, dp(170)));
        LinearLayout words = col();
        words.setPadding(dp(16), dp(24), dp(12), 0);
        add(words, text("GAMING.", 29, WHITE, true), 0);
        add(words, text("TANPA GIMMICK.", 26, RED, true), 0);
        add(words, text("MONITOR  /  LAUNCH  /  ANALYZE", 11, WHITE, true), 9);
        frame.addView(words);
        add(body, frame, 15);
    }

    private void alerts() {
        int heat = DeviceInfo.heatLevel(this);
        int lv = DeviceInfo.level(this);
        boolean chg = DeviceInfo.charging(this);
        String msg = null;
        int color = AMBER;
        if (heat == 2) {
            msg = "⚠  Perangkat panas. Istirahatkan game, lepas casing, dan hindari mengisi daya sambil bermain.";
            color = RED;
        } else if (heat == 1) {
            msg = "◔  Perangkat mulai hangat. Pantau suhu dan turunkan grafis bila perlu.";
        } else if (lv >= 0 && lv <= 15 && !chg) {
            msg = "▰  Baterai rendah (" + lv + "%). Hubungkan charger sebelum sesi panjang.";
        }
        if (msg == null) return;
        TextView t = text(msg, 13, WHITE, false);
        pad(t, 14, 12);
        t.setBackground(bg(0xFF1A1114, 14, color));
        add(body, t, 13);
    }

    private void device() {
        LinearLayout c = card("⌁  STATUS PERANGKAT");
        LinearLayout stats = row();
        int lv = DeviceInfo.level(this);
        stat(stats, "▰", lv < 0 ? "N/A" : lv + "%", DeviceInfo.charging(this) ? "MENGISI" : "BATERAI");
        stat(stats, "♨", DeviceInfo.tempText(DeviceInfo.tempC(this)), "SUHU BATERAI");
        stat(stats, "✧", DeviceInfo.thermalText(this), "THERMAL");
        add(c, stats, 13);
        kv(c, "SISTEM", "ANDROID " + Build.VERSION.RELEASE);
        kv(c, "PERANGKAT", Build.MANUFACTURER.toUpperCase(Locale.ROOT) + " " + Build.MODEL);
        kv(c, "RAM TERSEDIA", DeviceInfo.ram(this));
        kv(c, "JARINGAN", DeviceInfo.network(this));
    }

    private void gameCard(LinearLayout c, Game g) {
        boolean chosen = selected.equals(g.name);
        LinearLayout wrap = col();
        wrap.setBackground(bg(chosen ? 0xFF32121B : 0xFF1C1C22, 14, chosen ? RED : 0xFF39333A));
        wrap.setPadding(dp(3), dp(3), dp(3), dp(9));
        if (g.banner != 0) {
            ImageView im = image(g.banner);
            im.setContentDescription("Banner " + g.name);
            wrap.addView(im, new LinearLayout.LayoutParams(-1, dp(90)));
        } else {
            String ini = g.name.isEmpty() ? "?" : g.name.substring(0, 1).toUpperCase(Locale.ROOT);
            TextView t = text(ini, 30, WHITE, true);
            t.setGravity(Gravity.CENTER);
            t.setBackground(gradient(0xFF2A1218, 0xFF5A1422, 12));
            wrap.addView(t, new LinearLayout.LayoutParams(-1, dp(70)));
        }
        LinearLayout r = row();
        r.setPadding(dp(9), dp(9), dp(9), 0);
        LinearLayout info = col();
        add(info, text(g.name, 17, WHITE, true), 0);
        boolean ok = installed(g);
        add(info, text(g.sub + "  /  " + (ok ? "TERPASANG" : "BELUM TERPASANG"), 10,
                ok ? (chosen ? 0xFFFF9DAB : MUTED) : AMBER, false), 3);
        r.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView play = text(ok ? "▶  PLAY" : "⇩  GET", 12, WHITE, true);
        pad(play, 10, 10);
        play.setMinHeight(dp(40));
        play.setGravity(Gravity.CENTER);
        play.setBackground(gradient(0xFFAA0F28, RED, 10));
        r.addView(play);
        play.setOnClickListener(v -> {
            select(g.name);
            launch();
        });
        add(wrap, r, 0);
        add(c, wrap, 11);
        wrap.setOnClickListener(v -> {
            select(g.name);
            render();
        });
    }

    private void library() {
        LinearLayout c = card("⚔  GAME PROFILES");
        for (Game g : gameList()) gameCard(c, g);
    }

    private void shortcuts() {
        LinearLayout c = card("⌘  QUICK TOOLS");
        LinearLayout r = row();
        String[] names = {"◉\nMONITOR", "▥\nSESI", "☷\nTUNING"};
        for (int i = 0; i < 3; i++) {
            final int j = i;
            TextView t = text(names[i], 13, WHITE, true);
            t.setGravity(Gravity.CENTER);
            pad(t, 3, 14);
            t.setBackground(bg(0xFF242027, 12, 0xFF573039));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.rightMargin = dp(7);
            r.addView(t, lp);
            t.setOnClickListener(v -> {
                tab = j == 0 ? "home" : j == 1 ? "sessions" : "tools";
                render();
            });
        }
        add(c, r, 11);
    }

    private void baseline() {
        Game g = current();
        LinearLayout c = card("◎  RECOMMENDED BASELINE");
        add(c, text(g.name.toUpperCase(Locale.ROOT), 13, RED, true), 10);
        if (g.name.equals(EF)) {
            kv(c, "GRAFIS", "STANDARD");
            kv(c, "FRAME RATE", "60 JIKA TERSEDIA");
            kv(c, "KONEKSI", "WI-FI STABIL");
        } else if (g.name.equals(MH)) {
            kv(c, "GRAFIS", "LOW");
            kv(c, "FRAME RATE", "30 SEBAGAI BASELINE");
            kv(c, "BAYANGAN / EFEK", "RENDAH");
        } else {
            kv(c, "GRAFIS", "MULAI DARI MENENGAH");
            kv(c, "FRAME RATE", "SESUAI KEMAMPUAN HP");
            kv(c, "KONEKSI", "WI-FI STABIL");
        }
        add(c, text("Rekomendasi manual; bukan perubahan performa sistem atau FPS terukur.", 11, MUTED, false), 13);
        button(c, "▶  BUKA " + g.name.toUpperCase(Locale.ROOT), true, this::launch);
    }

    private void safety() {
        LinearLayout c = card("◈  GAMING CHECKLIST");
        kv(c, "MODE HEMAT BATERAI", "Nonaktifkan saat uji FPS");
        kv(c, "SUHU PERANGKAT", "Hentikan jika terlalu panas");
        kv(c, "FPS AKTUAL", "Tidak diukur oleh GamePulse");
        add(c, text("Gunakan pengaturan grafis resmi game. Jangan mengubah file game atau menonaktifkan perlindungan thermal.",
                12, MUTED, false), 12);
    }

    // ------------------------------------------------------------------ tab

    private void home() {
        hero();
        alerts();
        device();
        library();
        shortcuts();
        baseline();
        safety();
    }

    private void games() {
        title("GAME LIBRARY", "PILIH GAME. SIAPKAN PROFIL. MAIN.");
        library();
        LinearLayout c = card("＋  GAME LAIN");
        add(c, text("Tambahkan satu game atau aplikasi lain dari yang terpasang di HP.", 12, MUTED, false), 8);
        button(c, "PILIH DARI APLIKASI TERPASANG", false, this::pickGame);
        if (!pref().getString("custom_pkg", "").isEmpty()) {
            button(c, "HAPUS GAME PILIHAN", false, () -> {
                pref().edit().remove("custom_pkg").remove("custom_name").apply();
                if (!selected.equals(EF) && !selected.equals(MH)) select(EF);
                render();
            });
        }
        baseline();
    }

    private void startAndLaunch() {
        if (intentFor(current()) == null) {
            launch(); // menampilkan pesan / membuka Play Store
            return;
        }
        start();
        launch();
    }

    private void sessions() {
        title("SESSION LOG", "CATAT PERUBAHAN BATERAI DAN SUHU.");
        LinearLayout c = card("◷  ACTIVE SESSION");
        if (!store.active()) {
            add(c, text("Belum ada sesi aktif. Game terpilih: " + selected + ".", 13, MUTED, false), 10);
            button(c, "▶  MULAI SESI", true, this::start);
            button(c, "▶  MULAI & BUKA GAME", false, this::startAndLaunch);
        } else {
            add(c, text(store.activeGame() + "  /  " + store.activeMinutes() + " MENIT", 19, WHITE, true), 12);
            float peak = store.prefs().getFloat("peak", -1f);
            if (peak >= 0) {
                add(c, text("Suhu tertinggi terpantau: " + DeviceInfo.tempText(peak), 12, MUTED, false), 6);
            }
            button(c, "■  SELESAIKAN SESI", true, this::end);
            button(c, "▶  BUKA GAME", false, this::launch);
            button(c, "BATALKAN SESI (TANPA SIMPAN)", false, () ->
                    confirm("Batalkan sesi?", "Sesi aktif akan dibuang dan tidak masuk riwayat.", () -> {
                        store.discardActive();
                        render();
                    }));
        }
        statsCard();
        historyCards();
    }

    private void statsCard() {
        SessionStore.Stats s = store.stats();
        LinearLayout c = card("◔  RINGKASAN");
        kv(c, "TOTAL SESI", String.valueOf(s.count));
        kv(c, "TOTAL WAKTU", s.minutes / 60 + " j " + s.minutes % 60 + " m");
        kv(c, "RATA-RATA BATERAI", s.drainPerHour < 0 ? "Belum cukup data"
                : String.format(Locale.US, "%.1f%% / jam", s.drainPerHour));
        add(c, text("Rata-rata dihitung dari sesi \u2265 10 menit tanpa pengisian daya.", 11, MUTED, false), 12);
    }

    private void historyCards() {
        List<JSONObject> h = store.history();
        LinearLayout head = card("▥  SESSION HISTORY");
        if (h.isEmpty()) {
            add(head, text("Belum ada riwayat sesi.", 13, MUTED, false), 12);
            return;
        }
        add(head, text(h.size() + " sesi tersimpan (maks " + SessionStore.MAX_HISTORY + ").", 12, MUTED, false), 8);
        for (int i = 0; i < h.size() && i < HISTORY_SHOWN; i++) {
            TextView t = text(describe(h.get(i)), 13, WHITE, false);
            pad(t, 12, 11);
            t.setBackground(bg(0xFF1C1C22, 12, 0xFF39333A));
            add(head, t, 10);
        }
        if (h.size() > HISTORY_SHOWN) {
            add(head, text("+ " + (h.size() - HISTORY_SHOWN) + " sesi lebih lama (ikut terekspor).", 11, MUTED, false), 10);
        }
        button(head, "BAGIKAN RIWAYAT", false, this::exportHistory);
        button(head, "HAPUS RIWAYAT", false, () ->
                confirm("Hapus riwayat?", "Semua riwayat sesi akan dihapus permanen dari perangkat ini.", () -> {
                    store.clearHistory();
                    render();
                }));
    }

    private void tools() {
        title("CONTROL CENTER", "SHORTCUT PENGATURAN ANDROID.");
        LinearLayout c = card("☷  SAFE TUNING");
        button(c, "PENGATURAN LAYAR", false, () -> setting(Settings.ACTION_DISPLAY_SETTINGS));
        button(c, "PENGATURAN BATERAI", false, () -> setting(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        button(c, "PENGATURAN NOTIFIKASI", false, () -> setting(Settings.ACTION_APP_NOTIFICATION_SETTINGS));
        button(c, "PENGATURAN JARINGAN", false, () -> setting(Settings.ACTION_WIRELESS_SETTINGS));
        button(c, "REFRESH MONITOR", false, this::render);

        LinearLayout s = card("⚙  PREFERENSI");
        toggle(s, "Refresh otomatis tiap 30 detik", "auto_refresh", true);

        LinearLayout a = card("ⓘ  ABOUT");
        add(a, text("GamePulse v" + versionName(), 14, WHITE, true), 10);
        add(a, text("GamePulse tidak melakukan overclock, menghapus batas thermal, menutup aplikasi lain, atau mengukur FPS game secara langsung. Profil hanya saran manual.",
                13, MUTED, false), 8);
        add(a, text("Privasi: tanpa izin internet, iklan, analitik, atau pelacakan. Semua catatan sesi disimpan lokal di perangkat dan hilang jika aplikasi dihapus.",
                13, MUTED, false), 10);
    }

    // ------------------------------------------------------------------ sesi & riwayat

    private void start() {
        if (store.active()) {
            toast("Sesi masih aktif");
            return;
        }
        float t = DeviceInfo.tempC(this);
        store.start(selected, DeviceInfo.level(this), t);
        render();
    }

    private void end() {
        if (store.finish(DeviceInfo.level(this), DeviceInfo.tempC(this), DeviceInfo.thermalText(this))) {
            toast("Sesi disimpan ke riwayat");
        }
        render();
    }

    private String tempOrNa(double v) {
        return v < 0 ? "N/A" : String.format(Locale.US, "%.1f°C", v);
    }

    private String describe(JSONObject o) {
        String legacy = o.optString("legacy", "");
        if (!legacy.isEmpty()) return "Riwayat lama (v0.3 / v0.4)\n" + legacy;
        StringBuilder sb = new StringBuilder();
        sb.append(new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID")).format(new Date(o.optLong("end", 0))));
        sb.append("\n").append(o.optString("game", "?")).append(" / ").append(o.optLong("min", 0)).append(" menit");
        int b0 = o.optInt("b0", -1);
        int b1 = o.optInt("b1", -1);
        sb.append("\nBaterai: ").append(b0 < 0 ? "N/A" : b0 + "%").append(" → ").append(b1 < 0 ? "N/A" : b1 + "%");
        sb.append("\nSuhu: ").append(tempOrNa(o.optDouble("t0", -1))).append(" → ").append(tempOrNa(o.optDouble("t1", -1)));
        double pk = o.optDouble("peak", -1);
        if (pk >= 0) sb.append("\nSuhu tertinggi terpantau: ").append(tempOrNa(pk));
        sb.append("\nThermal akhir: ").append(o.optString("th", "N/A"));
        return sb.toString();
    }

    private void exportHistory() {
        List<JSONObject> h = store.history();
        if (h.isEmpty()) {
            toast("Belum ada riwayat untuk dibagikan");
            return;
        }
        StringBuilder sb = new StringBuilder("Riwayat sesi GamePulse\n\n");
        for (JSONObject o : h) sb.append(describe(o)).append("\n\n");
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_SUBJECT, "Riwayat GamePulse");
        s.putExtra(Intent.EXTRA_TEXT, sb.toString().trim());
        try {
            startActivity(Intent.createChooser(s, "Bagikan riwayat"));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membagikan.");
        }
    }

    private void setting(String action) {
        try {
            startActivity(new Intent(action).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
        } catch (Exception e) {
            toast("Pengaturan tidak tersedia");
        }
    }

    private void refreshVisibleStats() {
        if (!"home".equals(tab) && !"sessions".equals(tab)) return;
        if (scroll == null) return;
        store.trackPeak(DeviceInfo.tempC(this));
        final int y = scroll.getScrollY();
        render();
        if (scroll != null) scroll.post(() -> scroll.scrollTo(0, y));
    }
}
