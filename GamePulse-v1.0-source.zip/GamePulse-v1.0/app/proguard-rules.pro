# GamePulse hanya memakai API platform Android (tanpa library pihak ketiga).
# Tidak ada aturan keep tambahan yang diperlukan.
