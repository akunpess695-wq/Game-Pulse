# Checklist uji di perangkat (belum dijalankan — wajib sebelum dibagikan luas)

Perangkat utama: Redmi Note 12 Pro 5G. Bila ada, uji juga satu HP Android 10–12.

- [ ] Instal APK rilis; ikon GP tampil benar (bentuk bulat/kotak).
- [ ] Android 15: konten tidak tertutup status bar & navigation bar; gesture back berfungsi.
- [ ] Beranda: baterai, suhu, thermal, RAM, jaringan terisi; "LIVE" memperbarui tiap 30 dtk tanpa lompat scroll.
- [ ] Banner eFootball & Monster Hunter tampil tinggi ±90dp, tidak membesar.
- [ ] Tombol PLAY membuka eFootball (jp.konami.pesam) dan Monster Hunter Outlanders.
- [ ] Game belum terpasang → muncul GET dan membuka Play Store.
- [ ] Games → "Pilih dari aplikasi terpasang" → game tampil, bisa dibuka, bisa dihapus.
- [ ] Mulai sesi → tutup app → buka lagi → durasi berjalan; selesaikan → muncul di riwayat.
- [ ] Batalkan sesi tidak menambah riwayat.
- [ ] Update dari v0.4 (tanda tangan sama): riwayat lama muncul sebagai "Riwayat lama".
- [ ] Bagikan riwayat membuka share sheet; hapus riwayat meminta konfirmasi.
- [ ] Tombol Back: Games/Sessions/Tools → Beranda → keluar.
- [ ] Putar layar: tidak crash, layout tetap terbaca.
- [ ] TalkBack: navigasi bawah dan logo terbaca.
