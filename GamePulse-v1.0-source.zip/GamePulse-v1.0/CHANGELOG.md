# Changelog

## 1.0.0 — Rilis penuh
### Baru
- Ikon adaptif (Android 8+) dengan logo GP.
- Daftar game fleksibel (maks 12 pilihan): deteksi game otomatis atau pilih manual dari aplikasi terpasang; hapus per game.
- Profil per jenis game (MOBA, strategi, sepak bola, Monster Hunter, battle royale, umum) dengan tips.
- Kartu "Kesiapan Main": baterai, suhu, RAM, jaringan.
- Tombol Info Aplikasi per game (baterai/izin).
- Status "TERPASANG / BELUM TERPASANG" per game; tombol GET membuka Play Store bila belum terpasang.
- Peringatan panas & baterai rendah di Beranda (dari status thermal Android dan suhu baterai).
- Indikator pengisian daya, suhu tertinggi yang terpantau selama sesi, dan tombol batalkan sesi.
- Ringkasan sesi: total sesi, total waktu, rata-rata pemakaian baterai per jam.
- Riwayat terstruktur (maks 100 sesi), bagikan sebagai teks, hapus dengan konfirmasi.
- Pengaturan: refresh otomatis dapat dimatikan.
- Tombol Back kembali ke Beranda sebelum keluar.

### Diperbaiki
- Monster Hunter Outlanders kini ditemukan walau namanya di launcher "MHOutlanders" (dicocokkan tanpa spasi/simbol; "MHGU" tidak ikut cocok).
- Banner game kini tinggi tetap (sebelumnya mengikuti ukuran asli gambar sehingga terlalu tinggi).
- Tampilan tidak lagi tertimpa status bar / navigation bar pada Android 15 (edge-to-edge, targetSdk 35).
- Riwayat tidak lagi berupa satu teks yang membesar tanpa batas.
- Target sentuh tombol minimal 48dp; deskripsi aksesibilitas untuk logo dan navigasi.
- Pembuka pengaturan notifikasi menyertakan paket aplikasi agar langsung ke halaman yang benar.
- "Mulai & Buka Game" tidak memulai sesi bila game tidak ditemukan.

### Rilis & build
- Build release dengan R8 (minify + shrink resources).
- Penandatanganan lewat secrets GitHub (`GP_KEYSTORE_*`); workflow pembuat kunci disertakan.
- Output: APK rilis + AAB (Play Store).
- Riwayat v0.3/v0.4 dimigrasikan otomatis (namespace preferensi sama).

## 0.4.0
Status perangkat nyata, checklist gaming, tombol Mulai Sesi & Buka Game.
