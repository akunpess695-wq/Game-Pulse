package id.gamepulse.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.widget.TextView;

final class Premium {
    private Premium() {}

    static final int BG         = 0xFF090817;
    static final int SURFACE    = 0xFF17132A;
    static final int SURFACE_HI = 0xFF211B3B;
    static final int STROKE     = 0xFF322957;
    static final int STROKE_NEON= 0x778B3DFF;
    static final int TEXT       = 0xFFF5F1FF;
    static final int TEXT_2     = 0xFFB8AED8;
    static final int TEXT_3     = 0xFF7B70A3;
    static final int PRIMARY    = 0xFF8B3DFF;   // Electric Purple
    static final int PRIMARY_DK = 0xFF5E1FD6;
    static final int ACCENT     = 0xFFFF45C8;   // Neon Magenta
    static final int ACCENT_DK  = 0xFFC41F9A;
    static final int CYAN       = 0xFF35DFFF;   // Cyber Cyan
    static final int OK         = 0xFF4ADE80;
    static final int WARN       = 0xFFFBBF24;
    static final int HOT        = 0xFFFF5C7A;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable card(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(SURFACE);
        d.setCornerRadius(dp(c, 16));
        d.setStroke(Math.max(1, dp(c, 1)), STROKE);
        return d;
    }

    static GradientDrawable primaryButton(Context c) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{PRIMARY, ACCENT});
        d.setCornerRadius(dp(c, 14));
        return d;
    }

    static GradientDrawable secondaryButton(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x00000000);
        d.setCornerRadius(dp(c, 14));
        d.setStroke(Math.max(1, dp(c, 1)), STROKE_NEON);
        return d;
    }

    static GradientDrawable bannerScrim() {
        return new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xF2090817, 0x80090817, 0x00090817});
    }

    static void title(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setLetterSpacing(-0.01f);
    }

    static void number(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setFontFeatureSettings("tnum");
    }

    static void label(TextView t) {
        t.setTextColor(TEXT_2);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setLetterSpacing(0.02f);
    }

    static int tempColor(float c) {
        if (c < 40f) return OK;
        if (c < 45f) return WARN;
        return HOT;
    }

    static int tempColor(float c, float warm, float hot) {
        if (c < warm) return OK;
        if (c < hot) return WARN;
        return HOT;
    }

    static int fpsColor(float fps, float target) {
        float r = fps / target;
        if (r >= 0.9f) return OK;
        if (r >= 0.7f) return WARN;
        return HOT;
    }
}
