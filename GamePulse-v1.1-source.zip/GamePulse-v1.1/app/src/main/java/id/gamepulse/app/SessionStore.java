package id.gamepulse.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Penyimpanan sesi & riwayat. Memakai namespace preferensi lama ("gamepulse_v3")
 * agar riwayat dari v0.3/v0.4 tidak hilang saat pembaruan.
 */
final class SessionStore {
    static final int MAX_HISTORY = 100;

    static final class Stats {
        int count;
        long minutes;
        /** Persen baterai per jam, atau -1 jika data belum cukup. */
        float drainPerHour = -1f;
    }

    private final SharedPreferences p;

    SessionStore(Context c) {
        p = c.getSharedPreferences("gamepulse_v3", Context.MODE_PRIVATE);
    }

    SharedPreferences prefs() { return p; }

    boolean active() { return !p.getString("active", "").isEmpty(); }
    String activeGame() { return p.getString("active", ""); }
    long startedAt() { return p.getLong("started", System.currentTimeMillis()); }

    long activeMinutes() {
        return Math.max(0L, (System.currentTimeMillis() - startedAt()) / 60000L);
    }

    void start(String game, int battery, float temp) {
        float t = Float.isNaN(temp) ? -1f : temp;
        p.edit()
                .putString("active", game)
                .putLong("started", System.currentTimeMillis())
                .putInt("batteryStart", battery)
                .putFloat("tempStartVal", t)
                .putFloat("peak", t)
                .apply();
    }

    /** Perbarui suhu tertinggi yang teramati selama sesi aktif. */
    void trackPeak(float temp) {
        if (!active() || Float.isNaN(temp)) return;
        if (temp > p.getFloat("peak", -1f)) p.edit().putFloat("peak", temp).apply();
    }

    void discardActive() {
        p.edit().remove("active").remove("started").apply();
    }

    /** Akhiri sesi aktif dan simpan ke riwayat. Mengembalikan false jika tidak ada sesi. */
    boolean finish(int batteryEnd, float tempEnd, String thermalEnd) {
        if (!active()) return false;
        trackPeak(tempEnd);
        long now = System.currentTimeMillis();
        JSONObject o = new JSONObject();
        try {
            o.put("end", now);
            o.put("game", activeGame());
            o.put("min", activeMinutes());
            o.put("b0", p.getInt("batteryStart", -1));
            o.put("b1", batteryEnd);
            o.put("t0", (double) p.getFloat("tempStartVal", -1f));
            o.put("t1", (double) (Float.isNaN(tempEnd) ? -1f : tempEnd));
            o.put("peak", (double) p.getFloat("peak", -1f));
            o.put("th", thermalEnd);
        } catch (JSONException e) {
            discardActive();
            return false;
        }
        JSONArray old = load();
        JSONArray out = new JSONArray();
        out.put(o);
        for (int i = 0; i < old.length() && out.length() < MAX_HISTORY; i++) out.put(old.opt(i));
        p.edit().putString("history_json", out.toString()).remove("active").remove("started").apply();
        return true;
    }

    private JSONArray load() {
        String j = p.getString("history_json", null);
        if (j != null) {
            try {
                return new JSONArray(j);
            } catch (JSONException ignored) {
                // jatuh ke migrasi di bawah
            }
        }
        JSONArray a = new JSONArray();
        String legacy = p.getString("history", "").trim();
        if (!legacy.isEmpty()) {
            try {
                JSONObject o = new JSONObject();
                o.put("legacy", legacy);
                a.put(o);
            } catch (JSONException ignored) {
                // abaikan
            }
        }
        return a;
    }

    List<JSONObject> history() {
        JSONArray a = load();
        List<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) list.add(o);
        }
        return list;
    }

    void clearHistory() {
        p.edit().putString("history_json", "[]").remove("history").apply();
    }

    Stats stats() {
        Stats s = new Stats();
        long dropSum = 0;
        long minSum = 0;
        for (JSONObject o : history()) {
            if (!o.has("game")) continue; // entri lama (teks) tidak dihitung
            long min = o.optLong("min", 0);
            s.count++;
            s.minutes += min;
            int b0 = o.optInt("b0", -1);
            int b1 = o.optInt("b1", -1);
            if (min >= 10 && b0 >= 0 && b1 >= 0 && b1 <= b0) {
                dropSum += (b0 - b1);
                minSum += min;
            }
        }
        if (minSum > 0) s.drainPerHour = dropSum * 60f / minSum;
        return s;
    }
}
