# Kebijakan Privasi — GamePulse

GamePulse tidak mengumpulkan, mengirim, atau membagikan data apa pun.

- Tidak ada izin internet; hanya `ACCESS_NETWORK_STATE` untuk membaca jenis jaringan (Wi-Fi/seluler).
- Tidak ada iklan, analitik, atau pelacakan.
- Catatan sesi (waktu, baterai, suhu) disimpan hanya di penyimpanan lokal aplikasi dan terhapus bila aplikasi dihapus.
- Fitur "Bagikan riwayat" hanya mengirim teks ke aplikasi yang Anda pilih sendiri.
- Daftar aplikasi terpasang dibaca di perangkat hanya untuk menemukan game dan fitur "Game lain"; tidak disimpan di luar nama dan paket game yang Anda pilih.

Kontak: isi dengan email/URL pengembang sebelum publikasi ke Play Store.
