package com.gamepulse.app.service

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.gamepulse.app.R
import com.gamepulse.app.shizuku.ShizukuOptimizer
import kotlinx.coroutines.*
import kotlin.math.abs

class GameOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isExpanded = false
    private var currentBatteryTemp = 36.0f
    private var isLocked60 = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            if (temp > 0) {
                currentBatteryTemp = temp / 10f
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        setupOverlayWindow()
        startMonitoringLoop()
    }

    private fun startForegroundNotification() {
        val channelId = "gamepulse_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "GamePulse HUD Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("GamePulse HUD Aktif")
            .setContentText("Ketuk kapsul HUD di layar untuk opsi cepat")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        startForeground(101, notification)
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupOverlayWindow() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_fps_pill, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 24
        }

        val quickActions = overlayView.findViewById<LinearLayout>(R.id.quickActionsLayout)
        val btnBoost = overlayView.findViewById<TextView>(R.id.btnBoost)
        val btnLockHz = overlayView.findViewById<TextView>(R.id.btnLockHz)
        val btnClose = overlayView.findViewById<TextView>(R.id.btnClose)

        btnClose.setOnClickListener { stopSelf() }

        btnBoost.setOnClickListener {
            serviceScope.launch {
                btnBoost.text = "..."
                val heavyApps = listOf(
                    "com.instagram.android",
                    "com.zhiliaoapp.musically",
                    "com.ss.android.ugc.trill",
                    "com.facebook.katana",
                    "com.shopee.id",
                    "com.tokopedia.tkpd",
                    "com.lazada.android"
                )
                ShizukuOptimizer.forceStopBackgroundApps(heavyApps)
                btnBoost.text = "OK ✓"
                delay(1500)
                btnBoost.text = "BOOST"
            }
        }

        btnLockHz.setOnClickListener {
            serviceScope.launch {
                if (!isLocked60) {
                    ShizukuOptimizer.lockRefreshRate(60f)
                    isLocked60 = true
                    btnLockHz.text = "AUTO Hz"
                } else {
                    ShizukuOptimizer.resetRefreshRate()
                    isLocked60 = false
                    btnLockHz.text = "60Hz"
                }
            }
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        overlayView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = abs(event.rawX - initialTouchX)
                    val diffY = abs(event.rawY - initialTouchY)
                    if (diffX < 10 && diffY < 10) {
                        isExpanded = !isExpanded
                        quickActions.visibility = if (isExpanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(overlayView, params)
    }

    private fun startMonitoringLoop() {
        val tvFps = overlayView.findViewById<TextView>(R.id.tvFps)
        val tvTemp = overlayView.findViewById<TextView>(R.id.tvTemp)

        serviceScope.launch {
            while (isActive) {
                val shizukuFps = ShizukuOptimizer.getRealTimeFps()
                val currentFps = if (shizukuFps > 0) shizukuFps else getDisplayRefreshRate()

                tvFps.text = "$currentFps FPS"
                tvFps.setTextColor(
                    when {
                        currentFps >= 55 -> Color.parseColor("#00FF88")
                        currentFps >= 40 -> Color.parseColor("#FFCC00")
                        else -> Color.parseColor("#FF4444")
                    }
                )

                tvTemp.text = "${currentBatteryTemp}°C"
                tvTemp.setTextColor(
                    when {
                        currentBatteryTemp >= 42.0f -> Color.parseColor("#FF4444")
                        currentBatteryTemp >= 39.5f -> Color.parseColor("#FFAA00")
                        else -> Color.parseColor("#E2E8F0")
                    }
                )

                delay(1000)
            }
        }
    }

    private fun getDisplayRefreshRate(): Int {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay
        }
        return display?.refreshRate?.toInt() ?: 60
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        unregisterReceiver(batteryReceiver)
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
