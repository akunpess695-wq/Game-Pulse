package com.gamepulse.app

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gamepulse.app.service.GameOverlayService
import com.gamepulse.app.shizuku.ShizukuOptimizer
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvShizukuStatus: TextView
    private lateinit var btnGrantShizuku: Button
    private lateinit var tvBatteryTemp: TextView
    private lateinit var tvRamUsage: TextView
    private lateinit var tvThermalStatus: TextView
    private lateinit var switchOverlay: Switch
    private lateinit var switchDownscale: Switch
    private lateinit var switchDnd: Switch
    private lateinit var btnBoostNow: Button
    private lateinit var rvGames: RecyclerView

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Izin Shizuku Aktif!", Toast.LENGTH_SHORT).show()
        }
        updateShizukuUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)

        initViews()
        setupListeners()
        loadInstalledGames()
        startDashboardTelemetry()
    }

    private fun initViews() {
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)
        btnGrantShizuku = findViewById(R.id.btnGrantShizuku)
        tvBatteryTemp = findViewById(R.id.tvBatteryTemp)
        tvRamUsage = findViewById(R.id.tvRamUsage)
        tvThermalStatus = findViewById(R.id.tvThermalStatus)
        switchOverlay = findViewById(R.id.switchOverlay)
        switchDownscale = findViewById(R.id.switchDownscale)
        switchDnd = findViewById(R.id.switchDnd)
        btnBoostNow = findViewById(R.id.btnBoostNow)
        rvGames = findViewById(R.id.rvGames)
        rvGames.layoutManager = LinearLayoutManager(this)
    }

    private fun setupListeners() {
        btnGrantShizuku.setOnClickListener {
            if (!ShizukuOptimizer.isShizukuAvailable()) {
                Toast.makeText(this, "Jalankan layanan Shizuku terlebih dahulu!", Toast.LENGTH_LONG).show()
            } else {
                ShizukuOptimizer.requestPermission(1001)
            }
        }

        switchOverlay.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!Settings.canDrawOverlays(this)) {
                    switchOverlay.isChecked = false
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    Toast.makeText(this, "Izinkan 'Tampilkan di atas aplikasi lain'", Toast.LENGTH_LONG).show()
                } else {
                    startOverlayHud()
                }
            } else {
                stopService(Intent(this, GameOverlayService::class.java))
            }
        }

        switchDnd.setOnCheckedChangeListener { _, isChecked ->
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                switchDnd.isChecked = false
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                Toast.makeText(this, "Aktifkan akses Jangan Ganggu untuk GamePulse", Toast.LENGTH_LONG).show()
            } else {
                nm.setInterruptionFilter(
                    if (isChecked) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
            }
        }

        btnBoostNow.setOnClickListener {
            lifecycleScope.launch {
                btnBoostNow.isEnabled = false
                btnBoostNow.text = "MEMBERSIHKAN PROSES..."
                val heavyApps = listOf(
                    "com.instagram.android",
                    "com.zhiliaoapp.musically",
                    "com.ss.android.ugc.trill",
                    "com.facebook.katana",
                    "com.shopee.id",
                    "com.tokopedia.tkpd",
                    "com.lazada.android",
                    "com.twitter.android"
                )
                if (ShizukuOptimizer.hasPermission()) {
                    ShizukuOptimizer.forceStopBackgroundApps(heavyApps)
                    Toast.makeText(this@MainActivity, "Deep Boost Shizuku Selesai!", Toast.LENGTH_SHORT).show()
                } else {
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    heavyApps.forEach { am.killBackgroundProcesses(it) }
                    Toast.makeText(this@MainActivity, "RAM Dibersihkan (Mode Standar)", Toast.LENGTH_SHORT).show()
                }
                delay(800)
                btnBoostNow.text = "BOOST PERFORMA SEKARANG"
                btnBoostNow.isEnabled = true
            }
        }
    }

    private fun startOverlayHud() {
        val intent = Intent(this, GameOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun updateShizukuUi() {
        when {
            ShizukuOptimizer.hasPermission() -> {
                tvShizukuStatus.text = "SHIZUKU: AKTIF & TERHUBUNG"
                tvShizukuStatus.setTextColor(Color.parseColor("#00FF88"))
                btnGrantShizuku.visibility = View.GONE
            }
            ShizukuOptimizer.isShizukuAvailable() -> {
                tvShizukuStatus.text = "SHIZUKU: BUTUH IZIN AKSES"
                tvShizukuStatus.setTextColor(Color.parseColor("#FFCC00"))
                btnGrantShizuku.visibility = View.VISIBLE
            }
            else -> {
                tvShizukuStatus.text = "SHIZUKU: TIDAK AKTIF (MODE STANDAR)"
                tvShizukuStatus.setTextColor(Color.parseColor("#FF5555"))
                btnGrantShizuku.visibility = View.VISIBLE
            }
        }
    }

    private fun startDashboardTelemetry() {
        lifecycleScope.launch {
            while (isActive) {
                updateShizukuUi()

                // RAM Info
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val usedGb = (memInfo.totalMem - memInfo.availMem) / (1024.0 * 1024.0 * 1024.0)
                val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
                tvRamUsage.text = String.format("%.1f / %.1f GB", usedGb, totalGb)

                // Battery Temp
                val batIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = (batIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350) / 10f
                tvBatteryTemp.text = "${temp}°C"

                // Thermal Status
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    val statusText = when (pm.currentThermalStatus) {
                        PowerManager.THERMAL_STATUS_NONE -> "OPTIMAL"
                        PowerManager.THERMAL_STATUS_LIGHT -> "HANGAT"
                        PowerManager.THERMAL_STATUS_MODERATE -> "WASPADA"
                        else -> "THROTTLING!"
                    }
                    tvThermalStatus.text = statusText
                }

                delay(1500)
            }
        }
    }

    private fun loadInstalledGames() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val games = apps.filter { app ->
            val isGameFlag = (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val isGameCat = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.category == ApplicationInfo.CATEGORY_GAME
            } else false
            isGameFlag || isGameCat
        }.map { app ->
            GameItem(
                name = pm.getApplicationLabel(app).toString(),
                packageName = app.packageName,
                icon = pm.getApplicationIcon(app)
            )
        }.sortedBy { it.name.lowercase() }

        rvGames.adapter = GameAdapter(games) { game ->
            launchOptimizedGame(game)
        }
    }

    private fun launchOptimizedGame(game: GameItem) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "Mengoptimalkan ${game.name}...", Toast.LENGTH_SHORT).show()

            if (ShizukuOptimizer.hasPermission() && switchDownscale.isChecked) {
                ShizukuOptimizer.setGameDownscale(game.packageName, "0.75")
            }

            if (Settings.canDrawOverlays(this@MainActivity)) {
                switchOverlay.isChecked = true
                startOverlayHud()
            }

            val launchIntent = packageManager.getLaunchIntentForPackage(game.packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this@MainActivity, "Tidak dapat membuka ${game.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    data class GameItem(
        val name: String,
        val packageName: String,
        val icon: android.graphics.drawable.Drawable
    )

    class GameAdapter(
        private val items: List<GameItem>,
        private val onLaunch: (GameItem) -> Unit
    ) : RecyclerView.Adapter<GameAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val ivIcon: ImageView = v.findViewById(R.id.ivGameIcon)
            val tvName: TextView = v.findViewById(R.id.tvGameName)
            val tvPkg: TextView = v.findViewById(R.id.tvGamePkg)
            val btnPlay: Button = v.findViewById(R.id.btnPlayGame)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.ivIcon.setImageDrawable(item.icon)
            holder.tvName.text = item.name
            holder.tvPkg.text = item.packageName
            holder.btnPlay.setOnClickListener { onLaunch(item) }
        }

        override fun getItemCount(): Int = items.size
    }
}
