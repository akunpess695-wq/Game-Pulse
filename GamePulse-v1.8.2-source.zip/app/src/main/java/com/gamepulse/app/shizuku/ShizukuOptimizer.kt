package com.gamepulse.app.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuOptimizer {

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission(requestCode: Int = 1001) {
        if (isShizukuAvailable() && !hasPermission()) {
            try {
                Shizuku.requestPermission(requestCode)
            } catch (_: Throwable) {
            }
        }
    }

    suspend fun runShellCommand(command: String): String = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext "ERROR: Shizuku permission denied"
        try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            process.waitFor()
            output.toString().trim()
        } catch (e: Throwable) {
            "ERROR: ${e.message}"
        }
    }

    suspend fun getRealTimeFps(): Int {
        val result = runShellCommand("dumpsys SurfaceFlinger --latency")
        if (result.startsWith("ERROR") || result.isBlank()) return -1

        val lines = result.lines().drop(1).filter { it.isNotBlank() }
        if (lines.size < 2) return -1

        val timestamps = lines.mapNotNull { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 2) parts[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }

        if (timestamps.size < 2) return -1

        val durationNs = timestamps.last() - timestamps.first()
        if (durationNs <= 0L) return -1

        val frameCount = timestamps.size - 1
        val fps = (frameCount * 1_000_000_000.0 / durationNs).toInt()
        return fps.coerceIn(1, 144)
    }

    suspend fun lockRefreshRate(hz: Float) {
        runShellCommand("settings put system peak_refresh_rate $hz")
        runShellCommand("settings put system min_refresh_rate $hz")
    }

    suspend fun resetRefreshRate() {
        runShellCommand("settings delete system peak_refresh_rate")
        runShellCommand("settings delete system min_refresh_rate")
    }

    suspend fun setGameDownscale(packageName: String, scale: String = "0.75") {
        runShellCommand("cmd game set --downscale $scale $packageName")
    }

    suspend fun resetGameDownscale(packageName: String) {
        runShellCommand("cmd game reset $packageName")
    }

    suspend fun forceStopBackgroundApps(packages: List<String>) {
        for (pkg in packages) {
            runShellCommand("am force-stop $pkg")
        }
    }
}
