package id.gamepulse.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.widget.TextView;

/** Token desain "Carbon Redline". Hanya tampilan, tanpa logika. */
final class Premium {
    private Premium() {}

    // Warna
    static final int BG         = 0xFF0B0D12;
    static final int SURFACE    = 0xFF151922;
    static final int SURFACE_HI = 0xFF1C212C;
    static final int STROKE     = 0x14FFFFFF; // putih 8%
    static final int TEXT       = 0xFFF2F4F8;
    static final int TEXT_2     = 0xFF9AA3B2;
    static final int TEXT_3     = 0xFF5F6878;
    static final int ACCENT     = 0xFFE5383B;
    static final int ACCENT_DK  = 0xFFB3202A;
    static final int OK         = 0xFF2BD47D;
    static final int WARN       = 0xFFFFB020;
    static final int HOT        = 0xFFFF4D4F;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    /** Kartu: sudut 16dp, tepi tipis, tanpa bayangan. */
    static GradientDrawable card(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(SURFACE);
        d.setCornerRadius(dp(c, 16));
        d.setStroke(Math.max(1, dp(c, 1)), STROKE);
        return d;
    }

    /** Tombol utama: gradasi merah. */
    static GradientDrawable primaryButton(Context c) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{ACCENT, ACCENT_DK});
        d.setCornerRadius(dp(c, 14));
        return d;
    }

    /** Tombol sekunder: transparan dengan garis tepi. */
    static GradientDrawable secondaryButton(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x00000000);
        d.setCornerRadius(dp(c, 14));
        d.setStroke(Math.max(1, dp(c, 1)), 0x33FFFFFF);
        return d;
    }

    /** Gradasi gelap untuk ditumpuk di bawah banner. */
    static GradientDrawable bannerScrim() {
        return new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xF20B0D12, 0x800B0D12, 0x000B0D12});
    }

    // Tipografi (3 ukuran saja)
    static void title(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setLetterSpacing(-0.01f);
    }

    static void number(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setFontFeatureSettings("tnum"); // angka tabular, tidak goyang
    }

    static void label(TextView t) {
        t.setTextColor(TEXT_2);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setLetterSpacing(0.02f);
    }

    /** Warna status suhu (°C). */
    static int tempColor(float c) {
        if (c < 40f) return OK;
        if (c < 45f) return WARN;
        return HOT;
    }

    /** Warna status FPS terhadap target (misal 60/90/120). */
    static int fpsColor(float fps, float target) {
        float r = fps / target;
        if (r >= 0.9f) return OK;
        if (r >= 0.7f) return WARN;
        return HOT;
    }
}
