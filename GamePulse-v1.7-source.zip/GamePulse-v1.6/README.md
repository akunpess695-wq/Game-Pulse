# GamePulse v1.7 — Carbon Redline

Aplikasi Android native (Java; satu-satunya library pihak ketiga: Shizuku API, opsional) untuk memantau kondisi HP saat bermain dan membuka game dengan cepat. Dirancang untuk Redmi Note 12 Pro 5G; berjalan di Android 10+ (minSdk 29, targetSdk 35).

## Fitur
- Status perangkat nyata: baterai (+ mengisi), suhu baterai, thermal Android, RAM, jaringan.
- Peringatan panas dan baterai rendah (juga lewat notifikasi saat sesi, walau app tidak dibuka).
- Profil eFootball & Monster Hunter Outlanders + hingga 12 game lain (deteksi otomatis atau pilih manual).
- Profil rekomendasi per jenis game dan kartu Kesiapan Main (baterai, suhu, RAM, jaringan).
- Sesi bermain: durasi, baterai awal→akhir, suhu awal→akhir→tertinggi terpantau, thermal akhir.
- Ringkasan & riwayat (maks 100), bagikan sebagai teks, hapus dengan konfirmasi.
- Shortcut pengaturan Android (layar, baterai, notifikasi, jaringan).
- Tanpa izin internet, iklan, atau pelacakan. Lihat `PRIVACY.md`.

## Batasan (jujur)
- Optimasi hanya lewat API resmi (bersihkan RAM latar, Jangan Ganggu, saran manual); efeknya terbatas dan bergantung sistem.
- Tidak mengubah CPU/GPU, tidak membuka batas FPS, tidak melewati anti-cheat. FPS hanya diukur (perkiraan) bila Shizuku aktif.
- Profil hanyalah saran manual.
- Suhu tertinggi dipantau layanan latar hanya selama sesi aktif (notifikasi tetap tampil); di luar sesi tidak ada pemantauan.
- Layar putih di dalam eFootball berasal dari game itu sendiri, bukan dari GamePulse.
- **Kode belum pernah dikompilasi atau diuji di perangkat** oleh pembuatnya; lakukan `TEST_CHECKLIST.md` dulu.

## Cara build rilis (GitHub Actions)
1. Di repo, di root branch `main`, unggah `GamePulse-v1.0-source.zip` (sebagai ZIP, jangan diekstrak). Hapus zip & workflow lama (`GamePulse-v0.3/0.4-*`, `GamePulse-v0.4-build.yml`, `build.yml` lama).
2. Taruh `build.yml` di `.github/workflows/build.yml` dan `create-keystore.yml` di `.github/workflows/create-keystore.yml`.
3. **Sekali saja:** Actions → *Create GamePulse keystore* → Run. Unduh artifact `GamePulse-keystore-RAHASIA`, simpan `gamepulse-release.jks` di tempat aman **di luar GitHub**, isi 4 secret (`GP_KEYSTORE_BASE64`, `GP_KEYSTORE_PASSWORD`, `GP_KEY_ALIAS`, `GP_KEY_PASSWORD`) di Settings → Secrets and variables → Actions, lalu hapus artifact tersebut.
4. Actions → *Build GamePulse v1.0 Release* → Run workflow.
5. Unduh `GamePulse-v1.0.0-release-APK` (untuk dipasang) dan `...-AAB` (untuk Play Store).

Tanpa langkah 3, build tetap jalan memakai kunci sementara (muncul peringatan); APK-nya bisa dipasang tetapi tidak bisa diperbarui oleh build berikutnya yang bertanda tangan lain.

### Pembaruan dari v0.4
APK v0.4 adalah build debug dengan kunci debug. Android menolak memasang rilis bertanda tangan berbeda di atasnya. Bagikan riwayat (v0.4 tidak punya tombol ini) atau catat manual, copot v0.4, lalu pasang v1.0. Mulai v1.0, selalu pakai kunci yang sama.

### Build lokal
`gradle :app:assembleRelease` (butuh Gradle 8.9, JDK 17, Android SDK 35). Tanpa variabel `GP_KEYSTORE_*` hasilnya APK tidak bertanda tangan.

## Menuju Play Store
Siapkan: akun developer, ikon 512×512, feature graphic 1024×500, tangkapan layar, deskripsi, URL kebijakan privasi (isi `PRIVACY.md`, hosting di URL publik), formulir Data safety (jawab: tidak ada data dikumpulkan), dan pernyataan izin `QUERY_ALL_PACKAGES` tidak dipakai (app memakai `<queries>`).

Kredit: tidak ada pihak ketiga. Nama "eFootball" dan "Monster Hunter" milik pemiliknya masing-masing; GamePulse tidak berafiliasi dengan mereka.
