package id.gamepulse.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Grafik radar 3 sumbu. Menggambarkan PERKIRAAN arah trade-off sebuah preset, bukan hasil ukur. */
final class RadarView extends View {
    /** Nilai terakhir yang digambar; dipakai sebagai titik awal animasi saat layar dibangun ulang. */
    private static float[] last;

    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path poly = new Path();
    private final float d;
    private String[] labels = {"", "", ""};
    private float[] from = {0.2f, 0.2f, 0.2f}, to = {0.2f, 0.2f, 0.2f}, cur = {0.2f, 0.2f, 0.2f};
    private ValueAnimator anim;

    RadarView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(Math.max(1f, d));
        grid.setColor(0x33FFFFFF);
        axis.setStyle(Paint.Style.STROKE);
        axis.setStrokeWidth(Math.max(1f, d));
        axis.setColor(0x22FFFFFF);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x66FF3B30);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * d);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setColor(0xFFFF3B30);
        dot.setStyle(Paint.Style.FILL);
        dot.setColor(0xFFFF9A3C);
        label.setColor(0xFFD2B2B0);
        label.setTextSize(12f * d);
    }

    void setData(String[] labels, float[] target) {
        this.labels = labels;
        to = target.clone();
        from = (last != null && last.length == 3) ? last.clone() : new float[]{0.15f, 0.15f, 0.15f};
        cur = from.clone();
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(380);
        anim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            for (int i = 0; i < 3; i++) cur[i] = from[i] + (to[i] - from[i]) * t;
            last = cur.clone();
            invalidate();
        });
        anim.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.54f;
        float r = Math.min(w * 0.26f, h * 0.33f);
        double[] ang = {-Math.PI / 2, Math.PI / 6, 5 * Math.PI / 6};   // atas, kanan-bawah, kiri-bawah
        for (int k = 1; k <= 3; k++) cv.drawCircle(cx, cy, r * k / 3f, grid);
        for (int i = 0; i < 3; i++) {
            cv.drawLine(cx, cy, cx + (float) Math.cos(ang[i]) * r, cy + (float) Math.sin(ang[i]) * r, axis);
        }
        poly.reset();
        float[] px = new float[3], py = new float[3];
        for (int i = 0; i < 3; i++) {
            float v = Math.max(0.05f, Math.min(1f, cur[i]));
            px[i] = cx + (float) Math.cos(ang[i]) * r * v;
            py[i] = cy + (float) Math.sin(ang[i]) * r * v;
            if (i == 0) poly.moveTo(px[i], py[i]); else poly.lineTo(px[i], py[i]);
        }
        poly.close();
        cv.drawPath(poly, fill);
        cv.drawPath(poly, line);
        for (int i = 0; i < 3; i++) cv.drawCircle(px[i], py[i], 4f * d, dot);

        float g = 10f * d;
        label.setTextAlign(Paint.Align.CENTER);
        cv.drawText(labels[0], cx, cy - r - g, label);
        label.setTextAlign(Paint.Align.LEFT);
        cv.drawText(labels[1], cx + (float) Math.cos(ang[1]) * r + g * 0.6f, cy + (float) Math.sin(ang[1]) * r + g * 2f, label);
        label.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(labels[2], cx + (float) Math.cos(ang[2]) * r - g * 0.6f, cy + (float) Math.sin(ang[2]) * r + g * 2f, label);
    }
}
