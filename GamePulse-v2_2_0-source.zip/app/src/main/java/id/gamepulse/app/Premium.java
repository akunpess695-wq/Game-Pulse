package id.gamepulse.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.widget.TextView;

final class Premium {
    private Premium() {}

    static final int BG         = 0xFF0A0506;
    static final int SURFACE    = 0xFF1A0C0F;
    static final int SURFACE_HI = 0xFF2A1014;
    static final int STROKE     = 0xFF4A1A22;
    static final int STROKE_NEON= 0x77E0262D;
    static final int TEXT       = 0xFFFFF1EE;
    static final int TEXT_2     = 0xFFD2B2B0;
    static final int TEXT_3     = 0xFF8F6F70;
    static final int PRIMARY    = 0xFFE0262D;   // Electric Purple
    static final int PRIMARY_DK = 0xFF8F1119;
    static final int ACCENT     = 0xFFFF3B30;   // Neon Magenta
    static final int ACCENT_DK  = 0xFFB3201A;
    static final int CYAN       = 0xFFFF9A3C;   // Cyber Cyan
    static final int OK         = 0xFF4ADE80;
    static final int WARN       = 0xFFFBBF24;
    static final int HOT        = 0xFFFF4D4D;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable card(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(SURFACE);
        d.setCornerRadius(dp(c, 16));
        d.setStroke(Math.max(1, dp(c, 1)), STROKE);
        return d;
    }

    static GradientDrawable primaryButton(Context c) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{PRIMARY, ACCENT});
        d.setCornerRadius(dp(c, 14));
        return d;
    }

    static GradientDrawable secondaryButton(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x00000000);
        d.setCornerRadius(dp(c, 14));
        d.setStroke(Math.max(1, dp(c, 1)), STROKE_NEON);
        return d;
    }

    static GradientDrawable bannerScrim() {
        return new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xF20A0506, 0x800A0506, 0x000A0506});
    }

    static void title(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setLetterSpacing(-0.01f);
    }

    static void number(TextView t) {
        t.setTextColor(TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setFontFeatureSettings("tnum");
    }

    static void label(TextView t) {
        t.setTextColor(TEXT_2);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setLetterSpacing(0.02f);
    }

    static int tempColor(float c) {
        if (c < 40f) return OK;
        if (c < 45f) return WARN;
        return HOT;
    }

    static int tempColor(float c, float warm, float hot) {
        if (c < warm) return OK;
        if (c < hot) return WARN;
        return HOT;
    }

    static int fpsColor(float fps, float target) {
        float r = fps / target;
        if (r >= 0.9f) return OK;
        if (r >= 0.7f) return WARN;
        return HOT;
    }

    /** Teks bergradien horizontal (dipakai judul: pink -> putih) dengan glow neon. */
    static void gradientText(TextView t, int from, int to, int glow) {
        t.post(() -> {
            float w = Math.max(1f, t.getPaint().measureText(t.getText().toString()));
            t.getPaint().setShader(new android.graphics.LinearGradient(0, 0, w, 0,
                    new int[]{from, to}, null, android.graphics.Shader.TileMode.CLAMP));
            t.invalidate();
        });
        t.setShadowLayer(dp(t.getContext(), 6), 0, 0, glow);
    }

    /** Teks dengan beberapa warna berurutan (mis. "GAME" putih + "PULSE" merah) dan glow. */
    static void gradientText(TextView t, int[] colors, float[] pos, int glow) {
        t.post(() -> {
            float w = Math.max(1f, t.getPaint().measureText(t.getText().toString()));
            t.getPaint().setShader(new android.graphics.LinearGradient(0, 0, w, 0,
                    colors, pos, android.graphics.Shader.TileMode.CLAMP));
            t.invalidate();
        });
        t.setShadowLayer(dp(t.getContext(), 6), 0, 0, glow);
    }
}
