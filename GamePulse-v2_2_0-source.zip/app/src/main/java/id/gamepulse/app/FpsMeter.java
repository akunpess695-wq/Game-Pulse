package id.gamepulse.app;

import android.content.SharedPreferences;

final class FpsMeter {
    private FpsMeter() {}

    private static final int MAXMS = 100, RES = 10;
    private static final long NONE = Long.MAX_VALUE;
    private static final long[] HIST = new long[MAXMS * RES + 1];
    private static long n, lastTs;
    private static double sum, sumSq;
    private static String layer;

    static volatile float live = -1f;
    static volatile String status = "";
    static volatile long nextMs = 5000L;
    static final long ACC_MIN_MS = 1000L, SLOW_MS = 5000L;

    static synchronized void reset(SharedPreferences p) {
        java.util.Arrays.fill(HIST, 0L);
        n = 0; lastTs = 0; sum = 0; sumSq = 0; layer = null;
        live = -1f; status = ""; nextMs = SLOW_MS;
        if (p != null) p.edit().remove("fps_avg").remove("fps_low").remove("fps_jit").remove("fps_n").apply();
    }

    static void sample(SharedPreferences p, String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z0-9._]+")) { status = "FPS: paket game tidak diketahui"; return; }
        String lay;
        synchronized (FpsMeter.class) { lay = layer; }
        if (lay == null) {
            lay = findLayer(pkg);
            if (lay == null) { live = -1f; status = "FPS: layar game belum ditemukan"; return; }
            synchronized (FpsMeter.class) { layer = lay; }
        }
        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency '" + lay + "'");
        if (out.startsWith("ERROR")) { live = -1f; status = "FPS: Shizuku gagal (" + out + ")"; dropLayer(); return; }
        int k = 0;
        double sumLocal = 0;
        long firstSeen = 0, lastSeen = 0;
        synchronized (FpsMeter.class) {
            String[] lines = out.split("\n");
            for (int i = 1; i < lines.length; i++) {
                String[] t0 = lines[i].trim().split("\\s+");
                if (t0.length < 3) continue;
                try {
                    long f = Long.parseLong(t0[1]);
                    if (f > 0 && f != NONE) { if (lastTs > 0 && f > lastTs) lastTs = 0; break; }
                } catch (NumberFormatException e) { }
            }
            for (int i = 1; i < lines.length; i++) {
                String[] t = lines[i].trim().split("\\s+");
                if (t.length < 3) continue;
                long ts;
                try { ts = Long.parseLong(t[1]); } catch (NumberFormatException e) { continue; }
                if (ts <= 0 || ts == NONE) continue;
                if (firstSeen == 0) firstSeen = ts;
                lastSeen = ts;
                if (ts <= lastTs) continue;
                if (lastTs > 0) {
                    double ms = (ts - lastTs) / 1e6;
                    if (ms > 0 && ms <= 1000) {
                        HIST[Math.min((int) (ms * RES), MAXMS * RES)]++;
                        n++; sum += ms; sumSq += ms * ms;
                        k++; sumLocal += ms;
                    }
                }
                lastTs = ts;
            }
            if (k > 0) live = (float) (1000.0 * k / sumLocal);
        }
        long spanMs = (lastSeen - firstSeen) / 1000000L;
        boolean acc = p == null || p.getBoolean("fps_acc", true);
        nextMs = (acc && spanMs > 0) ? Math.max(ACC_MIN_MS, Math.min(SLOW_MS, (long) (spanMs * 0.7))) : SLOW_MS;
        if (k == 0) { live = -1f; status = "FPS: menunggu frame game"; dropLayer(); return; }
        status = "";
        persist(p);
    }

    private static synchronized void dropLayer() { layer = null; lastTs = 0; }

    private static String findLayer(String pkg) {
        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --list");
        String best = null, any = null;
        for (String l : out.split("\n")) {
            String s = l.trim();
            if (s.isEmpty() || s.indexOf('\'') >= 0 || !s.contains(pkg)) continue;
            if (s.contains("SurfaceView") && !s.contains("Background")) { best = s; break; }
            if (any == null && !s.contains("Bounds")) any = s;
        }
        return best != null ? best : any;
    }

    private static synchronized void persist(SharedPreferences p) {
        if (n < 30) return;
        double mean = sum / n;
        double var = Math.max(0, sumSq / n - mean * mean);
        long target = Math.max(1, Math.round(n * 0.01)), acc = 0;
        int idx = 0;
        for (int i = MAXMS * RES; i >= 0; i--) { acc += HIST[i]; if (acc >= target) { idx = i; break; } }
        float low = (float) (1000.0 / ((idx + 0.5) / RES));
        p.edit().putFloat("fps_avg", (float) (1000.0 / mean)).putFloat("fps_low", low)
                .putFloat("fps_jit", (float) Math.sqrt(var)).putInt("fps_n", (int) Math.min(n, Integer.MAX_VALUE)).apply();
    }
}
