package id.gamepulse.app;

import android.content.Context;
import android.content.SharedPreferences;

final class Thresholds {
    private Thresholds() {}

    static final String K_WARM = "th_warm", K_HOT = "th_hot";
    static final int DEF_WARM = 40, DEF_HOT = 43;
    private static final int[] WARM_OPTS = {38, 40, 42};
    private static final int[] HOT_OPTS = {42, 43, 45, 47};

    static final float HEADROOM_WARM = 0.8f, HEADROOM_HOT = 0.95f;

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("gamepulse_v3", Context.MODE_PRIVATE);
    }

    private static boolean has(int[] a, int v) {
        for (int x : a) if (x == v) return true;
        return false;
    }

    private static int next(int[] a, int v) {
        for (int i = 0; i < a.length; i++) if (a[i] == v) return a[(i + 1) % a.length];
        return a[0];
    }

    static int warm(Context c) {
        int w = p(c).getInt(K_WARM, DEF_WARM);
        return has(WARM_OPTS, w) ? w : DEF_WARM;
    }

    static int hot(Context c) {
        int w = warm(c);
        int h = p(c).getInt(K_HOT, DEF_HOT);
        if (has(HOT_OPTS, h) && h > w) return h;
        for (int x : HOT_OPTS) if (x > w) return x;
        return HOT_OPTS[HOT_OPTS.length - 1];
    }

    static void cycleWarm(Context c) {
        p(c).edit().putInt(K_WARM, next(WARM_OPTS, warm(c))).apply();
    }

    static void cycleHot(Context c) {
        int w = warm(c);
        int n = next(HOT_OPTS, hot(c));
        for (int i = 0; i < HOT_OPTS.length && n <= w; i++) n = next(HOT_OPTS, n);
        p(c).edit().putInt(K_HOT, n).apply();
    }
}
