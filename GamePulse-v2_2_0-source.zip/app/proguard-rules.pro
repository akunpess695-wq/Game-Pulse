# Shizuku dipanggil sebagian lewat refleksi.
-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**
