# GamePulse v0.4 — Redline Extreme

Android native Java project for Redmi Note 12 Pro 5G (Dimensity 1080, 8 GB RAM), with eFootball and Monster Hunter Outlanders profiles.

## Improvements over v0.3
- Preserves the red-black Redline Extreme dashboard, custom GP launcher icon and original artwork.
- Shows actual Android-reported battery percentage, battery temperature, thermal status, available/total system RAM, and network type.
- Adds gaming safety checklist and shortcut to network settings.
- Adds **Start Session & Open Game** action.
- Launches games using Android launcher intents without WebView, overlays, or RESET_TASK_IF_NEEDED.
- Keeps session history across the upgrade by reusing the existing app preference namespace.
- Retains scroll position during dashboard refresh.

## Important limitations
- No direct CPU/GPU tuning, FPS unlocking, anti-cheat bypass, or measured game FPS.
- Profiles are suggestions, not automatic game settings.
- A white screen inside eFootball may be caused by the game itself; a launcher change is not a confirmed fix.
- Game discovery depends on installed package visibility and launcher labels.
- No APK has been built or device-tested here.

## GitHub Actions build
1. Upload `GamePulse-v0.4-source.zip` **as a ZIP** to the repository root on `main`.
2. Put `build.yml` at `.github/workflows/build.yml` (paste its content in the GitHub editor if downloads fail).
3. Run `Build GamePulse v0.4 APK from ZIP` from Actions.
4. Download `GamePulse-v0.4-debug-APK` artifact.

If Android rejects installing over an earlier debug build, its signing key may differ. Uninstalling removes local session history, so back up anything important first.
