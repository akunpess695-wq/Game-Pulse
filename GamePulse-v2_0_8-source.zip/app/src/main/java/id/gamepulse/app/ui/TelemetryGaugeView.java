package id.gamepulse.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

public class TelemetryGaugeView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcBounds = new RectF();

    private float progress = 0.75f;
    private String valueText = "60";
    private String labelText = "FPS";
    private int ringColor = AnimeTheme.ACCENT;

    public TelemetryGaugeView(Context context) {
        super(context);
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setColor(AnimeTheme.STROKE);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        valuePaint.setColor(AnimeTheme.TEXT_PRIMARY);
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        labelPaint.setColor(AnimeTheme.TEXT_SECONDARY);
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setMetric(float fraction, String value, String label, int color) {
        this.progress = Math.max(0f, Math.min(1f, fraction));
        this.valueText = value;
        this.labelText = label;
        this.ringColor = color;
        invalidate();
    }

    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF outerBounds = new RectF();
    private final RectF innerBounds = new RectF();

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float d = Math.min(w, h);
        float cx = w * 0.5f, cy = h * 0.5f;
        float stroke = d * 0.075f;

        // cincin luar tipis + tanda kardinal
        float ro = d * 0.5f - 2f;
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(Math.max(1f, d * 0.014f));
        ringPaint.setColor((ringColor & 0x00FFFFFF) | 0x99000000);
        outerBounds.set(cx - ro, cy - ro, cx + ro, cy + ro);
        canvas.drawCircle(cx, cy, ro, ringPaint);

        // busur progres + glow
        float rp = ro - stroke * 1.25f;
        arcBounds.set(cx - rp, cy - rp, cx + rp, cy + rp);
        trackPaint.setStrokeWidth(stroke);
        trackPaint.setColor(0x44B8AED8);
        canvas.drawArc(arcBounds, 135f, 270f, false, trackPaint);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setColor(ringColor);
        progressPaint.setShadowLayer(stroke * 0.9f, 0, 0, ringColor);
        canvas.drawArc(arcBounds, 135f, 270f * progress, false, progressPaint);
        progressPaint.clearShadowLayer();

        // cincin dalam putus-putus
        float ri = rp - stroke * 1.15f;
        dashPaint.setStyle(Paint.Style.STROKE);
        dashPaint.setStrokeWidth(Math.max(1f, d * 0.012f));
        dashPaint.setColor((ringColor & 0x00FFFFFF) | 0x77000000);
        dashPaint.setPathEffect(new android.graphics.DashPathEffect(new float[]{d * 0.03f, d * 0.03f}, 0));
        innerBounds.set(cx - ri, cy - ri, cx + ri, cy + ri);
        canvas.drawOval(innerBounds, dashPaint);

        valuePaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        valuePaint.setTextSize(d * 0.215f);
        labelPaint.setTextSize(d * 0.105f);
        float vy = cy + valuePaint.getTextSize() * 0.12f;
        canvas.drawText(valueText, cx, vy, valuePaint);
        canvas.drawText(labelText, cx, vy + labelPaint.getTextSize() * 1.45f, labelPaint);
    }
}
