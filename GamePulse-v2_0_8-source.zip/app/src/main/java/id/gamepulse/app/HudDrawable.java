package id.gamepulse.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.graphics.Outline;

/** Panel HUD sci-fi: sudut dipotong (chamfer), garis neon, dan tab aksen di pojok kanan atas. */
final class HudDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tab = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float cut, sw;
    private final boolean accent;

    HudDrawable(Context c, int fillColor, int strokeColor, float cutDp, boolean accent) {
        float d = c.getResources().getDisplayMetrics().density;
        cut = cutDp * d;
        sw = Math.max(1f, 1.2f * d);
        this.accent = accent;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(fillColor);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(sw);
        line.setColor(strokeColor);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(sw * 3.2f);
        glow.setColor((strokeColor & 0x00FFFFFF) | 0x26000000);
        tab.setStyle(Paint.Style.STROKE);
        tab.setStrokeWidth(sw * 2.4f);
        tab.setStrokeCap(Paint.Cap.ROUND);
        tab.setColor(0xFF35DFFF);
    }

    @Override public void draw(Canvas cv) {
        float l = getBounds().left + sw * 2, t = getBounds().top + sw * 2;
        float r = getBounds().right - sw * 2, b = getBounds().bottom - sw * 2;
        float k = Math.min(cut, Math.min(r - l, b - t) / 3f);
        path.reset();
        path.moveTo(l + k, t);
        path.lineTo(r - k, t);
        path.lineTo(r, t + k);
        path.lineTo(r, b - k * 0.45f);
        path.lineTo(r - k * 0.45f, b);
        path.lineTo(l + k, b);
        path.lineTo(l, b - k);
        path.lineTo(l, t + k * 0.45f);
        path.close();
        cv.drawPath(path, fill);
        cv.drawPath(path, glow);
        cv.drawPath(path, line);
        if (accent && (r - l) > k * 6) {
            float y = t - sw * 0.2f;
            cv.drawLine(r - k * 4.2f, y, r - k * 1.7f, y, tab);
            tab.setColor(0xFFFF45C8);
            cv.drawLine(r - k * 1.4f, y, r - k * 1.0f, y, tab);
            tab.setColor(0xFF35DFFF);
        }
    }

    @Override public void getOutline(Outline o) { o.setRect(getBounds()); o.setAlpha(0f); }
    @Override public void setAlpha(int a) { fill.setAlpha(a); line.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter f) { fill.setColorFilter(f); line.setColorFilter(f); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
