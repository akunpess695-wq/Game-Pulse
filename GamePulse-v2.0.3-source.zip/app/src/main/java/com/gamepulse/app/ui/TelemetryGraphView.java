package com.gamepulse.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class TelemetryGraphView extends View {

    private final List<Float> samples = new ArrayList<>();
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path linePath = new Path();
    private final Path fillPath = new Path();
    private float minVal = 0f;
    private float maxVal = 120f;
    private int accentColor = AnimeTheme.ACCENT;

    public TelemetryGraphView(Context context) {
        super(context);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(AnimeTheme.dp(context, 2.2f));
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setStrokeJoin(Paint.Join.ROUND);

        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1f);
        gridPaint.setColor(AnimeTheme.STROKE);
    }

    public void setRange(float min, float max, int color) {
        this.minVal = min;
        this.maxVal = Math.max(min + 1f, max);
        this.accentColor = color;
        invalidate();
    }

    public void setSamples(List<Float> values) {
        samples.clear();
        if (values != null) {
            samples.addAll(values);
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        for (int i = 1; i <= 3; i++) {
            float gy = h * (i / 4f);
            canvas.drawLine(0, gy, w, gy, gridPaint);
        }

        if (samples.size() < 2) return;

        linePaint.setColor(accentColor);
        linePath.reset();
        fillPath.reset();

        float stepX = w / (samples.size() - 1);
        for (int i = 0; i < samples.size(); i++) {
            float v = Math.max(minVal, Math.min(maxVal, samples.get(i)));
            float norm = (v - minVal) / (maxVal - minVal);
            float x = i * stepX;
            float y = h - (norm * (h - 12f) + 6f);
            if (i == 0) {
                linePath.moveTo(x, y);
                fillPath.moveTo(x, h);
                fillPath.lineTo(x, y);
            } else {
                linePath.lineTo(x, y);
                fillPath.lineTo(x, y);
            }
        }
        fillPath.lineTo(w, h);
        fillPath.close();

        int topFill = (accentColor & 0x00FFFFFF) | 0x44000000;
        fillPaint.setShader(new LinearGradient(0, 0, 0, h, topFill, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawPath(fillPath, fillPaint);
        canvas.drawPath(linePath, linePaint);
    }
}
