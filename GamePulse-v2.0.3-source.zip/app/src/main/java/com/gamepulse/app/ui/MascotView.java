package com.gamepulse.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public class MascotView extends View {

    public enum Expression {
        HAPPY("Siap tempur! Sistem dalam kondisi prima."),
        EXCITED("Game meluncur! Fokus penuh ke kemenangan!"),
        FOCUSED("Memantau telemetri FPS & frame-time secara real-time."),
        CONCERNED("Suhu meningkat! Sebaiknya aktifkan pendinginan."),
        SLEEPY("Mode siaga... Menunggu sesi bermain berikutnya."),
        CELEBRATING("Sesi luar biasa! Performa stabil tanpa drop!");

        public final String defaultLine;
        Expression(String line) { this.defaultLine = line; }
    }

    private Expression expression = Expression.HAPPY;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();

    public MascotView(Context context) { super(context); }
    public MascotView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setExpression(Expression expr) {
        if (expr != null && this.expression != expr) {
            this.expression = expr;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w * 0.5f;
        float cy = h * 0.52f;
        float s = Math.min(w, h) / 200f;

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0, 0, w, h,
                Color.parseColor("#338B3DFF"), Color.parseColor("#22FF45C8"), Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, 84f * s, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f * s);
        paint.setColor(Color.parseColor("#5535DFFF"));
        canvas.drawCircle(cx, cy, 78f * s, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#C7B8EA"));
        path.reset();
        path.moveTo(cx - 52f * s, cy - 28f * s);
        path.quadTo(cx - 68f * s, cy + 36f * s, cx - 50f * s, cy + 82f * s);
        path.lineTo(cx + 50f * s, cy + 82f * s);
        path.quadTo(cx + 68f * s, cy + 36f * s, cx + 52f * s, cy - 28f * s);
        path.close();
        canvas.drawPath(path, paint);

        paint.setColor(Color.parseColor("#141124"));
        path.reset();
        path.moveTo(cx - 54f * s, cy + 86f * s);
        path.quadTo(cx - 48f * s, cy + 48f * s, cx - 18f * s, cy + 44f * s);
        path.lineTo(cx + 18f * s, cy + 44f * s);
        path.quadTo(cx + 48f * s, cy + 48f * s, cx + 54f * s, cy + 86f * s);
        path.close();
        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.4f * s);
        paint.setColor(AnimeTheme.PRIMARY);
        canvas.drawLine(cx - 26f * s, cy + 50f * s, cx, cy + 72f * s, paint);
        canvas.drawLine(cx + 26f * s, cy + 50f * s, cx, cy + 72f * s, paint);
        paint.setColor(AnimeTheme.ACCENT);
        canvas.drawCircle(cx, cy + 75f * s, 3.2f * s, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#FFE4D6"));
        canvas.drawRect(cx - 9f * s, cy + 28f * s, cx + 9f * s, cy + 48f * s, paint);

        path.reset();
        path.moveTo(cx - 38f * s, cy - 18f * s);
        path.quadTo(cx - 39f * s, cy + 16f * s, cx, cy + 34f * s);
        path.quadTo(cx + 39f * s, cy + 16f * s, cx + 38f * s, cy - 18f * s);
        path.quadTo(cx + 36f * s, cy - 52f * s, cx, cy - 52f * s);
        path.quadTo(cx - 36f * s, cy - 52f * s, cx - 38f * s, cy - 18f * s);
        path.close();
        canvas.drawPath(path, paint);

        paint.setColor(Color.parseColor("#44FF45C8"));
        canvas.drawOval(new RectF(cx - 28f * s, cy + 6f * s, cx - 15f * s, cy + 13f * s), paint);
        canvas.drawOval(new RectF(cx + 15f * s, cy + 6f * s, cx + 28f * s, cy + 13f * s), paint);

        drawEyes(canvas, cx, cy, s);
        drawMouth(canvas, cx, cy, s);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#DCD0F7"));
        path.reset();
        path.moveTo(cx - 42f * s, cy - 16f * s);
        path.quadTo(cx - 34f * s, cy - 58f * s, cx, cy - 58f * s);
        path.quadTo(cx + 34f * s, cy - 58f * s, cx + 42f * s, cy - 16f * s);
        path.lineTo(cx + 26f * s, cy - 32f * s);
        path.lineTo(cx + 14f * s, cy - 12f * s);
        path.lineTo(cx + 2f * s, cy - 30f * s);
        path.lineTo(cx - 10f * s, cy - 10f * s);
        path.lineTo(cx - 24f * s, cy - 30f * s);
        path.close();
        canvas.drawPath(path, paint);

        paint.setColor(AnimeTheme.SECONDARY);
        float px = cx + 25f * s;
        float py = cy - 34f * s;
        for (int i = 0; i < 5; i++) {
            double ang = Math.toRadians(i * 72 - 18);
            canvas.drawCircle(px + (float) Math.cos(ang) * 4.5f * s,
                    py + (float) Math.sin(ang) * 4.5f * s, 3.2f * s, paint);
        }
        paint.setColor(AnimeTheme.ACCENT);
        canvas.drawCircle(px, py, 2.2f * s, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5.5f * s);
        paint.setColor(Color.parseColor("#1D1836"));
        rect.set(cx - 47f * s, cy - 64f * s, cx + 47f * s, cy + 20f * s);
        canvas.drawArc(rect, 185f, 170f, false, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#191430"));
        canvas.drawRoundRect(new RectF(cx - 54f * s, cy - 22f * s, cx - 39f * s, cy + 8f * s), 6f * s, 6f * s, paint);
        canvas.drawRoundRect(new RectF(cx + 39f * s, cy - 22f * s, cx + 54f * s, cy + 8f * s), 6f * s, 6f * s, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * s);
        paint.setColor(AnimeTheme.ACCENT);
        canvas.drawRoundRect(new RectF(cx - 52f * s, cy - 19f * s, cx - 41f * s, cy + 5f * s), 5f * s, 5f * s, paint);
        canvas.drawRoundRect(new RectF(cx + 41f * s, cy - 19f * s, cx + 52f * s, cy + 5f * s), 5f * s, 5f * s, paint);
    }

    private void drawEyes(Canvas canvas, float cx, float cy, float s) {
        float ey = cy - 2f * s;
        float lx = cx - 16f * s;
        float rx = cx + 16f * s;

        if (expression == Expression.SLEEPY) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.4f * s);
            paint.setColor(Color.parseColor("#3B2863"));
            canvas.drawLine(lx - 7f * s, ey + 2f * s, lx + 7f * s, ey + 2f * s, paint);
            canvas.drawLine(rx - 7f * s, ey + 2f * s, rx + 7f * s, ey + 2f * s, paint);
            return;
        }
        if (expression == Expression.CELEBRATING) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.6f * s);
            paint.setColor(Color.parseColor("#3B2863"));
            rect.set(lx - 7f * s, ey - 4f * s, lx + 7f * s, ey + 8f * s);
            canvas.drawArc(rect, 190f, 160f, false, paint);
            rect.set(rx - 7f * s, ey - 4f * s, rx + 7f * s, ey + 8f * s);
            canvas.drawArc(rect, 190f, 160f, false, paint);
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawOval(new RectF(lx - 8f * s, ey - 6f * s, lx + 8f * s, ey + 7f * s), paint);
        canvas.drawOval(new RectF(rx - 8f * s, ey - 6f * s, rx + 8f * s, ey + 7f * s), paint);

        paint.setColor(AnimeTheme.PRIMARY);
        canvas.drawCircle(lx, ey + 0.5f * s, 5.4f * s, paint);
        canvas.drawCircle(rx, ey + 0.5f * s, 5.4f * s, paint);

        paint.setColor(Color.parseColor("#2A0E5E"));
        canvas.drawCircle(lx, ey + 0.5f * s, 2.6f * s, paint);
        canvas.drawCircle(rx, ey + 0.5f * s, 2.6f * s, paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(lx - 2f * s, ey - 2f * s, 1.8f * s, paint);
        canvas.drawCircle(rx - 2f * s, ey - 2f * s, 1.8f * s, paint);
    }

    private void drawMouth(Canvas canvas, float cx, float cy, float s) {
        float my = cy + 17f * s;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * s);
        paint.setColor(Color.parseColor("#B84A62"));
        rect.set(cx - 6f * s, my - 2f * s, cx + 6f * s, my + 5f * s);
        canvas.drawArc(rect, 15f, 150f, false, paint);
    }
}
