package com.gamepulse.app;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gamepulse.app.ui.AnimeTheme;

import java.util.Locale;

public class OverlayService extends Service {

    private WindowManager wm;
    private LinearLayout capsuleView;
    private TextView telemetryLabel;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable updater = new Runnable() {
        @Override
        public void run() {
            if (telemetryLabel != null) {
                Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                float tempC = 35.0f;
                if (bat != null) {
                    tempC = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) / 10f;
                }
                SharedPreferences prefs = getSharedPreferences("gamepulse_prefs", MODE_PRIVATE);
                int fps = Math.round(prefs.getFloat("last_measured_fps", 60f));
                telemetryLabel.setText(String.format(Locale.US, "● %d FPS  ·  %.1f°C", fps, tempC));
            }
            handler.postDelayed(this, 1500L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        capsuleView = new LinearLayout(this);
        capsuleView.setOrientation(LinearLayout.HORIZONTAL);
        capsuleView.setGravity(Gravity.CENTER_VERTICAL);
        capsuleView.setPadding(AnimeTheme.dp(this, 14), AnimeTheme.dp(this, 7),
                AnimeTheme.dp(this, 14), AnimeTheme.dp(this, 7));
        capsuleView.setBackground(AnimeTheme.cardDrawable(
                this, 0xE6090817, AnimeTheme.PRIMARY, 20));

        telemetryLabel = new TextView(this);
        telemetryLabel.setText("● 60 FPS  ·  35.0°C");
        telemetryLabel.setTextColor(AnimeTheme.ACCENT);
        telemetryLabel.setTextSize(12f);
        telemetryLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        capsuleView.addView(telemetryLabel);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = AnimeTheme.dp(this, 16);
        params.y = AnimeTheme.dp(this, 48);

        capsuleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        wm.updateViewLayout(capsuleView, params);
                        return true;
                }
                return false;
            }
        });

        wm.addView(capsuleView, params);
        handler.post(updater);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updater);
        if (wm != null && capsuleView != null) {
            wm.removeView(capsuleView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
