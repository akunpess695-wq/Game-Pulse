package com.gamepulse.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

public class TelemetryGaugeView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcBounds = new RectF();

    private float progress = 0.75f;
    private String valueText = "60";
    private String labelText = "FPS";
    private int ringColor = AnimeTheme.ACCENT;

    public TelemetryGaugeView(Context context) {
        super(context);
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setColor(AnimeTheme.STROKE);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        valuePaint.setColor(AnimeTheme.TEXT_PRIMARY);
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        labelPaint.setColor(AnimeTheme.TEXT_SECONDARY);
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setMetric(float fraction, String value, String label, int color) {
        this.progress = Math.max(0f, Math.min(1f, fraction));
        this.valueText = value;
        this.labelText = label;
        this.ringColor = color;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float stroke = Math.min(w, h) * 0.085f;
        trackPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setColor(ringColor);

        arcBounds.set(stroke, stroke, w - stroke, h - stroke);
        canvas.drawArc(arcBounds, 135f, 270f, false, trackPaint);
        canvas.drawArc(arcBounds, 135f, 270f * progress, false, progressPaint);

        valuePaint.setTextSize(Math.min(w, h) * 0.21f);
        labelPaint.setTextSize(Math.min(w, h) * 0.11f);
        float cx = w * 0.5f;
        float cy = h * 0.52f;
        canvas.drawText(valueText, cx, cy, valuePaint);
        canvas.drawText(labelText, cx, cy + labelPaint.getTextSize() * 1.45f, labelPaint);
    }
}
