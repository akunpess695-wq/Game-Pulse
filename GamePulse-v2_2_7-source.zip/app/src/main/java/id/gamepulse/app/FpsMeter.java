package id.gamepulse.app;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class FpsMeter {
    private FpsMeter() {}

    private static final int MAXMS = 100, RES = 10;
    private static final long NONE = Long.MAX_VALUE;
    private static final long[] HIST = new long[MAXMS * RES + 1];
    private static long n, lastTs;
    private static double sum, sumSq;
    private static String layer;
    private static String trackedPkg;

    static volatile float live = -1f;
    static volatile String status = "";
    static volatile long nextMs = 2000L;
    static final long ACC_MIN_MS = 1000L, SLOW_MS = 3000L;

    static synchronized void reset(SharedPreferences p) {
        java.util.Arrays.fill(HIST, 0L);
        n = 0; lastTs = 0; sum = 0; sumSq = 0; layer = null; trackedPkg = null;
        live = -1f; status = ""; nextMs = 2000L;
        if (p != null) p.edit().remove("fps_avg").remove("fps_low").remove("fps_jit").remove("fps_n").apply();
    }

    static void sample(SharedPreferences p, String pkg) {
        String fg = foregroundPkg();
        boolean sess = p != null && !p.getString("active", "").isEmpty();
        if (sess && pkg != null && fg != null && !fg.equals(pkg)) {
            live = -1f;
            status = "FPS: game tidak sedang di layar (" + fg + ")";
            return;
        }
        String targetPkg = (fg != null && !fg.isEmpty()) ? fg : pkg;
        if (targetPkg == null || !targetPkg.matches("[A-Za-z0-9._]+")) {
            live = -1f;
            status = "FPS: buka game di layar untuk mulai mengukur";
            return;
        }

        String lay;
        synchronized (FpsMeter.class) {
            if (trackedPkg != null && !trackedPkg.equals(targetPkg)) {
                layer = null;
                lastTs = 0;
                java.util.Arrays.fill(HIST, 0L);
                n = 0; sum = 0; sumSq = 0;
                if (p != null) p.edit().remove("fps_avg").remove("fps_low").remove("fps_jit").remove("fps_n").apply();
            }
            trackedPkg = targetPkg;
            lay = layer;
        }

        if (lay == null) {
            List<String> candidates = new ArrayList<>();
            if (fg != null) candidates.add(fg);
            if (pkg != null && !pkg.equals(fg)) candidates.add(pkg);
            lay = findLayer(candidates.toArray(new String[0]));
            if (lay == null) {
                live = -1f;
                status = "FPS: layer game belum terdeteksi (" + targetPkg + ")";
                return;
            }
            synchronized (FpsMeter.class) { layer = lay; }
        }

        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency " + shellQuote(lay));
        if (out.startsWith("ERROR")) {
            live = -1f;
            status = "FPS: Shizuku gagal (" + out + ")";
            dropLayer();
            return;
        }

        int k = 0;
        double sumLocal = 0;
        long firstSeen = 0, lastSeen = 0;
        synchronized (FpsMeter.class) {
            String[] lines = out.split("\n");
            for (int i = 1; i < lines.length; i++) {
                String[] t0 = lines[i].trim().split("\\s+");
                if (t0.length < 3) continue;
                try {
                    long f = Long.parseLong(t0[1]);
                    if (f > 0 && f != NONE) {
                        if (lastTs > 0 && f > lastTs) lastTs = 0;
                        break;
                    }
                } catch (NumberFormatException ignored) { }
            }
            for (int i = 1; i < lines.length; i++) {
                String[] t = lines[i].trim().split("\\s+");
                if (t.length < 3) continue;
                long ts;
                try { ts = Long.parseLong(t[1]); } catch (NumberFormatException e) { continue; }
                if (ts <= 0 || ts == NONE) continue;
                if (firstSeen == 0) firstSeen = ts;
                lastSeen = ts;
                if (ts <= lastTs) continue;
                if (lastTs > 0) {
                    double ms = (ts - lastTs) / 1e6;
                    if (ms > 0 && ms <= 1000) {
                        HIST[Math.min((int) (ms * RES), MAXMS * RES)]++;
                        n++; sum += ms; sumSq += ms * ms;
                        k++; sumLocal += ms;
                    }
                }
                lastTs = ts;
            }
            if (k > 0) live = (float) (1000.0 * k / sumLocal);
        }

        long spanMs = (lastSeen - firstSeen) / 1000000L;
        boolean acc = p == null || p.getBoolean("fps_acc", true);
        nextMs = (acc && spanMs > 0) ? Math.max(ACC_MIN_MS, Math.min(SLOW_MS, (long) (spanMs * 0.7))) : 1500L;
        if (k == 0) {
            live = -1f;
            status = "FPS: menunggu frame baru (" + targetPkg + ")";
            dropLayer();
            return;
        }
        status = "";
        persist(p);
    }

    private static synchronized void dropLayer() { layer = null; lastTs = 0; }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static boolean isIgnoredPkg(String p) {
        if (p == null || p.isEmpty()) return true;
        return p.equals("id.gamepulse.app")
                || p.equals("android")
                || p.startsWith("com.android.systemui")
                || p.startsWith("com.android.launcher")
                || p.contains(".launcher")
                || p.equals("com.miui.home")
                || p.equals("com.mi.android.globallauncher")
                || p.equals("com.miui.securitycenter")
                || p.equals("com.xiaomi.joyose");
    }

    /** Paket aplikasi yang sedang tampil di layar (mendukung Android 10-15 / MIUI / HyperOS). */
    private static String foregroundPkg() {
        String out = ShizukuHelper.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp|mTopFullscreenOpaqueWindowState'");
        Matcher m = Pattern.compile("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/[A-Za-z0-9_.$]+").matcher(out);
        while (m.find()) {
            String p = m.group(1);
            if (!isIgnoredPkg(p)) return p;
        }
        String act = ShizukuHelper.exec("dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity'");
        Matcher m2 = Pattern.compile("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/[A-Za-z0-9_.$]+").matcher(act);
        while (m2.find()) {
            String p = m2.group(1);
            if (!isIgnoredPkg(p)) return p;
        }
        return null;
    }

    private static String findLayer(String[] pkgs) {
        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --list");
        if (out.startsWith("ERROR")) return null;
        String[] lines = out.split("\n");
        Set<String> orderedPkgs = new LinkedHashSet<>();
        for (String pkg : pkgs) {
            if (pkg != null && pkg.matches("[A-Za-z0-9._]+") && !isIgnoredPkg(pkg)) {
                orderedPkgs.add(pkg);
            }
        }
        for (String pkg : orderedPkgs) {
            Pattern pat = Pattern.compile("(?<![A-Za-z0-9._])" + Pattern.quote(pkg) + "(?![A-Za-z0-9_.])");
            String bestSurfaceView = null;
            String bestBlast = null;
            String bestActivity = null;
            String fallback = null;
            for (String l : lines) {
                String s = l.trim();
                if (s.isEmpty() || !pat.matcher(s).find()) continue;
                if (s.contains("Background") || s.contains("Bounds") || s.contains("Screenshot") || s.contains("DimLayer")) continue;
                if (s.startsWith("SurfaceView") || s.contains("SurfaceView[") || s.contains("SurfaceView -")) {
                    if (s.contains("BLAST")) {
                        bestBlast = s;
                        break;
                    }
                    if (bestSurfaceView == null) bestSurfaceView = s;
                } else if (s.contains("BLAST") && bestBlast == null) {
                    bestBlast = s;
                } else if (s.contains("/") && bestActivity == null) {
                    bestActivity = s;
                } else if (fallback == null) {
                    fallback = s;
                }
            }
            if (bestBlast != null) return bestBlast;
            if (bestSurfaceView != null) return bestSurfaceView;
            if (bestActivity != null) return bestActivity;
            if (fallback != null) return fallback;
        }
        return null;
    }

    private static synchronized void persist(SharedPreferences p) {
        if (p == null || n < 30) return;
        double mean = sum / n;
        double var = Math.max(0, sumSq / n - mean * mean);
        long target = Math.max(1, Math.round(n * 0.01)), acc = 0;
        int idx = 0;
        for (int i = MAXMS * RES; i >= 0; i--) { acc += HIST[i]; if (acc >= target) { idx = i; break; } }
        float low = (float) (1000.0 / ((idx + 0.5) / RES));
        p.edit().putFloat("fps_avg", (float) (1000.0 / mean)).putFloat("fps_low", low)
                .putFloat("fps_jit", (float) Math.sqrt(var)).putInt("fps_n", (int) Math.min(n, Integer.MAX_VALUE)).apply();
    }
}
