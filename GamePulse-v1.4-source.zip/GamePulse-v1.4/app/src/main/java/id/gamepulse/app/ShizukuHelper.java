package id.gamepulse.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import rikka.shizuku.Shizuku;

/** Perintah setingkat ADB lewat Shizuku (opsional, tanpa root). Semua pemanggilan dibungkus agar tidak membuat app crash. */
final class ShizukuHelper {
    private ShizukuHelper() {}

    static final int REQ = 4101;
    private static final String K_RES = "res_changed";

    static boolean running() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    static boolean granted() {
        try { return running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    static void requestPermission() {
        try { Shizuku.requestPermission(REQ); } catch (Throwable ignored) { }
    }

    /** Jalankan perintah shell lewat Shizuku (BLOKIR: panggil dari thread latar). Mengembalikan keluaran gabungan. */
    static String exec(String cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null});
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            p.waitFor();
            return sb.toString().trim();
        } catch (Throwable t) {
            return "ERROR: " + t.getClass().getSimpleName();
        }
    }

    static void forceStop(List<String> pkgs) {
        for (String p : pkgs) exec("am force-stop " + p);
    }

    /** Turunkan resolusi ke persen tertentu dengan rasio tetap. Mengembalikan teks hasil. */
    static String lowerResolution(SharedPreferences prefs, int percent) {
        String out = exec("wm size");
        Matcher m = Pattern.compile("Physical size:\\s*(\\d+)x(\\d+)").matcher(out);
        if (!m.find()) return "Gagal membaca ukuran layar: " + out;
        int w = even(Integer.parseInt(m.group(1)) * percent / 100);
        int h = even(Integer.parseInt(m.group(2)) * percent / 100);
        prefs.edit().putBoolean(K_RES, true).apply(); // tandai dulu agar bisa dipulihkan walau app tertutup
        String r = exec("wm size " + w + "x" + h);
        return r.isEmpty() ? "Resolusi " + w + "x" + h : r;
    }

    static void resetResolution(SharedPreferences prefs) {
        exec("wm size reset");
        prefs.edit().remove(K_RES).apply();
    }

    private static int even(int v) { return v - (v % 2); }

    static boolean resolutionChanged(SharedPreferences prefs) {
        return prefs.getBoolean(K_RES, false);
    }

    /** Eksperimental: sintaks berbeda antar versi Android; keluaran asli ditampilkan agar bisa diperiksa. */
    static String gameModePerformance(String pkg) {
        String a = exec("cmd game set --mode performance --user 0 " + pkg);
        if (a.isEmpty() || !a.toLowerCase().contains("error") && !a.toLowerCase().contains("unknown")) return a.isEmpty() ? "OK (tanpa keluaran)" : a;
        return exec("cmd game mode performance " + pkg);
    }

    private static final String K_HZ = "hz_prev";
    private static final String K_IDLE = "idle_pkg";

    /** Kunci refresh rate (min & puncak) ke nilai tertentu; nilai lama disimpan agar bisa dikembalikan. */
    static String lockRefreshRate(SharedPreferences prefs, int hz) {
        if (!prefs.contains(K_HZ)) {
            String pk = exec("settings get system peak_refresh_rate");
            String mn = exec("settings get system min_refresh_rate");
            prefs.edit().putString(K_HZ, pk + "|" + mn).apply(); // simpan dulu agar bisa dipulihkan walau app tertutup
        }
        exec("settings put system peak_refresh_rate " + hz);
        exec("settings put system min_refresh_rate " + hz);
        return "Refresh rate dikunci " + hz + " Hz";
    }

    static void restoreRefreshRate(SharedPreferences prefs) {
        String s = prefs.getString(K_HZ, null);
        if (s == null) return;
        String[] v = s.split("\\|", -1);
        putOrDelete("peak_refresh_rate", v.length > 0 ? v[0] : "");
        putOrDelete("min_refresh_rate", v.length > 1 ? v[1] : "");
        prefs.edit().remove(K_HZ).apply();
    }

    private static void putOrDelete(String key, String val) {
        if (val.matches("[0-9]+(\\.[0-9]+)?")) exec("settings put system " + key + " " + val);
        else exec("settings delete system " + key); // nilai asli kosong/"null"
    }

    /** Cegah game dibatasi Doze/standby: whitelist hemat daya + bucket aktif. Hanya dicatat bila kita yang menambahkan. */
    static void boostApp(SharedPreferences prefs, String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z0-9._]+")) return;
        String cur = exec("cmd deviceidle whitelist");
        if (!cur.contains("," + pkg + ",")) {
            exec("cmd deviceidle whitelist +" + pkg);
            prefs.edit().putString(K_IDLE, pkg).apply();
        }
        exec("am set-standby-bucket " + pkg + " active");
    }

    static void unboostApp(SharedPreferences prefs) {
        String pkg = prefs.getString(K_IDLE, null);
        if (pkg == null) return;
        exec("cmd deviceidle whitelist -" + pkg);
        prefs.edit().remove(K_IDLE).apply();
    }

    static boolean pendingRestore(SharedPreferences prefs) {
        return prefs.getBoolean(K_RES, false) || prefs.contains(K_HZ) || prefs.contains(K_IDLE);
    }

    /** Kembalikan semua perubahan Shizuku (resolusi, refresh rate, whitelist). Panggil dari thread latar. */
    static void restoreAll(SharedPreferences prefs) {
        if (prefs.getBoolean(K_RES, false)) resetResolution(prefs);
        restoreRefreshRate(prefs);
        unboostApp(prefs);
    }
}
