package id.gamepulse.app;

import android.content.SharedPreferences;

/**
 * Pengukur FPS lewat Shizuku: membaca timestamp frame dari SurfaceFlinger (dumpsys SurfaceFlinger --latency).
 * Menghitung FPS rata-rata, 1% low, dan jitter dari histogram waktu-antar-frame. Sampel berkala (bukan kontinu),
 * jadi angkanya perkiraan. BELUM TERVERIFIKASI di HyperOS: status ditampilkan agar mudah didiagnosis.
 */
final class FpsMeter {
    private FpsMeter() {}

    private static final int MAXMS = 100;
    private static final long NONE = Long.MAX_VALUE;
    private static final long[] HIST = new long[MAXMS + 1];
    private static long n, lastTs;
    private static double sum, sumSq;
    private static String layer;

    /** FPS jendela terakhir (-1 jika belum ada). */
    static volatile float live = -1f;
    /** Pesan diagnosis singkat. */
    static volatile String status = "";

    static synchronized void reset(SharedPreferences p) {
        java.util.Arrays.fill(HIST, 0L);
        n = 0; lastTs = 0; sum = 0; sumSq = 0; layer = null;
        live = -1f; status = "";
        if (p != null) p.edit().remove("fps_avg").remove("fps_low").remove("fps_jit").remove("fps_n").apply();
    }

    /** BLOKIR: panggil dari thread latar. */
    static void sample(SharedPreferences p, String pkg) {
        if (pkg == null || !pkg.matches("[A-Za-z0-9._]+")) { status = "FPS: paket game tidak diketahui"; return; }
        String lay;
        synchronized (FpsMeter.class) { lay = layer; }
        if (lay == null) {
            lay = findLayer(pkg);
            if (lay == null) { live = -1f; status = "FPS: layar game belum ditemukan"; return; }
            synchronized (FpsMeter.class) { layer = lay; }
        }
        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency '" + lay + "'");
        if (out.startsWith("ERROR")) { live = -1f; status = "FPS: Shizuku gagal (" + out + ")"; dropLayer(); return; }
        int k = 0;
        double sumLocal = 0;
        synchronized (FpsMeter.class) {
            String[] lines = out.split("\n");
            for (int i = 1; i < lines.length; i++) {
                String[] t = lines[i].trim().split("\\s+");
                if (t.length < 3) continue;
                long ts;
                try { ts = Long.parseLong(t[1]); } catch (NumberFormatException e) { continue; }
                if (ts <= 0 || ts == NONE || ts <= lastTs) continue;
                if (lastTs > 0) {
                    double ms = (ts - lastTs) / 1e6;
                    if (ms > 0 && ms <= 1000) {
                        HIST[Math.min((int) ms, MAXMS)]++;
                        n++; sum += ms; sumSq += ms * ms;
                        k++; sumLocal += ms;
                    }
                }
                lastTs = ts;
            }
            if (k > 0) live = (float) (1000.0 * k / sumLocal);
        }
        if (k == 0) { live = -1f; status = "FPS: menunggu frame game"; dropLayer(); return; }
        status = "";
        persist(p);
    }

    private static synchronized void dropLayer() { layer = null; lastTs = 0; }

    private static String findLayer(String pkg) {
        String out = ShizukuHelper.exec("dumpsys SurfaceFlinger --list");
        String best = null, any = null;
        for (String l : out.split("\n")) {
            String s = l.trim();
            if (s.isEmpty() || s.indexOf('\'') >= 0 || !s.contains(pkg)) continue;
            if (s.contains("SurfaceView") && !s.contains("Background")) { best = s; break; }
            if (any == null && !s.contains("Bounds")) any = s;
        }
        return best != null ? best : any;
    }

    private static synchronized void persist(SharedPreferences p) {
        if (n < 30) return;
        double mean = sum / n;
        double var = Math.max(0, sumSq / n - mean * mean);
        long target = Math.max(1, Math.round(n * 0.01)), acc = 0;
        int idx = 0;
        for (int i = MAXMS; i >= 0; i--) { acc += HIST[i]; if (acc >= target) { idx = i; break; } }
        float low = (float) (1000.0 / (idx + 0.5));
        p.edit().putFloat("fps_avg", (float) (1000.0 / mean)).putFloat("fps_low", low)
                .putFloat("fps_jit", (float) Math.sqrt(var)).putInt("fps_n", (int) Math.min(n, Integer.MAX_VALUE)).apply();
    }
}
