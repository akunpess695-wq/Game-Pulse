package id.gamepulse.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.PowerManager;
import java.util.Locale;

/** Pembaca status perangkat. Semua nilai berasal dari API resmi Android. */
final class DeviceInfo {
    private DeviceInfo() {}

    private static final String[] THERMAL = {"Normal", "Ringan", "Sedang", "Berat", "Kritis", "Darurat", "Shutdown"};

    private static Intent battery(Context c) {
        return c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    static int level(Context c) {
        Intent b = battery(c);
        if (b == null) return -1;
        int a = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return (s <= 0 || a < 0) ? -1 : Math.round(a * 100f / s);
    }

    /** Suhu baterai dalam derajat Celsius, atau NaN jika tidak tersedia. */
    static float tempC(Context c) {
        Intent b = battery(c);
        if (b == null) return Float.NaN;
        int v = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        return v == Integer.MIN_VALUE ? Float.NaN : v / 10f;
    }

    static String tempText(float t) {
        return Float.isNaN(t) ? "N/A" : String.format(Locale.US, "%.1f°C", t);
    }

    static boolean charging(Context c) {
        Intent b = battery(c);
        if (b == null) return false;
        int s = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL;
    }

    /** Status thermal Android 0..6, atau -1 jika tidak tersedia. */
    static int thermalStatus(Context c) {
        try {
            PowerManager p = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return p == null ? -1 : p.getCurrentThermalStatus();
        } catch (Exception e) {
            return -1;
        }
    }

    static String thermalText(Context c) {
        int i = thermalStatus(c);
        return (i >= 0 && i < THERMAL.length) ? THERMAL[i] : "N/A";
    }

    /** 0 = aman, 1 = mulai hangat, 2 = panas. */
    static int heatLevel(Context c) {
        int th = thermalStatus(c);
        float t = tempC(c);
        if (th >= 3 || (!Float.isNaN(t) && t >= 43f)) return 2;
        if (th >= 2 || (!Float.isNaN(t) && t >= 40f)) return 1;
        return 0;
    }

    static String ram(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return "N/A";
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(m);
        return String.format(Locale.US, "%.1f / %.1f GB", m.availMem / 1073741824.0, m.totalMem / 1073741824.0);
    }

    /** RAM tersedia dalam GB, atau -1 jika tidak diketahui. */
    static double ramAvailGb(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return -1;
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(m);
        return m.availMem / 1073741824.0;
    }

    static String network(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "Tidak diketahui";
            Network net = cm.getActiveNetwork();
            if (net == null) return "Offline";
            NetworkCapabilities n = cm.getNetworkCapabilities(net);
            if (n == null) return "Offline";
            if (n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (n.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Data seluler";
            if (n.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            return "Terhubung";
        } catch (Exception e) {
            return "Tidak diketahui";
        }
    }
}
