package id.gamepulse.app;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.PowerManager;
import java.util.HashSet;
import java.util.Set;

/** Optimasi pra-main lewat API resmi Android (tanpa root). Hasilnya terbatas dan dijelaskan jujur ke pengguna. */
final class Optimizer {
    private Optimizer() {}

    private static final String K_DND_PREV = "dnd_prev";

    /** Minta Android menghentikan proses latar aplikasi pengguna (bukan sistem, bukan GamePulse, bukan game). */
    static int cleanRam(Context c, String keepPkg) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return 0;
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Set<String> done = new HashSet<>();
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null) continue;
            ApplicationInfo ai = i.activityInfo.applicationInfo;
            String p = i.activityInfo.packageName;
            if (ai == null || (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (p.equals(c.getPackageName()) || p.equals(keepPkg) || !done.add(p)) continue;
            try { am.killBackgroundProcesses(p); } catch (Exception ignored) { }
        }
        return done.size();
    }

    /** Daftar paket aplikasi pengguna (non-sistem) yang punya ikon launcher, tanpa GamePulse dan paket keep. */
    static java.util.List<String> userPackages(Context c, String keepPkg) {
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Set<String> seen = new HashSet<>();
        java.util.List<String> out = new java.util.ArrayList<>();
        for (ResolveInfo i : pm.queryIntentActivities(q, 0)) {
            if (i.activityInfo == null || i.activityInfo.applicationInfo == null) continue;
            String p = i.activityInfo.packageName;
            if ((i.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (p.equals(c.getPackageName()) || p.equals(keepPkg) || !seen.add(p)) continue;
            out.add(p);
        }
        return out;
    }

    static boolean dndGranted(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    /** Aktifkan mode prioritas (panggilan/alarm tetap masuk). Simpan filter lama agar bisa dikembalikan. */
    static boolean dndOn(Context c, SharedPreferences p) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.isNotificationPolicyAccessGranted()) return false;
        if (p.getInt(K_DND_PREV, -1) < 0) p.edit().putInt(K_DND_PREV, nm.getCurrentInterruptionFilter()).apply();
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        return true;
    }

    /** Kembalikan filter notifikasi hanya jika GamePulse yang mengubahnya. */
    static void dndOff(Context c, SharedPreferences p) {
        int prev = p.getInt(K_DND_PREV, -1);
        if (prev < 0) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        try {
            if (nm != null && nm.isNotificationPolicyAccessGranted()) nm.setInterruptionFilter(prev);
        } catch (Exception ignored) { }
        p.edit().remove(K_DND_PREV).apply();
    }

    static boolean powerSave(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isPowerSaveMode();
    }
}
