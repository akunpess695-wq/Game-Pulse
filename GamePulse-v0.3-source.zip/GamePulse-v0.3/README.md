# GamePulse v0.3 — Redline Extreme

Native Java Android project targeting Redmi Note 12 Pro 5G, Android 14. Original abstract redline game banners and custom GP launcher icon are included as PNG resources. No publisher game artwork is included.

## Functional features
- Native AMOLED black/red gaming dashboard, game banners, custom launcher icon, four-tab navigation.
- Real battery percentage, battery temperature and Android thermal status; no fake FPS display.
- eFootball (`jp.konami.pesam`) launch using Android PackageManager, and Monster Hunter Outlanders discovery by visible launcher label.
- Local session start/end, battery and temperature before/after, session history in SharedPreferences.
- Shortcuts to Android display, battery and notification settings.

## Limits
- Profiles are **recommendations only**, not CPU/GPU tuning.
- No root, Shizuku, overclocking, overlay, thermal bypass, FPS capture, or force-stop.
- White-screen issue is not confirmed fixed until tested on device; app starts game launcher intent directly without WebView or game overlay.
- Monster Hunter package discovery may fail on OEM devices or localized labels; user can launch from home screen.
- Debug APK is not built or tested in this authoring environment; use GitHub Actions.

## Build without manual extraction
1. Upload **GamePulse-v0.3-source.zip** unchanged to repository root on `main`.
2. Place workflow contents at `.github/workflows/build.yml`.
3. GitHub Actions > Build GamePulse v0.3 APK from ZIP > Run workflow.
4. Download artifact `GamePulse-v0.3-debug-APK` after successful build.

If upgrading over previous version, application ID remains `id.gamepulse.app`; debug signing keys may differ across GitHub runners, so Android may require uninstalling the previous debug APK first (which removes its locally stored session history).
