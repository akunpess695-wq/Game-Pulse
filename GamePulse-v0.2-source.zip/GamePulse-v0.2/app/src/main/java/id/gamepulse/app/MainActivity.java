package id.gamepulse.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int BG=0xFF08090C, PANEL=0xFF14161B, PANEL2=0xFF1D2026, RED=0xFFFF344C, WHITE=0xFFF7F7F9, MUTED=0xFF9A9FA9, GREEN=0xFF57D5A0;
    private static final String EF="eFootball", MH="Monster Hunter Outlanders";
    private LinearLayout body, root;
    private String selected=EF, tab="home";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable ticker=new Runnable(){public void run(){if(!isFinishing() && !isDestroyed()){draw();handler.postDelayed(this,20000);}}};
    private SharedPreferences prefs(){return getSharedPreferences("gamepulse_v2",MODE_PRIVATE);}
    @Override public void onCreate(Bundle state){super.onCreate(state);selected=prefs().getString("selected",EF);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);draw();}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);draw();handler.postDelayed(ticker,20000);}
    @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setIncludeFontPadding(true);return t;}
    private void add(LinearLayout parent,View v,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(v,p);}
    private void space(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private LinearLayout panel(String heading){LinearLayout p=column();p.setPadding(dp(17),dp(16),dp(17),dp(18));p.setBackground(shape(PANEL,18,0xFF282C34));add(body,p,15);if(heading!=null)add(p,txt(heading,16,WHITE,true),0);return p;}
    private void pill(LinearLayout p,String s,int color){TextView v=txt(s,11,color,true);v.setPadding(dp(10),dp(7),dp(10),dp(7));v.setBackground(shape(0xFF262A30,30,0));add(p,v,10);}
    private void action(LinearLayout parent,String label,boolean primary,Runnable r){TextView b=txt(label,14,primary?WHITE:WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(15),dp(14),dp(15));b.setBackground(shape(primary?RED:PANEL2,13,primary?0:0xFF30343D));add(parent,b,12);b.setOnClickListener(v->r.run());}
    private Intent battery(){return registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));}
    private int level(Intent i){if(i==null)return -1;int a=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),b=i.getIntExtra(BatteryManager.EXTRA_SCALE,-1);return a<0||b<=0?-1:Math.round(a*100f/b);}
    private String temperature(Intent i){if(i==null)return "N/A";int t=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Integer.MIN_VALUE);return t==Integer.MIN_VALUE?"N/A":String.format(Locale.US,"%.1f°C",t/10f);}
    private String thermal(){PowerManager p=(PowerManager)getSystemService(POWER_SERVICE);if(p==null)return "N/A";int s=p.getCurrentThermalStatus();String[] a={"Normal","Ringan","Sedang","Berat","Kritis","Darurat","Shutdown"};return s>=0&&s<a.length?a[s]:"N/A";}
    private void metric(LinearLayout r,String label,String value,int color){LinearLayout c=column();c.setPadding(dp(10),dp(14),dp(7),dp(14));c.setBackground(shape(PANEL2,12,0));TextView v=txt(value,20,color,true);v.setGravity(Gravity.CENTER);add(c,v,0);TextView k=txt(label,11,MUTED,false);k.setGravity(Gravity.CENTER);add(c,k,4);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.rightMargin=dp(7);r.addView(c,lp);}
    private void keyValue(LinearLayout p,String a,String b){LinearLayout r=row();TextView l=txt(a,13,MUTED,false),v=txt(b,13,WHITE,true);r.addView(l,new LinearLayout.LayoutParams(0,-2,1));r.addView(v);add(p,r,13);}
    private void draw(){
        root=column();root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        body=column();body.setPadding(dp(19),dp(22),dp(19),dp(28));scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        header();
        if(tab.equals("home"))home();else if(tab.equals("games"))games();else if(tab.equals("sessions"))sessions();else settings();
        navigation();setContentView(root);
    }
    private void header(){LinearLayout h=row();TextView logo=txt("◈  GAMEPULSE",17,WHITE,true);h.addView(logo,new LinearLayout.LayoutParams(0,-2,1));TextView version=txt("V0.2  /  REDLINE",10,RED,true);h.addView(version);add(body,h,0);View line=new View(this);line.setBackgroundColor(RED);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(46),dp(3));lp.topMargin=dp(13);body.addView(line,lp);}
    private void title(String a,String b){add(body,txt(a,27,WHITE,true),21);add(body,txt(b,13,MUTED,false),6);}
    private void home(){
        title("READY TO PLAY.","Redmi Note 12 Pro 5G  •  RAM 8 GB");
        LinearLayout stats=panel("DEVICE LIVE STATUS");Intent b=battery();LinearLayout r=row();metric(r,"BATERAI",level(b)<0?"N/A":level(b)+"%",WHITE);metric(r,"SUHU BATERAI",temperature(b),RED);metric(r,"THERMAL",thermal(),GREEN);add(stats,r,14);
        keyValue(stats,"Android",Build.VERSION.RELEASE);keyValue(stats,"Perangkat",Build.MANUFACTURER+" "+Build.MODEL);
        LinearLayout game=panel("GAME LIBRARY");gameItem(game,EF,"COMPETITIVE  /  STABILITY");gameItem(game,MH,"BALANCED  /  THERMAL");
        LinearLayout launch=panel("QUICK LAUNCH");add(launch,txt(selected,20,WHITE,true),10);add(launch,txt(selected.equals(EF)?"Grafis Standard • target 60 FPS jika tersedia":"Grafis Low • target 30 FPS jika tersedia",12,MUTED,false),7);action(launch,"▶  MULAI SESI & BUKA GAME",true,()->launchWithSession());action(launch,"BUKA GAME SAJA",false,()->launch());
        add(body,txt("Tidak ada overclock, overlay, atau bypass thermal. FPS bukan hasil pengukuran langsung.",11,MUTED,false),19);
    }
    private void gameItem(LinearLayout parent,String name,String subtitle){LinearLayout item=column();item.setPadding(dp(13),dp(13),dp(13),dp(13));boolean active=selected.equals(name);item.setBackground(shape(active?0xFF33191F:PANEL2,13,active?RED:0xFF343841));add(item,txt((active?"●  ":"○  ")+name,15,WHITE,true),0);add(item,txt(subtitle,11,active?0xFFFF9EAA:MUTED,false),5);add(parent,item,11);item.setOnClickListener(v->{selected=name;prefs().edit().putString("selected",name).apply();draw();});}
    private void games(){title("GAME PROFILES.","Pilih game dan konfigurasi awal.");LinearLayout p=panel("SELECT GAME");gameItem(p,EF,"RESPONS KONTROL & KONEKSI");gameItem(p,MH,"FRAME PACING & SUHU");LinearLayout q=panel("RECOMMENDED BASELINE");if(selected.equals(EF)){keyValue(q,"Grafis","Standard");keyValue(q,"Frame rate","60 jika tersedia");keyValue(q,"Koneksi","Wi-Fi stabil");}else{keyValue(q,"Grafis","Low");keyValue(q,"Frame rate","30 jika tersedia");keyValue(q,"Efek / bayangan","Rendah");}add(q,txt("Pengaturan grafis harus diterapkan dari menu game. Profil ini tidak mengubah sistem secara otomatis.",12,MUTED,false),16);action(q,"▶  BUKA "+selected.toUpperCase(Locale.ROOT),true,()->launch());}
    private void sessions(){title("SESSION TRACKER.","Pantau baterai dan suhu sebelum/sesudah bermain.");LinearLayout p=panel("CURRENT SESSION");String active=prefs().getString("active","");if(active.isEmpty()){add(p,txt("Belum ada sesi aktif.",13,MUTED,false),10);action(p,"MULAI SESI "+selected.toUpperCase(Locale.ROOT),true,()->startSession());}else{long mins=Math.max(0,(System.currentTimeMillis()-prefs().getLong("started",System.currentTimeMillis()))/60000);add(p,txt(active+"  •  "+mins+" menit",17,WHITE,true),13);action(p,"AKHIRI & SIMPAN SESI",true,()->endSession());action(p,"▶  BUKA GAME",false,()->launch());}LinearLayout h=panel("SESSION HISTORY");String history=prefs().getString("history","");add(h,txt(history.isEmpty()?"Belum ada sesi tersimpan.":history,13,history.isEmpty()?MUTED:WHITE,false),13);}
    private void settings(){title("CONTROL CENTER.","Pengaturan aman tanpa root.");LinearLayout p=panel("ANDROID SHORTCUTS");action(p,"PENGATURAN LAYAR",false,()->openSetting(Settings.ACTION_DISPLAY_SETTINGS));action(p,"PENGATURAN BATERAI",false,()->openSetting(Settings.ACTION_BATTERY_SAVER_SETTINGS));action(p,"PENGATURAN NOTIFIKASI",false,()->openSetting(Settings.ACTION_APP_NOTIFICATION_SETTINGS));LinearLayout q=panel("ABOUT GAMEPULSE");add(q,txt("GamePulse tidak menutup paksa aplikasi lain, mengubah clock CPU/GPU, mengukur FPS game pihak ketiga, atau menghilangkan batas thermal. Data sesi disimpan lokal.",13,MUTED,false),12);}
    private void navigation(){LinearLayout nav=row();nav.setPadding(dp(10),dp(9),dp(10),dp(10));nav.setBackground(shape(0xFF111318,0,0));String[] ids={"home","games","sessions","settings"},labels={"⌂  HOME","▣  GAMES","◷  SESSIONS","⚙  TOOLS"};for(int i=0;i<ids.length;i++){final String id=ids[i];TextView t=txt(labels[i],10,tab.equals(id)?RED:MUTED,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(4),dp(12),dp(4),dp(12));if(tab.equals(id))t.setBackground(shape(0xFF30171C,10,0));nav.addView(t,new LinearLayout.LayoutParams(0,-2,1));t.setOnClickListener(v->{tab=id;draw();});}root.addView(nav);}
    private void startSession(){if(!prefs().getString("active","").isEmpty()){Toast.makeText(this,"Sesi sebelumnya masih aktif",Toast.LENGTH_SHORT).show();return;}Intent b=battery();prefs().edit().putString("active",selected).putLong("started",System.currentTimeMillis()).putInt("startBattery",level(b)).putString("startTemp",temperature(b)).apply();draw();}
    private void endSession(){String active=prefs().getString("active","");if(active.isEmpty())return;long minutes=Math.max(0,(System.currentTimeMillis()-prefs().getLong("started",System.currentTimeMillis()))/60000);String record=new SimpleDateFormat("dd MMM yyyy HH:mm",new Locale("id","ID")).format(new Date())+"\n"+active+" • "+minutes+" menit\nBaterai: "+prefs().getInt("startBattery",-1)+"% → "+level(battery())+"%\nSuhu baterai: "+prefs().getString("startTemp","N/A")+" → "+temperature(battery())+"\nThermal akhir: "+thermal();prefs().edit().putString("history",record+"\n\n"+prefs().getString("history","")).remove("active").remove("started").apply();draw();}
    private void launchWithSession(){boolean newSession=prefs().getString("active","").isEmpty();if(newSession)startSession();launch();}
    private void launch(){
        // Never create a blank Activity, WebView, splash overlay, or transparent window over the game.
        PackageManager pm=getPackageManager();Intent intent=null;
        if(selected.equals(EF))intent=pm.getLaunchIntentForPackage("jp.konami.pesam");
        else intent=findMonsterHunter(pm);
        if(intent==null){Toast.makeText(this,"Game belum ditemukan. Buka dari launcher HP; sesi tetap tercatat.",Toast.LENGTH_LONG).show();return;}
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try{startActivity(intent);}catch(Exception e){Toast.makeText(this,"Gagal membuka game. Coba buka dari launcher HP.",Toast.LENGTH_LONG).show();}
    }
    private Intent findMonsterHunter(PackageManager pm){
        // Package ID is not assumed. Find only launcher apps whose visible label matches.
        Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo info:pm.queryIntentActivities(query,0)){
            String label=String.valueOf(info.loadLabel(pm)).toLowerCase(Locale.ROOT);
            if(label.contains("monster hunter") && label.contains("outlanders")){
                return pm.getLaunchIntentForPackage(info.activityInfo.packageName);
            }
        }
        return null;
    }
    private void openSetting(String action){try{startActivity(new Intent(action));}catch(Exception e){Toast.makeText(this,"Pengaturan tidak tersedia",Toast.LENGTH_SHORT).show();}}
}
