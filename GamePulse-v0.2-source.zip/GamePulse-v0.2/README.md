# GamePulse v0.2 — Redline

Native Java Android gaming launcher and session tracker for Redmi Note 12 Pro 5G (8 GB RAM), Android 14. No root, no overlay, no Internet permission.

## Changes
- Redline AMOLED black/red dashboard, compact live device metrics, 4-tab navigation.
- eFootball launch uses `PackageManager.getLaunchIntentForPackage("jp.konami.pesam")` and Android's normal game activity; no GamePulse overlay, WebView, fake loading screen, or blank intermediary activity.
- Monster Hunter Outlanders launcher found by visible installed app label (no guessed package ID).
- Start/end session, battery, battery temperature, Android thermal status, locally stored history.
- Profiles are recommendations, not privileged performance changes or real FPS measurement.

## GitHub Actions without manual extraction
1. Upload `GamePulse-v0.2-source.zip` to repository root, unchanged.
2. Create or replace `.github/workflows/build.yml` with the separately supplied `build.yml`.
3. Actions → Build GamePulse v0.2 APK from ZIP → Run workflow.
4. Download the APK artifact. The runner extracts the ZIP automatically.

## Known limitations
The white screen observed while opening eFootball might be caused by game initialization, rendering, or game/device compatibility. This version removes app-side intermediary UI but cannot guarantee it resolves game-side white screens. Capture `adb logcat` around launch if it persists. Monster Hunter Outlanders discovery depends on the installed app's launcher label containing both `monster hunter` and `outlanders`.

No Android SDK or full Gradle build was available during packaging. Validate with GitHub Actions before installing.
