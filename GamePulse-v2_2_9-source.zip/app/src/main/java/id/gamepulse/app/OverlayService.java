package id.gamepulse.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class OverlayService extends Service {
    private static final String CH_HUD = "gp_hud";
    private static final String ACT_TOUCH = "id.gamepulse.app.HUD_TOGGLE_TOUCH";
    private static final int ID_HUD = 7003;
    private static final long TICK_MS = 1000L;
    private static final int MODE_MINI = 0, MODE_STRIP = 1, MODE_PANEL = 2;
    private static final int SIDE_CENTER = 0, SIDE_LEFT = 1, SIDE_RIGHT = 2;
    private static final int[] ALPHA_STEPS = {20, 35, 50, 70, 90};
    static volatile boolean isRunning = false;

    private WindowManager wm;
    private LinearLayout pill;
    private WindowManager.LayoutParams lp;
    private TextView tvFps, tvTemp, tvExtra, sep, btnBoost, btnHz, btnAlpha, btnClose;
    private LinearLayout actionsBox;
    private View dot;
    private Chamfer frame;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SessionStore store;
    private int mode = MODE_MINI;
    private int side = SIDE_CENTER;
    private long flashUntil = 0L;
    private boolean wasAlert = false;
    private long lastFpsAt;
    private final AtomicBoolean standaloneFpsBusy = new AtomicBoolean(false);

    /** Bingkai bersudut miring (chamfer) ala desain HUD merah-hitam; warnanya bisa diatur per mode. */
    private static final class Chamfer extends Drawable {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float cut;

        Chamfer(float cut, float stroke) {
            this.cut = cut;
            fill.setStyle(Paint.Style.FILL);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(stroke);
        }

        void set(int fillColor, int lineColor) {
            fill.setColor(fillColor);
            line.setColor(lineColor);
            invalidateSelf();
        }

        @Override protected void onBoundsChange(Rect b) {
            float i = line.getStrokeWidth() / 2f;
            float l = b.left + i, t = b.top + i, r = b.right - i, bt = b.bottom - i;
            float c = Math.min(cut, Math.min((r - l) / 2f, (bt - t) / 2f));
            path.reset();
            path.moveTo(l + c, t);
            path.lineTo(r - c, t);
            path.lineTo(r, t + c);
            path.lineTo(r, bt - c);
            path.lineTo(r - c, bt);
            path.lineTo(l + c, bt);
            path.lineTo(l, bt - c);
            path.lineTo(l, t + c);
            path.close();
        }

        @Override public void draw(Canvas c) {
            c.drawPath(path, fill);
            if (Color_alpha(line.getColor()) > 0) c.drawPath(path, line);
        }

        private static int Color_alpha(int color) { return (color >>> 24) & 0xFF; }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    static boolean canDraw(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static void start(Context c) {
        if (!canDraw(c)) return;
        try {
            c.startForegroundService(new Intent(c, OverlayService.class));
        } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, OverlayService.class));
        } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        store = new SessionStore(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CH_HUD, "Kapsul HUD FPS", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_HUD, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(ID_HUD, n);
        }
        if (!canDraw(this)) {
            stopSelf();
            return;
        }
        setupPill();
        if (pill == null) return;
        isRunning = true;
        h.post(tick);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACT_TOUCH.equals(intent.getAction()) && lp != null) {
            SharedPreferences sp = store.prefs();
            sp.edit().putBoolean("hud_through", !sp.getBoolean("hud_through", false)).apply();
            applyFlags();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(ID_HUD, buildNotification());
        }
        return START_NOT_STICKY;
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (pill != null) pill.post(this::clampPositionToScreen);
    }

    @Override public void onDestroy() {
        isRunning = false;
        h.removeCallbacks(tick);
        h.removeCallbacks(collapse);
        if (wm != null && pill != null) {
            try { wm.removeView(pill); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    private void applyGravity() {
        int hg = side == SIDE_LEFT ? Gravity.START : side == SIDE_RIGHT ? Gravity.END : Gravity.CENTER_HORIZONTAL;
        lp.gravity = Gravity.TOP | hg;
        lp.x = side == SIDE_CENTER ? 0 : dp(2);
    }

    private void clampPositionToScreen() {
        if (wm == null || pill == null || lp == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxY = Math.max(0, dm.heightPixels - Math.max(pill.getHeight(), dp(28)));
        lp.y = Math.max(0, Math.min(lp.y, maxY));
        try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) { }
    }

    private int computeFlags() {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (store.prefs().getBoolean("hud_through", false)) f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        return f;
    }

    private void applyFlags() {
        if (lp == null || pill == null || wm == null) return;
        lp.flags = computeFlags();
        try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) { }
    }

    private Notification buildNotification() {
        Intent in = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, in, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent ti = new Intent(this, OverlayService.class).setAction(ACT_TOUCH);
        PendingIntent tpi = PendingIntent.getService(this, 2, ti, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean through = store != null && store.prefs().getBoolean("hud_through", false);
        Notification.Action act = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_nav_tools),
                through ? "Aktifkan sentuh HUD" : "Mode tembus sentuh", tpi).build();
        return new Notification.Builder(this, CH_HUD)
                .setSmallIcon(R.drawable.ic_nav_tools)
                .setContentTitle("GamePulse HUD aktif")
                .setContentText(through ? "HUD tembus sentuh. Ketuk tombol di bawah untuk mengatur HUD lagi"
                        : "Ketuk HUD: lebar/mini • Tahan: panel aksi • Geser: pindah")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .addAction(act)
                .build();
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private void shadow(TextView t) {
        t.setShadowLayer(3f, 0f, 1f, 0xCC000000);
    }

    private final Runnable collapse = () -> setMode(MODE_MINI);

    private void rearm() {
        h.removeCallbacks(collapse);
        if (mode != MODE_MINI) h.postDelayed(collapse, mode == MODE_PANEL ? 8000L : 4000L);
    }

    private void setMode(int m) {
        mode = m;
        boolean mini = m == MODE_MINI;
        sep.setVisibility(mini ? View.GONE : View.VISIBLE);
        tvTemp.setVisibility(mini ? View.GONE : View.VISIBLE);
        tvExtra.setVisibility(mini ? View.GONE : View.VISIBLE);
        actionsBox.setVisibility(m == MODE_PANEL ? View.VISIBLE : View.GONE);
        int padH = mini ? dp(8) : dp(12);
        pill.setPadding(padH, dp(3), padH, dp(3));
        if (!mini && FpsMeter.shown() <= 0f) {
            Toast.makeText(this, "FPS: " + fpsReason(store.prefs()), Toast.LENGTH_SHORT).show();
        }
        render();
        rearm();
        pill.post(this::clampPositionToScreen);
    }

    private void applyStyle() {
        SharedPreferences sp = store.prefs();
        int a = sp.getInt("hud_alpha", 35);
        int pct = mode == MODE_MINI ? a : Math.min(95, a + 35);
        boolean flash = System.currentTimeMillis() < flashUntil;
        if (flash) pct = Math.max(pct, 85);
        int fill = ((pct * 255 / 100) << 24) | 0x0A0506;
        int line = flash ? 0xFFE0262D : (mode == MODE_MINI ? 0x44E0262D : 0xCCE0262D);
        frame.set(fill, line);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPill() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) { stopSelf(); return; }

        SharedPreferences sp = store.prefs();
        side = Math.max(0, Math.min(2, sp.getInt("hud_side", SIDE_CENTER)));

        pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setMinimumHeight(dp(28));
        pill.setPadding(dp(8), dp(3), dp(8), dp(3));

        frame = new Chamfer(dp(6), Math.max(1, dp(1)));
        pill.setBackground(frame);

        dot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Premium.OK);
        dot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dotLp.rightMargin = dp(6);
        pill.addView(dot, dotLp);

        tvFps = new TextView(this);
        tvFps.setText("--");
        tvFps.setTextColor(Premium.TEXT_2);
        tvFps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tvFps.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        tvFps.setSingleLine(true);
        shadow(tvFps);
        pill.addView(tvFps);

        sep = new TextView(this);
        sep.setText(" • ");
        sep.setTextColor(0x88FFFFFF);
        sep.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        shadow(sep);
        sep.setVisibility(View.GONE);
        pill.addView(sep);

        tvTemp = new TextView(this);
        tvTemp.setText("--°C");
        tvTemp.setTextColor(Premium.TEXT);
        tvTemp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvTemp.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        tvTemp.setSingleLine(true);
        shadow(tvTemp);
        tvTemp.setVisibility(View.GONE);
        pill.addView(tvTemp);

        tvExtra = new TextView(this);
        tvExtra.setTextColor(Premium.TEXT_2);
        tvExtra.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tvExtra.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        tvExtra.setPadding(dp(6), 0, 0, 0);
        tvExtra.setSingleLine(true);
        shadow(tvExtra);
        tvExtra.setVisibility(View.GONE);
        pill.addView(tvExtra);

        actionsBox = new LinearLayout(this);
        actionsBox.setOrientation(LinearLayout.HORIZONTAL);
        actionsBox.setGravity(Gravity.CENTER_VERTICAL);
        actionsBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(-2, -2);
        actLp.leftMargin = dp(8);

        btnBoost = chip("BOOST", Premium.OK, 0x224ADE80);
        btnBoost.setOnClickListener(v -> { rearm(); runQuickBoost(); });
        actionsBox.addView(btnBoost);

        boolean isLocked = sp.contains("hz_prev");
        btnHz = chip(isLocked ? "AUTO" : "60Hz", Premium.WARN, 0x22FBBF24);
        LinearLayout.LayoutParams hzLp = new LinearLayout.LayoutParams(-2, -2);
        hzLp.leftMargin = dp(5);
        btnHz.setOnClickListener(v -> { rearm(); toggleQuickHz(); });
        actionsBox.addView(btnHz, hzLp);

        btnAlpha = chip("◐" + sp.getInt("hud_alpha", 35), Premium.TEXT, 0x22FFFFFF);
        LinearLayout.LayoutParams alLp = new LinearLayout.LayoutParams(-2, -2);
        alLp.leftMargin = dp(5);
        btnAlpha.setOnClickListener(v -> {
            int cur = store.prefs().getInt("hud_alpha", 35);
            int next = ALPHA_STEPS[0];
            for (int i = 0; i < ALPHA_STEPS.length; i++) {
                if (ALPHA_STEPS[i] > cur) { next = ALPHA_STEPS[i]; break; }
            }
            store.prefs().edit().putInt("hud_alpha", next).apply();
            btnAlpha.setText("◐" + next);
            rearm();
            applyStyle();
        });
        actionsBox.addView(btnAlpha, alLp);

        TextView btnThrough = chip("TEMBUS", Premium.TEXT_2, 0x22FFFFFF);
        LinearLayout.LayoutParams thLp = new LinearLayout.LayoutParams(-2, -2);
        thLp.leftMargin = dp(5);
        btnThrough.setOnClickListener(v -> {
            store.prefs().edit().putBoolean("hud_through", true).apply();
            Toast.makeText(this, "HUD tembus sentuh. Buka lagi lewat tombol di notifikasi", Toast.LENGTH_LONG).show();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(ID_HUD, buildNotification());
            setMode(MODE_MINI);
            applyFlags();
        });
        actionsBox.addView(btnThrough, thLp);

        btnClose = new TextView(this);
        btnClose.setText("✕");
        btnClose.setTextColor(Premium.HOT);
        btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnClose.setTypeface(Typeface.DEFAULT_BOLD);
        btnClose.setPadding(dp(6), dp(2), dp(2), dp(2));
        LinearLayout.LayoutParams clsLp = new LinearLayout.LayoutParams(-2, -2);
        clsLp.leftMargin = dp(4);
        btnClose.setOnClickListener(v -> {
            store.prefs().edit().putBoolean("hud_on", false).apply();
            stopSelf();
        });
        actionsBox.addView(btnClose, clsLp);

        pill.addView(actionsBox, actLp);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                computeFlags(),
                PixelFormat.TRANSLUCENT
        );
        applyGravity();
        lp.y = sp.getInt("hud_y", dp(6));
        applyStyle();

        final int slop = dp(8);
        pill.setOnTouchListener(new View.OnTouchListener() {
            int initLeft, initY;
            float touchX, touchY;
            boolean dragging, longFired;
            final Runnable longPress = () -> {
                if (!dragging) {
                    longFired = true;
                    pill.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    setMode(mode == MODE_PANEL ? MODE_MINI : MODE_PANEL);
                }
            };

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        int[] xy = new int[2];
                        pill.getLocationOnScreen(xy);
                        initLeft = xy[0];
                        initY = lp.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        dragging = false;
                        longFired = false;
                        h.removeCallbacks(collapse);
                        h.postDelayed(longPress, 450L);
                        return true;
                    }
                    case MotionEvent.ACTION_MOVE: {
                        float dx = event.getRawX() - touchX, dy = event.getRawY() - touchY;
                        if (!dragging && !longFired && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            dragging = true;
                            h.removeCallbacks(longPress);
                            lp.gravity = Gravity.TOP | Gravity.START;
                            lp.x = initLeft;
                        }
                        if (dragging) {
                            lp.x = initLeft + Math.round(dx);
                            lp.y = initY + Math.round(dy);
                            try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) { }
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        h.removeCallbacks(longPress);
                        if (dragging) {
                            snapToSide();
                        } else if (!longFired && event.getAction() == MotionEvent.ACTION_UP) {
                            setMode(mode == MODE_MINI ? MODE_STRIP : MODE_MINI);
                        }
                        dragging = false;
                        rearm();
                        return true;
                    }
                }
                return false;
            }
        });

        wm.addView(pill, lp);
    }

    /** Setelah digeser: tempel ke kiri/kanan/tengah terdekat dan simpan posisi. */
    private void snapToSide() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.max(1, pill.getWidth());
        float f = (lp.x + w / 2f) / (float) Math.max(1, dm.widthPixels);
        side = f < 0.35f ? SIDE_LEFT : (f > 0.65f ? SIDE_RIGHT : SIDE_CENTER);
        applyGravity();
        clampPositionToScreen();
        store.prefs().edit().putInt("hud_side", side).putInt("hud_y", lp.y).apply();
    }

    private TextView chip(String label, int textColor, int bgColor) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(textColor);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        t.setPadding(dp(6), dp(2), dp(6), dp(2));
        t.setSingleLine(true);
        GradientDrawable d = new GradientDrawable();
        d.setColor(bgColor);
        d.setCornerRadius(dp(6));
        t.setBackground(d);
        return t;
    }

    private void runQuickBoost() {
        btnBoost.setText("...");
        final String keepPkg = store.prefs().getString("active_pkg", null);
        new Thread(() -> {
            Optimizer.cleanRam(getApplicationContext(), keepPkg);
            if (ShizukuHelper.granted()) {
                ShizukuHelper.forceStop(Optimizer.userPackages(getApplicationContext(), keepPkg));
            }
            h.post(() -> {
                btnBoost.setText("OK ✓");
                h.postDelayed(() -> btnBoost.setText("BOOST"), 1500);
            });
        }, "gp-hud-boost").start();
    }

    private void toggleQuickHz() {
        if (!ShizukuHelper.granted()) {
            Toast.makeText(this, "Shizuku belum aktif", Toast.LENGTH_SHORT).show();
            return;
        }
        final SharedPreferences sp = store.prefs();
        final boolean currentlyLocked = sp.contains("hz_prev");
        new Thread(() -> {
            if (!currentlyLocked) {
                ShizukuHelper.lockRefreshRate(sp, 60);
                h.post(() -> btnHz.setText("AUTO"));
            } else {
                ShizukuHelper.restoreRefreshRate(sp);
                h.post(() -> btnHz.setText("60Hz"));
            }
        }, "gp-hud-hz").start();
    }

    @SuppressWarnings("deprecation")
    private int currentDisplayHz() {
        try {
            if (wm != null && wm.getDefaultDisplay() != null) {
                return Math.round(wm.getDefaultDisplay().getRefreshRate());
            }
        } catch (Throwable ignored) { }
        return 60;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            SharedPreferences sp = store.prefs();
            boolean sessionHandled = store.active() && sp.getBoolean("svc_on", true);
            if (!sessionHandled && sp.getBoolean("sz_fps", true) && ShizukuHelper.granted()
                    && System.currentTimeMillis() - lastFpsAt >= FpsMeter.nextMs
                    && standaloneFpsBusy.compareAndSet(false, true)) {
                lastFpsAt = System.currentTimeMillis();
                final String pkg = sp.getString("active_pkg", null);
                new Thread(() -> {
                    try { FpsMeter.sample(sp, pkg); } finally { standaloneFpsBusy.set(false); }
                }, "gp-hud-fps").start();
            }
            render();
            h.postDelayed(this, TICK_MS);
        }
    };

    private void render() {
        if (pill == null || tvFps == null) return;
        SharedPreferences sp = store.prefs();
        boolean mini = mode == MODE_MINI;
        float liveFps = FpsMeter.shown();
        if (liveFps > 0f) {
            String n = String.valueOf(Math.round(liveFps));
            tvFps.setText(mini ? n : n + " FPS");
            int c = Premium.fpsColor(liveFps, 60f);
            tvFps.setTextColor(c);
            setDotColor(c);
        } else {
            tvFps.setText(mini ? "--" : "-- FPS");
            tvFps.setTextColor(Premium.TEXT_2);
            setDotColor(Premium.WARN);
        }

        float temp = DeviceInfo.tempC(this);
        boolean tempOk = !Float.isNaN(temp) && temp > 0f;
        if (!mini) {
            StringBuilder ex = new StringBuilder();
            float low = sp.getFloat("fps_low", -1f);
            if (liveFps > 0f && low > 0f && sp.getInt("fps_n", 0) >= 30) ex.append("L").append(Math.round(low)).append(" ");
            ex.append(currentDisplayHz()).append("Hz");
            int bat = batteryPct();
            if (bat >= 0) ex.append(" ").append(bat).append("%");
            tvExtra.setText(ex.toString());
            if (tempOk) {
                tvTemp.setText(String.format(Locale.US, "%.1f°C", temp));
                tvTemp.setTextColor(Premium.tempColor(temp, Thresholds.warm(this), Thresholds.hot(this)));
            } else {
                tvTemp.setText("N/A");
            }
            if (btnHz != null) btnHz.setText(sp.contains("hz_prev") ? "AUTO" : "60Hz");
        }

        boolean alert = (liveFps > 0f && liveFps < 24f) || (tempOk && temp >= Thresholds.hot(this));
        if (alert && !wasAlert) flashUntil = System.currentTimeMillis() + 3000L;
        wasAlert = alert;
        applyStyle();
    }

    private String fpsReason(SharedPreferences sp) {
        if (!ShizukuHelper.granted()) return "Shizuku belum aktif/diizinkan";
        if (!sp.getBoolean("sz_fps", true)) return "pengukuran FPS dimatikan di pengaturan";
        // auto-detect foreground game even when active_pkg is null
        String st = FpsMeter.status;
        if (st.isEmpty()) return "sedang mengukur";
        return st.startsWith("FPS: ") ? st.substring(5) : st;
    }

    private int batteryPct() {
        try {
            BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
            return bm == null ? -1 : bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Throwable t) { return -1; }
    }

    private void setDotColor(int color) {
        if (dot != null && dot.getBackground() instanceof GradientDrawable) {
            ((GradientDrawable) dot.getBackground()).setColor(color);
        }
    }
}
