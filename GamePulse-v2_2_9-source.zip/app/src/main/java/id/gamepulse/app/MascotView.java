package id.gamepulse.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * Original Anime Mascot View ("Sora — Cyber Sakura Companion").
 * Renders crisp vector-style anime character artwork on Canvas with 6 dynamic expressions:
 * HAPPY, EXCITED, FOCUSED, CONCERNED, SLEEPY, CELEBRATING.
 * Lightweight, zero memory leaks, scales cleanly to any Android screen density.
 */
public class MascotView extends View {

    public enum Expression {
        HAPPY("Siap tempur! Sistem dalam kondisi prima."),
        EXCITED("Game meluncur! Fokus penuh ke kemenangan!"),
        FOCUSED("Memantau telemetri FPS & frame-time secara real-time."),
        CONCERNED("Suhu meningkat! Sebaiknya aktifkan pendinginan."),
        SLEEPY("Mode siaga... Menunggu sesi bermain berikutnya."),
        CELEBRATING("Sesi luar biasa! Performa stabil tanpa drop!") ;

        public final String defaultLine;
        Expression(String line) { this.defaultLine = line; }
    }

    private Expression expression = Expression.HAPPY;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();

    public MascotView(Context context) {
        super(context);
    }

    public MascotView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setExpression(Expression expr) {
        if (expr != null && this.expression != expr) {
            this.expression = expr;
            invalidate();
        }
    }

    public Expression getExpression() {
        return expression;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w * 0.5f;
        float cy = h * 0.52f;
        float s = Math.min(w, h) / 200f;

        // 1. Subtle Cyber Aura Ring behind mascot
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0, 0, w, h,
                Color.parseColor("#33E0262D"), Color.parseColor("#22FF3B30"), Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, 84f * s, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f * s);
        paint.setColor(Color.parseColor("#55FF9A3C"));
        canvas.drawCircle(cx, cy, 78f * s, paint);

        // 2. Back Long Silver-Lavender Hair
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#C7B8EA"));
        path.reset();
        path.moveTo(cx - 52f * s, cy - 28f * s);
        path.quadTo(cx - 68f * s, cy + 36f * s, cx - 50f * s, cy + 82f * s);
        path.lineTo(cx + 50f * s, cy + 82f * s);
        path.quadTo(cx + 68f * s, cy + 36f * s, cx + 52f * s, cy - 28f * s);
        path.close();
        canvas.drawPath(path, paint);

        // 3. Futuristic Black & Electric Purple Techwear Collar/Shoulders
        paint.setColor(Color.parseColor("#141124"));
        path.reset();
        path.moveTo(cx - 54f * s, cy + 86f * s);
        path.quadTo(cx - 48f * s, cy + 48f * s, cx - 18f * s, cy + 44f * s);
        path.lineTo(cx + 18f * s, cy + 44f * s);
        path.quadTo(cx + 48f * s, cy + 48f * s, cx + 54f * s, cy + 86f * s);
        path.close();
        canvas.drawPath(path, paint);

        // Neon purple & cyan trim on collar
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.4f * s);
        paint.setColor(Premium.PRIMARY);
        canvas.drawLine(cx - 26f * s, cy + 50f * s, cx, cy + 72f * s, paint);
        canvas.drawLine(cx + 26f * s, cy + 50f * s, cx, cy + 72f * s, paint);
        paint.setColor(Premium.CYAN);
        canvas.drawCircle(cx, cy + 75f * s, 3.2f * s, paint);

        // 4. Neck & Anime Face Contour
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#FFE4D6"));
        canvas.drawRect(cx - 9f * s, cy + 28f * s, cx + 9f * s, cy + 48f * s, paint);

        path.reset();
        path.moveTo(cx - 38f * s, cy - 18f * s);
        path.quadTo(cx - 39f * s, cy + 16f * s, cx, cy + 34f * s);
        path.quadTo(cx + 39f * s, cy + 16f * s, cx + 38f * s, cy - 18f * s);
        path.quadTo(cx + 36f * s, cy - 52f * s, cx, cy - 52f * s);
        path.quadTo(cx - 36f * s, cy - 52f * s, cx - 38f * s, cy - 18f * s);
        path.close();
        canvas.drawPath(path, paint);

        // Soft cheek blush
        paint.setColor(Color.parseColor("#44FF3B30"));
        canvas.drawOval(new RectF(cx - 28f * s, cy + 6f * s, cx - 15f * s, cy + 13f * s), paint);
        canvas.drawOval(new RectF(cx + 15f * s, cy + 6f * s, cx + 28f * s, cy + 13f * s), paint);

        // 5. Expressive Violet Anime Eyes (changes per expression)
        drawEyes(canvas, cx, cy, s);

        // 6. Mouth (changes per expression)
        drawMouth(canvas, cx, cy, s);

        // 7. Front Anime Bangs & Sakura Hairpin
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#DCD0F7"));
        path.reset();
        path.moveTo(cx - 42f * s, cy - 16f * s);
        path.quadTo(cx - 34f * s, cy - 58f * s, cx, cy - 58f * s);
        path.quadTo(cx + 34f * s, cy - 58f * s, cx + 42f * s, cy - 16f * s);
        path.lineTo(cx + 26f * s, cy - 32f * s);
        path.lineTo(cx + 14f * s, cy - 12f * s);
        path.lineTo(cx + 2f * s, cy - 30f * s);
        path.lineTo(cx - 10f * s, cy - 10f * s);
        path.lineTo(cx - 24f * s, cy - 30f * s);
        path.close();
        canvas.drawPath(path, paint);

        // Sakura Hairpin on right temple
        paint.setColor(Premium.ACCENT);
        float px = cx + 25f * s;
        float py = cy - 34f * s;
        for (int i = 0; i < 5; i++) {
            double ang = Math.toRadians(i * 72 - 18);
            canvas.drawCircle(px + (float) Math.cos(ang) * 4.5f * s,
                    py + (float) Math.sin(ang) * 4.5f * s, 3.2f * s, paint);
        }
        paint.setColor(Premium.CYAN);
        canvas.drawCircle(px, py, 2.2f * s, paint);

        // 8. Gaming Headset with GamePulse Cyan Emblem
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5.5f * s);
        paint.setColor(Color.parseColor("#1D1836"));
        rect.set(cx - 47f * s, cy - 64f * s, cx + 47f * s, cy + 20f * s);
        canvas.drawArc(rect, 185f, 170f, false, paint);

        // Headset Ear Cups
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#191430"));
        canvas.drawRoundRect(new RectF(cx - 54f * s, cy - 22f * s, cx - 39f * s, cy + 8f * s), 6f * s, 6f * s, paint);
        canvas.drawRoundRect(new RectF(cx + 39f * s, cy - 22f * s, cx + 54f * s, cy + 8f * s), 6f * s, 6f * s, paint);

        // Glowing Cyan / Purple Headset Trim
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * s);
        paint.setColor(Premium.CYAN);
        canvas.drawRoundRect(new RectF(cx - 52f * s, cy - 19f * s, cx - 41f * s, cy + 5f * s), 5f * s, 5f * s, paint);
        canvas.drawRoundRect(new RectF(cx + 41f * s, cy - 19f * s, cx + 52f * s, cy + 5f * s), 5f * s, 5f * s, paint);

        // 9. Expression Accent Particles (Sweat drop for CONCERNED, Sparkles for EXCITED/CELEBRATING, Zzz for SLEEPY)
        drawExpressionProps(canvas, cx, cy, s);
    }

    private void drawEyes(Canvas canvas, float cx, float cy, float s) {
        float ey = cy - 2f * s;
        float lx = cx - 16f * s;
        float rx = cx + 16f * s;

        if (expression == Expression.SLEEPY) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.4f * s);
            paint.setColor(Color.parseColor("#3B2863"));
            canvas.drawLine(lx - 7f * s, ey + 2f * s, lx + 7f * s, ey + 2f * s, paint);
            canvas.drawLine(rx - 7f * s, ey + 2f * s, rx + 7f * s, ey + 2f * s, paint);
            return;
        }

        if (expression == Expression.CELEBRATING) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.6f * s);
            paint.setColor(Color.parseColor("#3B2863"));
            rect.set(lx - 7f * s, ey - 4f * s, lx + 7f * s, ey + 8f * s);
            canvas.drawArc(rect, 190f, 160f, false, paint);
            rect.set(rx - 7f * s, ey - 4f * s, rx + 7f * s, ey + 8f * s);
            canvas.drawArc(rect, 190f, 160f, false, paint);
            return;
        }

        // Open Expressive Violet Anime Iris
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawOval(new RectF(lx - 8f * s, ey - 6f * s, lx + 8f * s, ey + 7f * s), paint);
        canvas.drawOval(new RectF(rx - 8f * s, ey - 6f * s, rx + 8f * s, ey + 7f * s), paint);

        paint.setColor(Premium.PRIMARY);
        canvas.drawCircle(lx, ey + 0.5f * s, 5.4f * s, paint);
        canvas.drawCircle(rx, ey + 0.5f * s, 5.4f * s, paint);

        paint.setColor(Color.parseColor("#2A0E5E"));
        canvas.drawCircle(lx, ey + 0.5f * s, 2.6f * s, paint);
        canvas.drawCircle(rx, ey + 0.5f * s, 2.6f * s, paint);

        // Anime eye specular catchlights
        paint.setColor(Color.WHITE);
        canvas.drawCircle(lx - 2f * s, ey - 2f * s, 1.8f * s, paint);
        canvas.drawCircle(rx - 2f * s, ey - 2f * s, 1.8f * s, paint);
        if (expression == Expression.EXCITED) {
            paint.setColor(Premium.CYAN);
            canvas.drawCircle(lx + 2f * s, ey + 2.2f * s, 1.3f * s, paint);
            canvas.drawCircle(rx + 2f * s, ey + 2.2f * s, 1.3f * s, paint);
        }

        // Eyebrows
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * s);
        paint.setColor(Color.parseColor("#6D599E"));
        if (expression == Expression.CONCERNED) {
            canvas.drawLine(lx - 7f * s, ey - 8f * s, lx + 6f * s, ey - 11f * s, paint);
            canvas.drawLine(rx - 6f * s, ey - 11f * s, rx + 7f * s, ey - 8f * s, paint);
        } else if (expression == Expression.FOCUSED) {
            canvas.drawLine(lx - 7f * s, ey - 10f * s, lx + 7f * s, ey - 8f * s, paint);
            canvas.drawLine(rx - 7f * s, ey - 8f * s, rx + 7f * s, ey - 10f * s, paint);
        } else {
            canvas.drawLine(lx - 6f * s, ey - 10f * s, lx + 6f * s, ey - 10f * s, paint);
            canvas.drawLine(rx - 6f * s, ey - 10f * s, rx + 6f * s, ey - 10f * s, paint);
        }
    }

    private void drawMouth(Canvas canvas, float cx, float cy, float s) {
        float my = cy + 17f * s;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * s);
        paint.setColor(Color.parseColor("#B84A62"));

        switch (expression) {
            case EXCITED:
            case CELEBRATING:
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.parseColor("#FF6B8B"));
                rect.set(cx - 6f * s, my - 2f * s, cx + 6f * s, my + 7f * s);
                canvas.drawArc(rect, 0f, 180f, true, paint);
                break;
            case CONCERNED:
                rect.set(cx - 5f * s, my + 1f * s, cx + 5f * s, my + 6f * s);
                canvas.drawArc(rect, 190f, 160f, false, paint);
                break;
            case FOCUSED:
                canvas.drawLine(cx - 4f * s, my + 2f * s, cx + 4f * s, my + 2f * s, paint);
                break;
            case SLEEPY:
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.parseColor("#D96B84"));
                canvas.drawCircle(cx, my + 2f * s, 2.5f * s, paint);
                break;
            case HAPPY:
            default:
                rect.set(cx - 6f * s, my - 2f * s, cx + 6f * s, my + 5f * s);
                canvas.drawArc(rect, 15f, 150f, false, paint);
                break;
        }
    }

    private void drawExpressionProps(Canvas canvas, float cx, float cy, float s) {
        paint.setStyle(Paint.Style.FILL);
        if (expression == Expression.CONCERNED) {
            // Cyan sweat drop
            paint.setColor(Premium.CYAN);
            path.reset();
            float sx = cx + 32f * s;
            float sy = cy - 18f * s;
            path.moveTo(sx, sy - 6f * s);
            path.quadTo(sx + 5f * s, sy + 2f * s, sx, sy + 5f * s);
            path.quadTo(sx - 5f * s, sy + 2f * s, sx, sy - 6f * s);
            path.close();
            canvas.drawPath(path, paint);
        } else if (expression == Expression.EXCITED || expression == Expression.CELEBRATING) {
            // Neon stars
            paint.setColor(Premium.CYAN);
            canvas.drawCircle(cx - 46f * s, cy - 36f * s, 2.6f * s, paint);
            paint.setColor(Premium.ACCENT);
            canvas.drawCircle(cx + 48f * s, cy - 30f * s, 3f * s, paint);
        }
    }
}
