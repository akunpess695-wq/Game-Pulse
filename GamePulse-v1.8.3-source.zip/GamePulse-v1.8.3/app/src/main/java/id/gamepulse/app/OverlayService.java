package id.gamepulse.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class OverlayService extends Service {
    private static final String CH_HUD = "gp_hud";
    private static final int ID_HUD = 7003;
    private static final long TICK_MS = 1000L;
    static volatile boolean isRunning = false;

    private WindowManager wm;
    private LinearLayout pill;
    private WindowManager.LayoutParams lp;
    private TextView tvFps, tvTemp, btnBoost, btnHz, btnClose;
    private LinearLayout actionsBox;
    private View dot;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SessionStore store;
    private boolean expanded = false;
    private final AtomicBoolean standaloneFpsBusy = new AtomicBoolean(false);

    static boolean canDraw(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static void start(Context c) {
        if (!canDraw(c)) return;
        try {
            c.startForegroundService(new Intent(c, OverlayService.class));
        } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, OverlayService.class));
        } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        store = new SessionStore(this);
        if (!canDraw(this)) {
            stopSelf();
            return;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CH_HUD, "Kapsul HUD FPS", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_HUD, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(ID_HUD, n);
        }
        setupPill();
        isRunning = true;
        h.post(tick);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        clampPositionToScreen();
    }

    @Override public void onDestroy() {
        isRunning = false;
        h.removeCallbacks(tick);
        if (wm != null && pill != null) {
            try { wm.removeView(pill); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    private void clampPositionToScreen() {
        if (wm == null || pill == null || lp == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxX = Math.max(0, dm.widthPixels - Math.max(pill.getWidth(), dp(120)));
        int maxY = Math.max(0, dm.heightPixels - Math.max(pill.getHeight(), dp(40)));
        lp.x = Math.max(0, Math.min(lp.x, maxX));
        lp.y = Math.max(0, Math.min(lp.y, maxY));
        try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) { }
    }

    private Notification buildNotification() {
        Intent in = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, in, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH_HUD)
                .setSmallIcon(R.drawable.ic_nav_tools)
                .setContentTitle("GamePulse HUD aktif")
                .setContentText("Ketuk kapsul FPS di layar untuk aksi cepat")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .build();
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPill() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) { stopSelf(); return; }

        pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(10), dp(4), dp(10), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xD90B0D12);
        bg.setCornerRadius(dp(14));
        bg.setStroke(Math.max(1, dp(1)), 0x55E5383B);
        pill.setBackground(bg);

        dot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(Premium.OK);
        dot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(6), dp(6));
        dotLp.rightMargin = dp(6);
        pill.addView(dot, dotLp);

        tvFps = new TextView(this);
        tvFps.setText("60 FPS");
        tvFps.setTextColor(Premium.OK);
        tvFps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvFps.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        pill.addView(tvFps);

        TextView sep = new TextView(this);
        sep.setText(" • ");
        sep.setTextColor(0x66FFFFFF);
        sep.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        pill.addView(sep);

        tvTemp = new TextView(this);
        tvTemp.setText("36.0°C");
        tvTemp.setTextColor(Premium.TEXT);
        tvTemp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tvTemp.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        pill.addView(tvTemp);

        actionsBox = new LinearLayout(this);
        actionsBox.setOrientation(LinearLayout.HORIZONTAL);
        actionsBox.setGravity(Gravity.CENTER_VERTICAL);
        actionsBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(-2, -2);
        actLp.leftMargin = dp(8);

        btnBoost = chip("BOOST", Premium.OK, 0x222BD47D);
        btnBoost.setOnClickListener(v -> runQuickBoost());
        actionsBox.addView(btnBoost);

        boolean isLocked = store.prefs().contains("hz_prev");
        btnHz = chip(isLocked ? "AUTO" : "60Hz", Premium.WARN, 0x22FFB020);
        LinearLayout.LayoutParams hzLp = new LinearLayout.LayoutParams(-2, -2);
        hzLp.leftMargin = dp(5);
        btnHz.setOnClickListener(v -> toggleQuickHz());
        actionsBox.addView(btnHz, hzLp);

        btnClose = new TextView(this);
        btnClose.setText("✕");
        btnClose.setTextColor(Premium.HOT);
        btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        btnClose.setTypeface(Typeface.DEFAULT_BOLD);
        btnClose.setPadding(dp(6), dp(2), dp(2), dp(2));
        LinearLayout.LayoutParams clsLp = new LinearLayout.LayoutParams(-2, -2);
        clsLp.leftMargin = dp(4);
        btnClose.setOnClickListener(v -> {
            store.prefs().edit().putBoolean("hud_on", false).apply();
            stopSelf();
        });
        actionsBox.addView(btnClose, clsLp);

        pill.addView(actionsBox, actLp);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(16);
        lp.y = dp(36);

        pill.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY;
            float touchX, touchY;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = lp.x;
                        initY = lp.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = initX + Math.round(event.getRawX() - touchX);
                        lp.y = initY + Math.round(event.getRawY() - touchY);
                        try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (Math.abs(event.getRawX() - touchX) < 12 && Math.abs(event.getRawY() - touchY) < 12) {
                            expanded = !expanded;
                            actionsBox.setVisibility(expanded ? View.VISIBLE : View.GONE);
                            pill.post(() -> clampPositionToScreen());
                        } else {
                            clampPositionToScreen();
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(pill, lp);
    }

    private TextView chip(String label, int textColor, int bgColor) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(textColor);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        t.setPadding(dp(6), dp(2), dp(6), dp(2));
        GradientDrawable d = new GradientDrawable();
        d.setColor(bgColor);
        d.setCornerRadius(dp(6));
        t.setBackground(d);
        return t;
    }

    private void runQuickBoost() {
        btnBoost.setText("...");
        final String keepPkg = store.prefs().getString("active_pkg", null);
        new Thread(() -> {
            Optimizer.cleanRam(getApplicationContext(), keepPkg);
            if (ShizukuHelper.granted()) {
                ShizukuHelper.forceStop(Optimizer.userPackages(getApplicationContext(), keepPkg));
            }
            h.post(() -> {
                btnBoost.setText("OK ✓");
                h.postDelayed(() -> btnBoost.setText("BOOST"), 1500);
            });
        }, "gp-hud-boost").start();
    }

    private void toggleQuickHz() {
        if (!ShizukuHelper.granted()) {
            Toast.makeText(this, "Shizuku belum aktif", Toast.LENGTH_SHORT).show();
            return;
        }
        final SharedPreferences sp = store.prefs();
        final boolean currentlyLocked = sp.contains("hz_prev");
        new Thread(() -> {
            if (!currentlyLocked) {
                ShizukuHelper.lockRefreshRate(sp, 60);
                h.post(() -> btnHz.setText("AUTO"));
            } else {
                ShizukuHelper.restoreRefreshRate(sp);
                h.post(() -> btnHz.setText("60Hz"));
            }
        }, "gp-hud-hz").start();
    }

    @SuppressWarnings("deprecation")
    private int currentDisplayHz() {
        try {
            if (wm != null && wm.getDefaultDisplay() != null) {
                return Math.round(wm.getDefaultDisplay().getRefreshRate());
            }
        } catch (Throwable ignored) { }
        return 60;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            SharedPreferences sp = store.prefs();
            boolean sessionHandled = store.active() && sp.getBoolean("svc_on", true);
            if (!sessionHandled && sp.getBoolean("sz_fps", true) && ShizukuHelper.granted()
                    && standaloneFpsBusy.compareAndSet(false, true)) {
                final String pkg = sp.getString("active_pkg", null);
                if (pkg != null) {
                    new Thread(() -> {
                        try { FpsMeter.sample(sp, pkg); } finally { standaloneFpsBusy.set(false); }
                    }, "gp-hud-fps").start();
                } else {
                    standaloneFpsBusy.set(false);
                }
            }

            float liveFps = FpsMeter.live;
            if (liveFps > 0f) {
                int fpsInt = Math.round(liveFps);
                tvFps.setText(fpsInt + " FPS");
                int c = Premium.fpsColor(liveFps, 60f);
                tvFps.setTextColor(c);
                setDotColor(c);
            } else {
                int curHz = currentDisplayHz();
                tvFps.setText(curHz + " Hz");
                tvFps.setTextColor(Premium.TEXT_2);
                setDotColor(Premium.WARN);
            }

            float temp = DeviceInfo.tempC(OverlayService.this);
            if (!Float.isNaN(temp) && temp > 0f) {
                tvTemp.setText(String.format(Locale.US, "%.1f°C", temp));
                tvTemp.setTextColor(Premium.tempColor(temp, Thresholds.warm(OverlayService.this), Thresholds.hot(OverlayService.this)));
            } else {
                tvTemp.setText("N/A");
            }

            if (btnHz != null) {
                btnHz.setText(sp.contains("hz_prev") ? "AUTO" : "60Hz");
            }

            h.postDelayed(this, TICK_MS);
        }
    };

    private void setDotColor(int color) {
        if (dot != null && dot.getBackground() instanceof GradientDrawable) {
            ((GradientDrawable) dot.getBackground()).setColor(color);
        }
    }
}
