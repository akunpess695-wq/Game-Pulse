# Keep GamePulse telemetry and UI classes
-keep class com.gamepulse.app.** { *; }
