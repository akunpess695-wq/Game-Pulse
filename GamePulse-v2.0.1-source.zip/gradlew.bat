@rem Minimal Windows wrapper bootstrapper
gradle %*
