# GamePulse v0.1 — Redmi Note 12 Pro 5G

Native Java Android MVP. Two manual gaming profiles: eFootball and Monster Hunter Outlanders.

## Implemented
- Battery level and battery temperature via ACTION_BATTERY_CHANGED
- Device thermal status via PowerManager API 29+
- Device/Android information
- Manual game profile selection and app launch attempt
- Session start/stop with locally stored duration, battery and temperature
- Links to supported Android settings
- Offline; no internet, root or dangerous permissions

## Build
Open in Android Studio with Android SDK 35 and Gradle 8.9, or run `gradle :app:assembleDebug` in a configured Android environment. GitHub Actions workflow is provided, but no GitHub account is connected and no CI run has been executed.

## Important limitations
- Game package ID for Monster Hunter Outlanders is unverified, so the app does not guess it; launcher shows a message. Users can still open the game from their launcher and manually track a session.
- No automated performance tweaks, FPS overlay, thermal bypass, RAM booster or benchmark claims.
- Session recording is manual; Android may kill the app during play, but SharedPreferences preserves active-session start time.
- App compilation/device testing has NOT been performed in this environment.
- All game graphic settings are recommendations, not automatically applied.
