package id.gamepulse.app;

import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG=0xFF09090F, CARD=0xFF171621, FG=0xFFF4F1FF, MUTED=0xFFA9A4BC, ACCENT=0xFFA78BFA;
    private static final String PREF="gamepulse_local";
    private LinearLayout content;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private String selected="eFootball";
    private final Runnable refresh=new Runnable(){ public void run(){ if(content!=null && !isFinishing()) { render(); handler.postDelayed(this,15000); } }};

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);selected=getPreferences(0).getString("selected","eFootball");render();handler.postDelayed(refresh,15000);}
    @Override protected void onDestroy(){handler.removeCallbacks(refresh);super.onDestroy();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setLineSpacing(dp(2),1);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void add(LinearLayout parent,View view,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(view,p);}
    private LinearLayout card(String title){LinearLayout l=vertical();l.setPadding(dp(18),dp(16),dp(18),dp(16));l.setBackground(shape(CARD,18));add(l,text(title,16,FG,true),0);add(content,l,14);return l;}
    private void line(LinearLayout l,String label,String value){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView a=text(label,13,MUTED,false),b=text(value,13,FG,true);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(b);add(l,r,12);}
    private void button(LinearLayout l,String label,Runnable action,boolean filled){TextView b=text(label,14,filled?BG:FG,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(13),dp(14),dp(13));b.setBackground(shape(filled?ACCENT:0xFF302A42,13));add(l,b,12);b.setOnClickListener(v->action.run());}
    private Intent battery(){return registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));}
    private int batteryLevel(Intent i){if(i==null)return -1;int a=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),s=i.getIntExtra(BatteryManager.EXTRA_SCALE,-1);return a<0||s<=0?-1:Math.round(a*100f/s);}
    private String temp(Intent i){if(i==null)return "Tidak tersedia";int t=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Integer.MIN_VALUE);return t==Integer.MIN_VALUE?"Tidak tersedia":String.format(Locale.US,"%.1f °C",t/10f);}
    private String thermal(){if(Build.VERSION.SDK_INT<29)return "Tidak tersedia";PowerManager p=(PowerManager)getSystemService(POWER_SERVICE);if(p==null)return "Tidak tersedia";int n=p.getCurrentThermalStatus();String[] names={"Normal","Ringan","Sedang","Berat","Kritis","Darurat","Shutdown"};return n>=0&&n<names.length?names[n]:"Status "+n;}
    private String active(){return getPreferences(0).getString("active","");}
    private void startSession(){if(!active().isEmpty()){Toast.makeText(this,"Selesaikan sesi sebelumnya",Toast.LENGTH_SHORT).show();return;}Intent b=battery();getPreferences(0).edit().putString("active",selected).putLong("started",System.currentTimeMillis()).putInt("start_battery",batteryLevel(b)).putString("start_temp",temp(b)).apply();render();}
    private void endSession(){if(active().isEmpty())return;android.content.SharedPreferences p=getPreferences(0);long duration=Math.max(0,(System.currentTimeMillis()-p.getLong("started",System.currentTimeMillis()))/60000);int end=batteryLevel(battery());String report=new SimpleDateFormat("dd MMM yyyy HH:mm",new Locale("id","ID")).format(new Date())+"\n"+active()+" • "+duration+" menit\nBaterai: "+p.getInt("start_battery",-1)+"% → "+end+"%\nSuhu baterai: "+p.getString("start_temp","-")+" → "+temp(battery())+"\nThermal akhir: "+thermal();p.edit().putString("history",report+"\n\n"+p.getString("history","")).remove("active").remove("started").apply();render();}
    private void launch(){String pkg=selected.equals("eFootball")?"jp.konami.pesam":null;Intent i=pkg==null?null:getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){startActivity(i);}else{Toast.makeText(this,"Game tidak ditemukan otomatis. Buka game dari launcher HP.",Toast.LENGTH_LONG).show();}}
    private void openSettings(String action){try{startActivity(new Intent(action));}catch(Exception e){Toast.makeText(this,"Pengaturan tidak tersedia",Toast.LENGTH_SHORT).show();}}
    private void render(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);content=vertical();content.setPadding(dp(20),dp(22),dp(20),dp(35));sc.addView(content);setContentView(sc);
        add(content,text("GAMEPULSE  /  V0.1",12,ACCENT,true),0);
        add(content,text("Gaming, tanpa gimmick.",26,FG,true),8);
        add(content,text("Profil khusus Redmi Note 12 Pro 5G • RAM 8 GB\nMonitor nyata • Tidak perlu root",13,MUTED,false),7);
        LinearLayout status=card("STATUS PERANGKAT");Intent b=battery();int level=batteryLevel(b);line(status,"Baterai",level<0?"Tidak tersedia":level+"%");line(status,"Suhu baterai",temp(b));line(status,"Status thermal",thermal());line(status,"Android",String.valueOf(Build.VERSION.RELEASE));line(status,"Perangkat",Build.MANUFACTURER+" "+Build.MODEL);
        LinearLayout game=card("PILIH PROFIL GAME");
        button(game,(selected.equals("eFootball")?"● ":"○ ")+"eFootball — Competitive Stability",()->select("eFootball"),selected.equals("eFootball"));
        button(game,(selected.equals("Monster Hunter Outlanders")?"● ":"○ ")+"Monster Hunter Outlanders — Thermal Stability",()->select("Monster Hunter Outlanders"),selected.equals("Monster Hunter Outlanders"));
        if(selected.equals("eFootball")){
            add(game,text("BASELINE • Grafis Standard • 60 FPS jika tersedia • prioritaskan jaringan stabil. Pengaturan harus dilakukan di dalam game.",13,MUTED,false),14);
        }else{
            add(game,text("BASELINE • Grafis Low • 30 FPS jika tersedia • efek/bayangan rendah. Naikkan kualitas hanya jika suhu dan gameplay stabil.",13,MUTED,false),14);
        }
        button(game,"Buka "+selected,()->launch(),false);
        LinearLayout session=card("CATAT SESI BERMAIN");String a=active();if(a.isEmpty()){
            add(session,text("Mulai pencatatan sebelum membuka game. Akhiri setelah kembali ke GamePulse.",13,MUTED,false),10);
            button(session,"Mulai sesi "+selected,()->startSession(),true);
        }else{
            long minutes=Math.max(0,(System.currentTimeMillis()-getPreferences(0).getLong("started",System.currentTimeMillis()))/60000);
            add(session,text("Aktif: "+a+" • "+minutes+" menit",14,ACCENT,true),10);
            button(session,"Akhiri & simpan sesi",()->endSession(),true);
        }
        LinearLayout settings=card("PENGATURAN YANG AMAN");
        add(settings,text("GamePulse tidak dapat memaksa CPU/GPU, menghapus RAM aplikasi lain, atau menonaktifkan thermal throttling tanpa akses khusus.",13,MUTED,false),10);
        button(settings,"Buka pengaturan layar",()->openSettings(Settings.ACTION_DISPLAY_SETTINGS),false);
        button(settings,"Buka pengaturan baterai",()->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS),false);
        button(settings,"Buka pengaturan notifikasi",()->openSettings(Settings.ACTION_APP_NOTIFICATION_SETTINGS),false);
        LinearLayout hist=card("RIWAYAT SESI");String h=getPreferences(0).getString("history","");add(hist,text(h.isEmpty()?"Belum ada sesi tersimpan.":h,13,h.isEmpty()?MUTED:FG,false),10);
        add(content,text("Data sesi tersimpan lokal. Tidak ada akses root, internet, atau telemetry. FPS game lain tidak dapat diukur langsung oleh aplikasi ini.",12,MUTED,false),20);
    }
    private void select(String s){selected=s;getPreferences(0).edit().putString("selected",s).apply();render();}
}
