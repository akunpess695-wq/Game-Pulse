package id.gamepulse.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public final class AnimeTheme {

    public static final int PRIMARY = Color.parseColor("#8B3DFF");
    public static final int PRIMARY_SOFT = Color.parseColor("#26164A");
    public static final int SECONDARY = Color.parseColor("#FF45C8");
    public static final int SECONDARY_SOFT = Color.parseColor("#381436");
    public static final int ACCENT = Color.parseColor("#35DFFF");
    public static final int BG = Color.parseColor("#090817");
    public static final int SURFACE = Color.parseColor("#17132A");
    public static final int SURFACE_ELEVATED = Color.parseColor("#211B3B");
    public static final int STROKE = Color.parseColor("#322957");
    public static final int STROKE_NEON = Color.parseColor("#778B3DFF");
    public static final int TEXT_PRIMARY = Color.parseColor("#F5F1FF");
    public static final int TEXT_SECONDARY = Color.parseColor("#B8AED8");
    public static final int TEXT_MUTED = Color.parseColor("#7B70A3");
    public static final int STATUS_GOOD = Color.parseColor("#4ADE80");
    public static final int STATUS_WARN = Color.parseColor("#FBBF24");
    public static final int STATUS_HOT = Color.parseColor("#FF45C8");

    private AnimeTheme() {}

    public static int dp(Context ctx, float dp) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, ctx.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable cardDrawable(Context ctx, int fillColor, int strokeColor, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fillColor);
        d.setCornerRadius(dp(ctx, radiusDp));
        if (strokeColor != 0) {
            d.setStroke(dp(ctx, 1), strokeColor);
        }
        return d;
    }

    public static GradientDrawable gradientCard(Context ctx, int startColor, int endColor, int strokeColor, float radiusDp) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{startColor, endColor});
        d.setCornerRadius(dp(ctx, radiusDp));
        if (strokeColor != 0) {
            d.setStroke(dp(ctx, 1), strokeColor);
        }
        return d;
    }

    public static GradientDrawable primaryButtonDrawable(Context ctx, float radiusDp) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{PRIMARY, SECONDARY});
        d.setCornerRadius(dp(ctx, radiusDp));
        return d;
    }

    public static void attachPressFeedback(final View target) {
        target.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90)
                            .setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140)
                            .setInterpolator(new DecelerateInterpolator()).start();
                    break;
            }
            return false;
        });
    }

    public static void playEntranceFade(View view, long delayMs) {
        view.setAlpha(0f);
        view.setTranslationY(14f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(delayMs)
                .setDuration(220)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }
}
