package id.gamepulse.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ThermalService extends Service {
    private static final String CH_RUN = "gp_session", CH_ALERT = "gp_alert";
    private static final int ID_RUN = 7001, ID_ALERT = 7002;
    private static final long TICK_MS = 15000L, ALERT_GAP_MS = 180000L;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SessionStore store;
    private long lastAlert;
    private volatile int resLevel = 100;
    private int coolTicks;
    private final AtomicBoolean resBusy = new AtomicBoolean(false);
    private static final int COOL_TICKS_NEEDED = 6;   // 6 x 15 dtk = 90 dtk dingin sebelum resolusi dinaikkan
    private final AtomicBoolean fpsBusy = new AtomicBoolean(false);
    private final Runnable fpsTick = new Runnable() {
        @Override public void run() {
            if (!store.active()) return;
            if (store.prefs().getBoolean("sz_fps", true) && ShizukuHelper.granted() && fpsBusy.compareAndSet(false, true)) {
                final String pkg = store.prefs().getString("active_pkg", null);
                new Thread(() -> {
                    try { FpsMeter.sample(store.prefs(), pkg); } finally { fpsBusy.set(false); }
                }).start();
            }
            h.postDelayed(this, FpsMeter.nextMs);
        }
    };

    static void start(Context c) {
        try {
            c.startForegroundService(new Intent(c, ThermalService.class));
        } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, ThermalService.class)); } catch (Exception ignored) { }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        store = new SessionStore(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CH_RUN, "Pemantau sesi", NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Peringatan panas", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        Notification n = runNotification("Memantau suhu…");
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(ID_RUN, n);
        h.removeCallbacks(tick);
        h.post(tick);
        h.removeCallbacks(fpsTick);
        h.post(fpsTick);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        resLevel = 100;
        h.removeCallbacks(tick);
        h.removeCallbacks(fpsTick);
        super.onDestroy();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!store.active()) {
                if (ShizukuHelper.pendingRestore(store.prefs()) && ShizukuHelper.granted()) {
                    final android.content.SharedPreferences sp = store.prefs();
                    new Thread(() -> ShizukuHelper.restoreAll(sp), "gp-restore").start();
                }
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
                return;
            }
            float t = DeviceInfo.tempC(ThermalService.this);
            store.beat();
            store.trackPeak(t);
            float hr = headroom();
            int heat = heatNow(hr);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(ID_RUN, runNotification(summary(t, hr)));
            if (heat == 2) onHot(t, nm);
            autoRes(heat);
            h.postDelayed(this, TICK_MS);
        }
    };

    private int heatNow(float hr) {
        int lvl = DeviceInfo.heatLevel(this);
        if (!Float.isNaN(hr) && hr >= Thresholds.HEADROOM_HOT) return 2;
        if (!Float.isNaN(hr) && hr >= Thresholds.HEADROOM_WARM) return Math.max(lvl, 1);
        return lvl;
    }

    private float headroom() {
        if (Build.VERSION.SDK_INT < 30) return Float.NaN;
        try {
            PowerManager pm = getSystemService(PowerManager.class);
            return pm == null ? Float.NaN : pm.getThermalHeadroom(10);
        } catch (Throwable e) {
            return Float.NaN;
        }
    }

    private String summary(float t, float hr) {
        StringBuilder sb = new StringBuilder();
        sb.append(store.activeGame()).append(" · ").append(store.activeMinutes()).append(" mnt · ")
                .append(DeviceInfo.tempText(t)).append(" · Thermal ").append(DeviceInfo.thermalText(this));
        if (!Float.isNaN(hr)) sb.append(String.format(Locale.US, " · indeks %.0f%%", hr * 100f));
        if (resLevel < 100) sb.append(" · Hemat ").append(resLevel).append("%");
        if (store.prefs().getBoolean("sz_fps", true) && ShizukuHelper.granted()) {
            if (FpsMeter.live >= 0) sb.append(String.format(Locale.US, "\nFPS %.0f", FpsMeter.live));
            float low = store.prefs().getFloat("fps_low", -1f);
            if (FpsMeter.live >= 0 && low >= 0) sb.append(String.format(Locale.US, " · 1%% low %.0f", low));
            if (FpsMeter.live < 0 && !FpsMeter.status.isEmpty()) sb.append("\n").append(FpsMeter.status);
        }
        return sb.toString();
    }

    private void onHot(float t, NotificationManager nm) {
        long now = System.currentTimeMillis();
        if (nm != null && now - lastAlert >= ALERT_GAP_MS) {
            lastAlert = now;
            Notification a = new Notification.Builder(this, CH_ALERT)
                    .setSmallIcon(R.drawable.ic_nav_tools)
                    .setContentTitle("HP mulai panas")
                    .setContentText(DeviceInfo.tempText(t) + " · Thermal " + DeviceInfo.thermalText(this)
                            + ". Turunkan grafis, lepas casing, jeda sebentar.")
                    .setStyle(new Notification.BigTextStyle().bigText(DeviceInfo.tempText(t) + " · Thermal "
                            + DeviceInfo.thermalText(this) + ". Turunkan grafis/FPS di game, lepas casing, "
                            + "hentikan pengisian daya, atau jeda beberapa menit."))
                    .setContentIntent(openApp())
                    .setAutoCancel(true)
                    .build();
            nm.notify(ID_ALERT, a);
        }
    }

    /** Resolusi bertahap: hangat -> 90%, panas -> 75%; naik satu tingkat hanya setelah dingin cukup lama. */
    private void autoRes(int heat) {
        android.content.SharedPreferences sp = store.prefs();
        if (!sp.getBoolean("sz_autores", false) || sp.getBoolean("sz_res", false) || !ShizukuHelper.granted()) return;
        final int want = heat >= 2 ? 75 : heat == 1 ? 90 : 100;
        if (want < resLevel) {
            coolTicks = 0;
            applyRes(want);
        } else if (want > resLevel) {
            if (++coolTicks >= COOL_TICKS_NEEDED) {
                coolTicks = 0;
                applyRes(resLevel == 75 ? Math.min(want, 90) : 100);
            }
        } else {
            coolTicks = 0;
        }
    }

    private void applyRes(final int level) {
        if (!resBusy.compareAndSet(false, true)) return;
        new Thread(() -> {
            try {
                if (level >= 100) { if (ShizukuHelper.resetResolution(store.prefs())) resLevel = 100; }
                else { ShizukuHelper.lowerResolution(store.prefs(), level); resLevel = level; }
            } finally { resBusy.set(false); }
        }, "gp-autores").start();
    }

    private PendingIntent openApp() {
        Intent in = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, in, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification runNotification(String text) {
        return new Notification.Builder(this, CH_RUN)
                .setSmallIcon(R.drawable.ic_nav_tools)
                .setContentTitle("GamePulse memantau sesi")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp())
                .build();
    }
}
