# HANDOFF — GamePulse optimasi game (update 12 Nov 2026)
Tujuan: aplikasi benar-benar membantu optimalisasi game, bertahap. Hemat token: kirim zip + berkas ini saja.

## Update v1.2.0 (12 Nov 2026)
Pengguna mengonfirmasi v1.1 terpasang dan Shizuku aktif & diizinkan (layar Tools menampilkan opsi AKTIF). Ditambahkan: kunci refresh rate + anti-Doze (ShizukuHelper.lockRefreshRate/boostApp/restoreAll; MainActivity.optimizeNow/shizukuCard/restoreScreen). BELUM dikompilasi (tak ada javac/Android SDK di sandbox) dan BELUM diuji di HP; tinjau lewat build GitHub Actions. Berikutnya: Tahap 2 (layanan latar pantau thermal + turunkan resolusi otomatis saat panas).

## Update v1.3.0 (12 Nov 2026) — Tahap 2
Ditambahkan ThermalService.java (foreground service specialUse; loop 15 dtk: trackPeak, notifikasi status, peringatan panas, indeks thermal getThermalHeadroom API 30+, auto-turun resolusi opsional via pref sz_autores). Disambung di MainActivity: start()/end()/batal sesi/onResume, toggle svc_on, tombol izin POST_NOTIFICATIONS. Manifest +3 izin + <service>. BELUM dikompilasi/diuji (cek sintaks parser lolos; simbol Android tak bisa diverifikasi di sandbox). Risiko: (1) properti specialUse perlu AGP 8.x (dipakai 8.7.3); (2) Play Store meninjau FGS specialUse; (3) auto-turun resolusi di tengah game bisa memuat ulang game — default mati; (4) ambang indeks thermal 0.8/0.95 adalah tebakan, kalibrasi di Redmi Note 12 Pro 5G. Berikutnya: Tahap 3 (skor Kesiapan + bandingkan sesi sebelum/sesudah).

## Update v1.4.0 (12 Nov 2026) — Tahap 3a FPS
FpsMeter.java (dumpsys SurfaceFlinger --list/--latency via ShizukuHelper.exec; histogram frame time; avg/1% low/jitter -> prefs fps_*; SessionStore.finish menyimpan fpsAvg/fpsLow/fpsJit). ThermalService menjalankan fpsTick 5 dtk (thread latar). MainActivity.start(): FpsMeter.reset + pref active_pkg. Risiko: (1) nama layer/--latency belum terverifikasi di HyperOS/Android 14-15, (2) exec lewat refleksi newProcess belum terbukti jalan, (3) sampel ±2-4 dtk per 5 dtk. Cek notifikasi status FPS saat uji; bandingkan dengan Scene 5 (pengguna: Scene tunjuk ~30 FPS tapi terasa ringan, jadi tampilkan 1% low & jitter). Berikutnya: Tahap 3b skor Kesiapan + bandingkan sesi.

## Update v1.5.0 (13 Nov 2026) — Tablet Mi Pad 6S Pro (144 Hz)
DisplayProfile.java (baru): rates()/target()/cycle()/summary(); optimizeNow memakai DisplayProfile.target (sebelumnya max getSupportedRefreshRates). ShizukuHelper.lockRefreshRate +secure miui_refresh_rate (hanya bila ada; pref hz_prev kini "peak|min|miui", "-" = tak disentuh). FpsMeter: histogram 0,1 ms + deteksi celah buffer. MainActivity: lebar maks 680dp, onConfigurationChanged->render, baris "Layar:" + tombol Target refresh. BELUM dikompilasi/diuji (hanya cek sintaks parser). Risiko: (1) kunci miui_refresh_rate di HyperOS dari ingatan; (2) peak/min_refresh_rate mungkin diabaikan HyperOS di tablet — cek "aktif N Hz" di Tools setelah Mulai & Buka Game; (3) 144 Hz lebih panas/boros, uji suhu; (4) ThermalService ambang suhu belum dikalibrasi untuk tablet.

## Update v1.6.0 (13 Nov 2026) — Carbon Redline
Premium.java (dari rekomendasi AI Coarena, diperiksa) + MainActivity: konstanta warna -> Premium.*, card()/button()/stat() memakai Premium, hero() +scrim. Belum diterapkan: angka FPS besar di layar Sesi/Home, batas 3 ukuran teks, kartu lain yang masih memakai warna lama hardcoded (kartu game, alert, nav aktif). BELUM dikompilasi/diuji (cek sintaks saja). Risiko: autosize teks di stat() pada layar sempit; kontras di bawah matahari.

## Status jujur
- Tahap 1 SELESAI DITULIS (v1.1.0), BELUM DIKOMPILASI, BELUM DIUJI. Build via GitHub Actions (build.yml tak berubah; zip harus bernama GamePulse-v*-source.zip di root).
- Batas Android tanpa root: tidak bisa naikkan CPU/GPU/FPS atau matikan thermal. Yang nyata: bebaskan RAM latar, kurangi gangguan, jaga suhu/baterai, panduan pengaturan.

## Tahap 1 (selesai): Optimizer.java + Tools "Optimasi Pra-Main"
RAM clean, DND saat sesi, cek Hemat Daya, tombol Game Turbo Xiaomi (komponen com.miui.securitycenter/...GameBoosterRealMainActivity BELUM TERVERIFIKASI).

## Tahap 4a (selesai ditulis): Shizuku — pengguna sudah memakai Shizuku
ShizukuHelper.java: force-stop, wm size 75%/reset, cmd game (eksperimental). Risiko diketahui: (1) Shizuku.newProcess lewat refleksi — bila gagal pindah ke UserService (AIDL); (2) versi dependensi 13.1.5 dari ingatan, belum diverifikasi; (3) README/PRIVACY masih menyebut "tanpa library pihak ketiga" — perbarui. Hentikan paksa bisa menghentikan alarm/sinkron app lain: sudah opt-in.

## Rencana berikutnya
- Tahap 2: layanan latar (foreground service) pantau suhu/thermal saat sesi + notifikasi peringatan; PowerManager.getThermalHeadroom (API 30+); catat suhu puncak sungguhan. Izin: FOREGROUND_SERVICE(+tipe), POST_NOTIFICATIONS.
- Tahap 3: skor Kesiapan + rekomendasi otomatis (profil per game), bandingkan sesi sebelum/sesudah optimasi.
- Tahap 4: GameManager (Android 12+) baca mode game; panduan Game Turbo/HyperOS per game; opsional Shizuku (butuh izin pengguna, risiko lebih tinggi — putuskan bersama).
- Tahap 5: pengujian di Redmi Note 12 Pro 5G, rapikan, rilis.

## File berubah (v1.1.0)
Optimizer.java (baru), MainActivity.java (tools(), optimizeNow(), startAndLaunch(), end(), readiness()), AndroidManifest.xml (2 izin), app/build.gradle (versi 11/1.1.0), CHANGELOG/README/TEST_CHECKLIST.
Catatan: izin baru perlu dicantumkan di PRIVACY.md/Data safety bila ke Play Store (KILL_BACKGROUND_PROCESSES bisa kena tinjauan).

## Skill terpakai (katalog Salamuda)
Verifikasi jujur, perubahan minimal, gerbang keamanan (tanpa jaringan/izin berlebih), serah terima.
Berikutnya dari katalog: performance-optimization (Tahap 2-3), webapp/QA debug (Tahap 5).

## Riwayat build
- Build 1 gagal: ShizukuHelper.even(int) belum didefinisikan (sudah diperbaiki). Dependensi Shizuku 13.1.5 TERUNDUH dengan baik. Kode belum pernah dikompilasi lokal, jadi bisa ada galat lain yang baru muncul setelah ini.
