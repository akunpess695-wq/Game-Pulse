package com.gamepulse.app;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.Choreographer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvFpsValue;
    private TextView tvTempValue;
    private boolean hudActive = false;
    private long lastFrameTimeNanos = 0;
    private int frameCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvFpsValue = findViewById(R.id.tvFpsValue);
        tvTempValue = findViewById(R.id.tvTempValue);
        Button btnToggleOverlay = findViewById(R.id.btnToggleOverlay);

        btnToggleOverlay.setOnClickListener(v -> {
            hudActive = !hudActive;
            btnToggleOverlay.setText(hudActive ? "DEACTIVATE CYBER HUD OVERLAY" : "ACTIVATE CYBER HUD OVERLAY");
            Toast.makeText(this, hudActive ? "Cyber Sakura HUD Active" : "HUD Paused", Toast.LENGTH_SHORT).show();
        });

        startTelemetryLoop();
    }

    private void startTelemetryLoop() {
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (lastFrameTimeNanos == 0) {
                    lastFrameTimeNanos = frameTimeNanos;
                }
                frameCount++;
                long elapsedNanos = frameTimeNanos - lastFrameTimeNanos;
                if (elapsedNanos >= 1_000_000_000L) {
                    double fps = (frameCount * 1_000_000_000.0) / elapsedNanos;
                    tvFpsValue.setText(String.format(Locale.US, "FPS: %.1f", fps));
                    updateBatteryTemp();
                    frameCount = 0;
                    lastFrameTimeNanos = frameTimeNanos;
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }

    private void updateBatteryTemp() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (batteryIntent != null) {
            int tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 365);
            float tempCelsius = tempTenths / 10.0f;
            tvTempValue.setText(String.format(Locale.US, "Battery Temp: %.1f°C", tempCelsius));
        }
    }
}
