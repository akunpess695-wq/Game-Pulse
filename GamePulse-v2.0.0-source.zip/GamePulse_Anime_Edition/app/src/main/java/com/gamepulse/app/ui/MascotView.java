package com.gamepulse.app.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class MascotView extends View {
    public MascotView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
