package com.gamepulse.app.ui;

import android.graphics.Color;

public class AnimeTheme {
    public static final int SAKURA_PINK = Color.parseColor("#FF6B9D");
    public static final int NEON_CYAN = Color.parseColor("#00F0FF");
    public static final int CYBER_VIOLET = Color.parseColor("#1A1025");
}
