package com.gamepulse.app.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class TelemetryGraphView extends View {
    public TelemetryGraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
