# GamePulse v2.0.0 — Anime Cyber Sakura Edition

Kelanjutan dari rilis `GamePulse-v1.9.0-source.zip` dengan pembaruan visual **Anime Cyber Sakura**, komponen HUD transparan, serta pemantau FPS dan suhu baterai real-time.

## Unggah ke GitHub
1. Unduh `GamePulse-v2.0.0-source.zip`.
2. Buka repository `akunpess695-wq/Game-Pulse` di GitHub -> klik **Add file** -> **Upload files** -> seret file ZIP ini lalu klik **Commit changes**.
