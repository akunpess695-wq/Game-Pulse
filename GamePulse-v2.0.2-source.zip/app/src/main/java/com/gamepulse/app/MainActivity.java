package com.gamepulse.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Choreographer;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.gamepulse.app.ui.AnimeTheme;
import com.gamepulse.app.ui.MascotView;
import com.gamepulse.app.ui.TelemetryGaugeView;
import com.gamepulse.app.ui.TelemetryGraphView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "gamepulse_prefs";

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout contentContainer;
    private LinearLayout bottomNavBar;
    private int currentTab = 0;

    private float currentTempC = 35.0f;
    private int currentBatteryPct = 80;
    private long freeRamMb = 2048;
    private long totalRamMb = 6144;
    private int currentRefreshHz = 60;
    private float measuredFps = 60.0f;
    private final List<Float> fpsHistory = new ArrayList<>();
    private final List<Float> tempHistory = new ArrayList<>();

    private long lastFrameNanos = 0L;
    private int frameCounter = 0;

    private static class GameEntry {
        final String name;
        final String pkg;
        final String category;
        boolean installed;
        boolean favorite;

        GameEntry(String name, String pkg, String category, boolean installed, boolean favorite) {
            this.name = name;
            this.pkg = pkg;
            this.category = category;
            this.installed = installed;
            this.favorite = favorite;
        }
    }

    private final List<GameEntry> gameLibrary = new ArrayList<>();
    private String searchQuery = "";
    private String selectedCategory = "Semua";

    private MascotView activeMascot;
    private TextView mascotSpeechView;
    private TextView liveFpsValue;
    private TextView liveTempValue;
    private TextView liveRamValue;
    private TextView liveHzValue;
    private TelemetryGaugeView fpsGauge;
    private TelemetryGaugeView tempGauge;
    private TelemetryGaugeView ramGauge;
    private TelemetryGraphView perfGraph;

    private final Runnable telemetryTicker = new Runnable() {
        @Override
        public void run() {
            sampleRealTelemetry();
            refreshLiveViews();
            handler.postDelayed(this, 1500L);
        }
    };

    private final Choreographer.FrameCallback fpsCallback = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            if (lastFrameNanos == 0L) lastFrameNanos = frameTimeNanos;
            frameCounter++;
            long diff = frameTimeNanos - lastFrameNanos;
            if (diff >= 1_000_000_000L) {
                measuredFps = (float) ((frameCounter * 1_000_000_000.0) / diff);
                prefs.edit().putFloat("last_measured_fps", measuredFps).apply();
                frameCounter = 0;
                lastFrameNanos = frameTimeNanos;
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        getWindow().setStatusBarColor(AnimeTheme.BG);
        getWindow().setNavigationBarColor(AnimeTheme.SURFACE);

        initGameLibrary();
        sampleRealTelemetry();
        buildRootShell();
        switchTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshInstalledFlags();
        handler.post(telemetryTicker);
        Choreographer.getInstance().postFrameCallback(fpsCallback);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(telemetryTicker);
        Choreographer.getInstance().removeFrameCallback(fpsCallback);
    }

    private void initGameLibrary() {
        gameLibrary.clear();
        String favs = prefs.getString("favorite_pkgs", "jp.konami.pesam");
        gameLibrary.add(new GameEntry("eFootball", "jp.konami.pesam", "Sports", false, favs.contains("jp.konami.pesam")));
        gameLibrary.add(new GameEntry("Mobile Legends: Bang Bang", "com.mobile.legends", "MOBA", false, favs.contains("com.mobile.legends")));
        gameLibrary.add(new GameEntry("Genshin Impact", "com.miHoYo.GenshinImpact", "RPG", false, favs.contains("com.miHoYo.GenshinImpact")));
        gameLibrary.add(new GameEntry("PUBG Mobile", "com.tencent.ig", "Shooter", false, favs.contains("com.tencent.ig")));
        gameLibrary.add(new GameEntry("Honor of Kings", "com.levelinfinite.sgameGlobal", "MOBA", false, favs.contains("com.levelinfinite.sgameGlobal")));
        refreshInstalledFlags();
    }

    private void refreshInstalledFlags() {
        PackageManager pm = getPackageManager();
        for (GameEntry g : gameLibrary) {
            try {
                pm.getPackageInfo(g.pkg, 0);
                g.installed = true;
            } catch (Exception e) {
                g.installed = false;
            }
        }
    }

    private void sampleRealTelemetry() {
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            int tempTenths = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350);
            currentTempC = tempTenths / 10f;
            int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 80);
            int scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            currentBatteryPct = scale > 0 ? Math.round((level * 100f) / scale) : level;
        }

        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            freeRamMb = mi.availMem / (1024L * 1024L);
            totalRamMb = mi.totalMem / (1024L * 1024L);
        }

        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        if (wm != null) {
            Display d = wm.getDefaultDisplay();
            if (d != null) {
                currentRefreshHz = Math.round(d.getRefreshRate());
            }
        }

        if (fpsHistory.size() >= 36) fpsHistory.remove(0);
        fpsHistory.add(measuredFps);

        if (tempHistory.size() >= 36) tempHistory.remove(0);
        tempHistory.add(currentTempC);
    }

    private void buildRootShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(AnimeTheme.BG);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(20), dp(14), dp(20), dp(12));
        topBar.setBackgroundColor(AnimeTheme.BG);

        TextView emblem = new TextView(this);
        emblem.setText("GP");
        emblem.setTextColor(AnimeTheme.TEXT_PRIMARY);
        emblem.setTextSize(13f);
        emblem.setTypeface(Typeface.DEFAULT_BOLD);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(AnimeTheme.primaryButtonDrawable(this, 12));
        topBar.addView(emblem, new LinearLayout.LayoutParams(dp(36), dp(36)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, 0, 0);

        TextView appTitle = new TextView(this);
        appTitle.setText("GamePulse");
        appTitle.setTextColor(AnimeTheme.TEXT_PRIMARY);
        appTitle.setTextSize(17f);
        appTitle.setTypeface(Typeface.DEFAULT_BOLD);
        titleCol.addView(appTitle);

        TextView appSub = new TextView(this);
        appSub.setText("Cyber Sakura Edition");
        appSub.setTextColor(AnimeTheme.ACCENT);
        appSub.setTextSize(11f);
        titleCol.addView(appSub);

        topBar.addView(titleCol, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView statusBadge = new TextView(this);
        statusBadge.setText("● Live");
        statusBadge.setTextColor(AnimeTheme.ACCENT);
        statusBadge.setTextSize(11f);
        statusBadge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        statusBadge.setPadding(dp(12), dp(6), dp(12), dp(6));
        statusBadge.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 14));
        topBar.addView(statusBadge);

        root.addView(topBar);

        contentContainer = new FrameLayout(this);
        root.addView(contentContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomNavBar = new LinearLayout(this);
        bottomNavBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomNavBar.setBackgroundColor(AnimeTheme.SURFACE);
        bottomNavBar.setPadding(dp(8), dp(8), dp(8), dp(10));

        View divider = new View(this);
        divider.setBackgroundColor(AnimeTheme.STROKE);
        root.addView(divider, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
        root.addView(bottomNavBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void renderBottomNav() {
        bottomNavBar.removeAllViews();
        String[] labels = {"Home", "Games", "Tools", "History", "Settings"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            boolean active = (i == currentTab);

            TextView item = new TextView(this);
            item.setText(labels[i]);
            item.setGravity(Gravity.CENTER);
            item.setTextSize(12f);
            item.setTypeface(active ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            item.setTextColor(active ? AnimeTheme.TEXT_PRIMARY : AnimeTheme.TEXT_MUTED);
            item.setPadding(dp(4), dp(10), dp(4), dp(10));
            if (active) {
                item.setBackground(AnimeTheme.gradientCard(
                        this, AnimeTheme.PRIMARY_SOFT, AnimeTheme.SECONDARY_SOFT, AnimeTheme.PRIMARY, 14));
            }
            item.setOnClickListener(v -> switchTab(index));
            bottomNavBar.addView(item, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
    }

    private void switchTab(int index) {
        currentTab = index;
        renderBottomNav();
        contentContainer.removeAllViews();
        activeMascot = null;
        mascotSpeechView = null;
        fpsGauge = null;
        tempGauge = null;
        ramGauge = null;
        perfGraph = null;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(8), dp(16), dp(24));

        switch (index) {
            case 0: buildHomeScreen(body); break;
            case 1: buildGamesScreen(body); break;
            case 2: buildToolsScreen(body); break;
            case 3: buildHistoryScreen(body); break;
            case 4: buildSettingsScreen(body); break;
        }

        scroll.addView(body);
        contentContainer.addView(scroll);
        AnimeTheme.playEntranceFade(body, 0);
    }

    private void buildHomeScreen(LinearLayout body) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.setBackground(AnimeTheme.gradientCard(
                this, AnimeTheme.PRIMARY_SOFT, AnimeTheme.SECONDARY_SOFT, AnimeTheme.STROKE_NEON, 22));

        MascotView mascot = new MascotView(this);
        MascotView.Expression initialExpr = currentTempC >= 41.0f
                ? MascotView.Expression.CONCERNED
                : MascotView.Expression.HAPPY;
        mascot.setExpression(initialExpr);
        activeMascot = mascot;
        hero.addView(mascot, new LinearLayout.LayoutParams(dp(116), dp(128)));

        LinearLayout heroRight = new LinearLayout(this);
        heroRight.setOrientation(LinearLayout.VERTICAL);
        heroRight.setPadding(dp(14), 0, 0, 0);

        String playerName = prefs.getString("player_name", "Commander");
        TextView welcome = new TextView(this);
        welcome.setText("Halo, " + playerName);
        welcome.setTextColor(AnimeTheme.TEXT_PRIMARY);
        welcome.setTextSize(20f);
        welcome.setTypeface(Typeface.DEFAULT_BOLD);
        heroRight.addView(welcome);

        TextView speech = new TextView(this);
        speech.setText(initialExpr.defaultLine);
        speech.setTextColor(AnimeTheme.TEXT_SECONDARY);
        speech.setTextSize(12f);
        speech.setPadding(0, dp(4), 0, dp(12));
        mascotSpeechView = speech;
        heroRight.addView(speech);

        Button btnOptimize = new Button(this);
        btnOptimize.setText("Start Optimization");
        btnOptimize.setAllCaps(false);
        btnOptimize.setTextColor(AnimeTheme.TEXT_PRIMARY);
        btnOptimize.setTextSize(13f);
        btnOptimize.setTypeface(Typeface.DEFAULT_BOLD);
        btnOptimize.setBackground(AnimeTheme.primaryButtonDrawable(this, 14));
        btnOptimize.setPadding(dp(16), dp(10), dp(16), dp(10));
        AnimeTheme.attachPressFeedback(btnOptimize);
        btnOptimize.setOnClickListener(v -> runDeviceOptimization());
        heroRight.addView(btnOptimize, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        hero.addView(heroRight, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(hero);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.topMargin = dp(12);

        liveFpsValue = createMetricCard(row1, "Frame rate", Math.round(measuredFps) + " FPS", AnimeTheme.ACCENT, true);
        liveTempValue = createMetricCard(row1, "Suhu perangkat", String.format(Locale.US, "%.1f°C", currentTempC),
                currentTempC >= 41f ? AnimeTheme.STATUS_HOT : AnimeTheme.STATUS_GOOD, false);
        body.addView(row1, rowLp);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams row2Lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        row2Lp.topMargin = dp(10);

        long usedRamMb = Math.max(0, totalRamMb - freeRamMb);
        liveRamValue = createMetricCard(row2, "Penggunaan RAM", usedRamMb + " / " + totalRamMb + " MB", AnimeTheme.TEXT_PRIMARY, true);
        liveHzValue = createMetricCard(row2, "Refresh rate", currentRefreshHz + " Hz", AnimeTheme.SECONDARY, false);
        body.addView(row2, row2Lp);

        body.addView(sectionHeader("Game pilihan cepat"));
        for (GameEntry g : gameLibrary) {
            if (g.favorite || g.installed) {
                body.addView(buildGameCard(g));
                break;
            }
        }
    }

    private TextView createMetricCard(LinearLayout parent, String label, String value, int valueColor, boolean leftMarginRight) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 18));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(AnimeTheme.TEXT_SECONDARY);
        lbl.setTextSize(12f);
        card.addView(lbl);

        TextView val = new TextView(this);
        val.setText(value);
        val.setTextColor(valueColor);
        val.setTextSize(19f);
        val.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        val.setPadding(0, dp(6), 0, 0);
        card.addView(val);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (leftMarginRight) lp.rightMargin = dp(10);
        parent.addView(card, lp);
        return val;
    }

    private void buildGamesScreen(LinearLayout body) {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Game Library");
        title.setTextColor(AnimeTheme.TEXT_PRIMARY);
        title.setTextSize(20f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button btnAdd = new Button(this);
        btnAdd.setText("+ Add Game");
        btnAdd.setAllCaps(false);
        btnAdd.setTextColor(AnimeTheme.TEXT_PRIMARY);
        btnAdd.setTextSize(12f);
        btnAdd.setBackground(AnimeTheme.primaryButtonDrawable(this, 12));
        btnAdd.setPadding(dp(14), dp(8), dp(14), dp(8));
        AnimeTheme.attachPressFeedback(btnAdd);
        btnAdd.setOnClickListener(v -> showAddCustomGamePrompt());
        top.addView(btnAdd);
        body.addView(top);

        EditText searchInput = new EditText(this);
        searchInput.setHint("Cari game...");
        searchInput.setText(searchQuery);
        searchInput.setTextColor(AnimeTheme.TEXT_PRIMARY);
        searchInput.setHintTextColor(AnimeTheme.TEXT_MUTED);
        searchInput.setTextSize(13f);
        searchInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchInput.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 14));
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sLp.topMargin = dp(12);
        body.addView(searchInput, sLp);

        String[] categories = {"Semua", "Favorit", "MOBA", "Sports", "RPG", "Shooter"};
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cLp.topMargin = dp(10);

        for (String cat : categories) {
            boolean active = cat.equals(selectedCategory);
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(11f);
            chip.setTextColor(active ? AnimeTheme.TEXT_PRIMARY : AnimeTheme.TEXT_SECONDARY);
            chip.setPadding(dp(10), dp(6), dp(10), dp(6));
            chip.setBackground(AnimeTheme.cardDrawable(
                    this, active ? AnimeTheme.PRIMARY : AnimeTheme.SURFACE, AnimeTheme.STROKE, 10));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            itemLp.rightMargin = dp(6);
            chip.setOnClickListener(v -> {
                selectedCategory = cat;
                switchTab(1);
            });
            chipRow.addView(chip, itemLp);
        }
        body.addView(chipRow, cLp);

        LinearLayout listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lLp.topMargin = dp(12);
        body.addView(listContainer, lLp);

        Runnable renderList = () -> {
            listContainer.removeAllViews();
            for (GameEntry g : gameLibrary) {
                if (!searchQuery.isEmpty() && !g.name.toLowerCase(Locale.US).contains(searchQuery.toLowerCase(Locale.US))) continue;
                if ("Favorit".equals(selectedCategory) && !g.favorite) continue;
                if (!"Semua".equals(selectedCategory) && !"Favorit".equals(selectedCategory)
                        && !g.category.equalsIgnoreCase(selectedCategory)) continue;
                listContainer.addView(buildGameCard(g));
            }
        };
        renderList.run();

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString();
                renderList.run();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private LinearLayout buildGameCard(GameEntry game) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(AnimeTheme.cardDrawable(
                this,
                game.installed ? AnimeTheme.SURFACE_ELEVATED : AnimeTheme.SURFACE,
                game.favorite ? AnimeTheme.SECONDARY : AnimeTheme.STROKE,
                18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);

        TextView cover = new TextView(this);
        String initials = game.name.length() >= 2 ? game.name.substring(0, 2).toUpperCase(Locale.US) : "GP";
        cover.setText(initials);
        cover.setGravity(Gravity.CENTER);
        cover.setTextColor(AnimeTheme.TEXT_PRIMARY);
        cover.setTextSize(15f);
        cover.setTypeface(Typeface.DEFAULT_BOLD);
        cover.setBackground(AnimeTheme.gradientCard(this, AnimeTheme.PRIMARY, AnimeTheme.SECONDARY, 0, 14));
        card.addView(cover, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), 0, dp(8), 0);

        TextView nameTv = new TextView(this);
        nameTv.setText(game.name);
        nameTv.setTextColor(AnimeTheme.TEXT_PRIMARY);
        nameTv.setTextSize(15f);
        nameTv.setTypeface(Typeface.DEFAULT_BOLD);
        info.addView(nameTv);

        TextView metaTv = new TextView(this);
        metaTv.setText(game.category + " · " + (game.installed ? "Terpasang" : "Belum terpasang"));
        metaTv.setTextColor(game.installed ? AnimeTheme.ACCENT : AnimeTheme.TEXT_MUTED);
        metaTv.setTextSize(11f);
        info.addView(metaTv);

        card.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView favBtn = new TextView(this);
        favBtn.setText(game.favorite ? "★" : "☆");
        favBtn.setTextSize(18f);
        favBtn.setTextColor(game.favorite ? AnimeTheme.SECONDARY : AnimeTheme.TEXT_MUTED);
        favBtn.setPadding(dp(8), dp(6), dp(10), dp(6));
        favBtn.setOnClickListener(v -> {
            game.favorite = !game.favorite;
            saveFavorites();
            switchTab(currentTab);
        });
        card.addView(favBtn);

        Button launchBtn = new Button(this);
        launchBtn.setText(game.installed ? "Play" : "Install");
        launchBtn.setAllCaps(false);
        launchBtn.setTextSize(12f);
        launchBtn.setTypeface(Typeface.DEFAULT_BOLD);
        launchBtn.setTextColor(AnimeTheme.TEXT_PRIMARY);
        launchBtn.setBackground(game.installed
                ? AnimeTheme.primaryButtonDrawable(this, 12)
                : AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 12));
        launchBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        AnimeTheme.attachPressFeedback(launchBtn);
        launchBtn.setOnClickListener(v -> launchGameWithTelemetry(game));
        card.addView(launchBtn);

        return card;
    }

    private void saveFavorites() {
        StringBuilder sb = new StringBuilder();
        for (GameEntry g : gameLibrary) {
            if (g.favorite) sb.append(g.pkg).append(",");
        }
        prefs.edit().putString("favorite_pkgs", sb.toString()).apply();
    }

    private void showAddCustomGamePrompt() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0 && !app.packageName.equals(getPackageName())) {
                boolean exists = false;
                for (GameEntry g : gameLibrary) {
                    if (g.pkg.equals(app.packageName)) { exists = true; break; }
                }
                if (!exists) {
                    String label = pm.getApplicationLabel(app).toString();
                    gameLibrary.add(new GameEntry(label, app.packageName, "Custom", true, true));
                    saveFavorites();
                    Toast.makeText(this, "Ditambahkan: " + label, Toast.LENGTH_SHORT).show();
                    switchTab(1);
                    return;
                }
            }
        }
        Toast.makeText(this, "Semua aplikasi pengguna sudah terdaftar", Toast.LENGTH_SHORT).show();
    }

    private void launchGameWithTelemetry(GameEntry game) {
        if (activeMascot != null) {
            activeMascot.setExpression(MascotView.Expression.EXCITED);
        }
        recordSessionSnapshot(game.name);
        Intent launch = getPackageManager().getLaunchIntentForPackage(game.pkg);
        if (launch != null) {
            startActivity(launch);
        } else {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + game.pkg)));
        }
    }

    private void buildToolsScreen(LinearLayout body) {
        LinearLayout monitorCard = new LinearLayout(this);
        monitorCard.setOrientation(LinearLayout.VERTICAL);
        monitorCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        monitorCard.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 20));

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        MascotView mascot = new MascotView(this);
        mascot.setExpression(MascotView.Expression.FOCUSED);
        activeMascot = mascot;
        headerRow.addView(mascot, new LinearLayout.LayoutParams(dp(72), dp(76)));

        LinearLayout hInfo = new LinearLayout(this);
        hInfo.setOrientation(LinearLayout.VERTICAL);
        hInfo.setPadding(dp(12), 0, 0, 0);

        TextView mTitle = new TextView(this);
        mTitle.setText("Performance Monitor");
        mTitle.setTextColor(AnimeTheme.TEXT_PRIMARY);
        mTitle.setTextSize(18f);
        mTitle.setTypeface(Typeface.DEFAULT_BOLD);
        hInfo.addView(mTitle);

        float frameTimeMs = measuredFps > 0 ? (1000f / measuredFps) : 16.6f;
        TextView mSub = new TextView(this);
        mSub.setText(String.format(Locale.US, "Frame-time %.1f ms · Baterai %d%% · %d Hz",
                frameTimeMs, currentBatteryPct, currentRefreshHz));
        mSub.setTextColor(AnimeTheme.TEXT_SECONDARY);
        mSub.setTextSize(12f);
        mascotSpeechView = mSub;
        hInfo.addView(mSub);

        headerRow.addView(hInfo, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        monitorCard.addView(headerRow);

        LinearLayout gaugeRow = new LinearLayout(this);
        gaugeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams gLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(104));
        gLp.topMargin = dp(14);

        fpsGauge = new TelemetryGaugeView(this);
        tempGauge = new TelemetryGaugeView(this);
        ramGauge = new TelemetryGaugeView(this);

        gaugeRow.addView(fpsGauge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        gaugeRow.addView(tempGauge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        gaugeRow.addView(ramGauge, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        monitorCard.addView(gaugeRow, gLp);

        perfGraph = new TelemetryGraphView(this);
        perfGraph.setRange(0f, 120f, AnimeTheme.ACCENT);
        perfGraph.setSamples(fpsHistory);
        LinearLayout.LayoutParams graphLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(88));
        graphLp.topMargin = dp(12);
        monitorCard.addView(perfGraph, graphLp);

        body.addView(monitorCard);

        body.addView(sectionHeader("Game Optimization Center"));

        LinearLayout optCard = new LinearLayout(this);
        optCard.setOrientation(LinearLayout.VERTICAL);
        optCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        optCard.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 20));

        addOptimizationToggle(optCard, "Perlindungan Thermal Otomatis", "opt_thermal", true);
        addOptimizationToggle(optCard, "Kunci Refresh Rate Tinggi (" + currentRefreshHz + " Hz)", "opt_hz", true);
        addOptimizationToggle(optCard, "Prioritas Memori & Background Trim", "opt_ram", true);
        addOptimizationToggle(optCard, "Kapsul HUD FPS Melayang", "overlay_enabled", false);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bLp.topMargin = dp(14);

        Button btnRunOpt = new Button(this);
        btnRunOpt.setText("Optimalkan Sekarang");
        btnRunOpt.setAllCaps(false);
        btnRunOpt.setTextColor(AnimeTheme.TEXT_PRIMARY);
        btnRunOpt.setTypeface(Typeface.DEFAULT_BOLD);
        btnRunOpt.setBackground(AnimeTheme.primaryButtonDrawable(this, 14));
        AnimeTheme.attachPressFeedback(btnRunOpt);
        btnRunOpt.setOnClickListener(v -> runDeviceOptimization());

        Button btnRestore = new Button(this);
        btnRestore.setText("Restore Default");
        btnRestore.setAllCaps(false);
        btnRestore.setTextColor(AnimeTheme.TEXT_SECONDARY);
        btnRestore.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE_ELEVATED, AnimeTheme.STROKE, 14));
        AnimeTheme.attachPressFeedback(btnRestore);
        btnRestore.setOnClickListener(v -> restoreDefaultSettings());

        LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f);
        optLp.rightMargin = dp(8);
        btnRow.addView(btnRunOpt, optLp);
        btnRow.addView(btnRestore, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        optCard.addView(btnRow, bLp);
        body.addView(optCard);

        refreshLiveViews();
    }

    private void addOptimizationToggle(LinearLayout parent, String title, final String prefKey, boolean defVal) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(AnimeTheme.TEXT_PRIMARY);
        tv.setTextSize(13f);
        row.addView(tv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch sw = new Switch(this);
        sw.setChecked(prefs.getBoolean(prefKey, defVal));
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(prefKey, isChecked).apply();
            if ("overlay_enabled".equals(prefKey)) {
                if (isChecked) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } else {
                        startService(new Intent(this, OverlayService.class));
                    }
                } else {
                    stopService(new Intent(this, OverlayService.class));
                }
            }
        });
        row.addView(sw);
        parent.addView(row);
    }

    private void runDeviceOptimization() {
        System.gc();
        sampleRealTelemetry();
        refreshLiveViews();
        if (activeMascot != null) activeMascot.setExpression(MascotView.Expression.HAPPY);
        if (mascotSpeechView != null) {
            mascotSpeechView.setText("Optimasi selesai! RAM tersedia " + freeRamMb + " MB.");
        }
        Toast.makeText(this, "Optimasi selesai · RAM bebas " + freeRamMb + " MB", Toast.LENGTH_SHORT).show();
    }

    private void restoreDefaultSettings() {
        prefs.edit()
                .putBoolean("opt_thermal", true)
                .putBoolean("opt_hz", false)
                .putBoolean("opt_ram", false)
                .putBoolean("overlay_enabled", false)
                .apply();
        stopService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "Pengaturan dikembalikan ke bawaan", Toast.LENGTH_SHORT).show();
        switchTab(currentTab);
    }

    private void buildHistoryScreen(LinearLayout body) {
        LinearLayout headerCard = new LinearLayout(this);
        headerCard.setOrientation(LinearLayout.HORIZONTAL);
        headerCard.setGravity(Gravity.CENTER_VERTICAL);
        headerCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        headerCard.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 20));

        MascotView mascot = new MascotView(this);
        mascot.setExpression(MascotView.Expression.CELEBRATING);
        activeMascot = mascot;
        headerCard.addView(mascot, new LinearLayout.LayoutParams(dp(72), dp(76)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), 0, 0, 0);

        TextView title = new TextView(this);
        title.setText("Gaming Session History");
        title.setTextColor(AnimeTheme.TEXT_PRIMARY);
        title.setTextSize(18f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);

        TextView sub = new TextView(this);
        sub.setText(MascotView.Expression.CELEBRATING.defaultLine);
        sub.setTextColor(AnimeTheme.TEXT_SECONDARY);
        sub.setTextSize(12f);
        col.addView(sub);

        headerCard.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(headerCard);

        body.addView(sectionHeader("Riwayat suhu sesi (°C)"));
        TelemetryGraphView tempGraph = new TelemetryGraphView(this);
        tempGraph.setRange(25f, 50f, AnimeTheme.SECONDARY);
        tempGraph.setSamples(tempHistory);
        tempGraph.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 16));
        tempGraph.setPadding(dp(12), dp(12), dp(12), dp(12));
        body.addView(tempGraph, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(100)));

        body.addView(sectionHeader("Catatan sesi terakhir"));
        String raw = prefs.getString("session_history_json", "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            if (arr.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("Belum ada sesi tercatat. Jalankan game dari tab Games untuk mulai merekam telemetri.");
                empty.setTextColor(AnimeTheme.TEXT_SECONDARY);
                empty.setTextSize(13f);
                empty.setPadding(dp(16), dp(16), dp(16), dp(16));
                empty.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 16));
                body.addView(empty);
            } else {
                for (int i = arr.length() - 1; i >= 0; i--) {
                    body.addView(buildSessionItemCard(arr.getJSONObject(i)));
                }
            }
        } catch (Exception ignored) {}
    }

    private LinearLayout buildSessionItemCard(JSONObject s) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);

        TextView gameTitle = new TextView(this);
        gameTitle.setText(s.optString("game", "Game Session") + " · " + s.optString("date", ""));
        gameTitle.setTextColor(AnimeTheme.TEXT_PRIMARY);
        gameTitle.setTextSize(14f);
        gameTitle.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(gameTitle);

        TextView stats = new TextView(this);
        stats.setText(String.format(Locale.US,
                "Durasi %s · Avg %.0f FPS · Max %.0f FPS · Suhu %.1f°C · Baterai -%d%%",
                s.optString("duration", "15m"),
                s.optDouble("avgFps", 60.0),
                s.optDouble("maxFps", 60.0),
                s.optDouble("temp", 36.0),
                s.optInt("batDrop", 3)));
        stats.setTextColor(AnimeTheme.ACCENT);
        stats.setTextSize(12f);
        stats.setTypeface(Typeface.MONOSPACE);
        stats.setPadding(0, dp(6), 0, 0);
        card.addView(stats);

        return card;
    }

    private void recordSessionSnapshot(String gameName) {
        try {
            JSONArray arr = new JSONArray(prefs.getString("session_history_json", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("game", gameName);
            obj.put("date", new SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(new Date()));
            obj.put("duration", "Sesi aktif");
            obj.put("avgFps", measuredFps);
            obj.put("maxFps", currentRefreshHz);
            obj.put("temp", currentTempC);
            obj.put("batDrop", 2);
            arr.put(obj);
            prefs.edit().putString("session_history_json", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void buildSettingsScreen(LinearLayout body) {
        LinearLayout profileCard = new LinearLayout(this);
        profileCard.setOrientation(LinearLayout.HORIZONTAL);
        profileCard.setGravity(Gravity.CENTER_VERTICAL);
        profileCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        profileCard.setBackground(AnimeTheme.gradientCard(
                this, AnimeTheme.PRIMARY_SOFT, AnimeTheme.SURFACE_ELEVATED, AnimeTheme.STROKE_NEON, 20));

        MascotView avatar = new MascotView(this);
        avatar.setExpression(MascotView.Expression.SLEEPY);
        profileCard.addView(avatar, new LinearLayout.LayoutParams(dp(68), dp(72)));

        LinearLayout pCol = new LinearLayout(this);
        pCol.setOrientation(LinearLayout.VERTICAL);
        pCol.setPadding(dp(12), 0, 0, 0);

        TextView pName = new TextView(this);
        pName.setText(prefs.getString("player_name", "Commander"));
        pName.setTextColor(AnimeTheme.TEXT_PRIMARY);
        pName.setTextSize(17f);
        pName.setTypeface(Typeface.DEFAULT_BOLD);
        pCol.addView(pName);

        TextView pSub = new TextView(this);
        pSub.setText("Maskot: Sora · Tema: Anime Cyber Sakura");
        pSub.setTextColor(AnimeTheme.SECONDARY);
        pSub.setTextSize(12f);
        pCol.addView(pSub);

        profileCard.addView(pCol, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        body.addView(profileCard);

        body.addView(sectionHeader("Integrasi Shizuku & Sistem"));
        LinearLayout shizukuCard = new LinearLayout(this);
        shizukuCard.setOrientation(LinearLayout.VERTICAL);
        shizukuCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        shizukuCard.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 18));

        boolean shizukuInstalled = isPackageInstalled("moe.shizuku.privileged.api");
        TextView shStatus = new TextView(this);
        shStatus.setText("Status Shizuku: " + (shizukuInstalled ? "Terpasang & Siap" : "Belum Terpasang"));
        shStatus.setTextColor(shizukuInstalled ? AnimeTheme.STATUS_GOOD : AnimeTheme.STATUS_WARN);
        shStatus.setTextSize(14f);
        shStatus.setTypeface(Typeface.DEFAULT_BOLD);
        shizukuCard.addView(shStatus);

        TextView shDesc = new TextView(this);
        shDesc.setText("Memungkinkan pemantauan frame-time tingkat lanjut dan kontrol refresh rate tanpa akses root.");
        shDesc.setTextColor(AnimeTheme.TEXT_SECONDARY);
        shDesc.setTextSize(12f);
        shDesc.setPadding(0, dp(4), 0, dp(10));
        shizukuCard.addView(shDesc);

        Button btnShizuku = new Button(this);
        btnShizuku.setText(shizukuInstalled ? "Buka Shizuku" : "Pasang Shizuku");
        btnShizuku.setAllCaps(false);
        btnShizuku.setTextColor(AnimeTheme.TEXT_PRIMARY);
        btnShizuku.setBackground(AnimeTheme.primaryButtonDrawable(this, 12));
        btnShizuku.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) {
                startActivity(i);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")));
            }
        });
        shizukuCard.addView(btnShizuku);
        body.addView(shizukuCard);

        body.addView(sectionHeader("Privasi & Tentang GamePulse"));
        LinearLayout aboutCard = new LinearLayout(this);
        aboutCard.setOrientation(LinearLayout.VERTICAL);
        aboutCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        aboutCard.setBackground(AnimeTheme.cardDrawable(this, AnimeTheme.SURFACE, AnimeTheme.STROKE, 18));

        TextView aboutTv = new TextView(this);
        aboutTv.setText("GamePulse v2.0.2 — Anime Cyber Sakura Edition
" +
                "• Telemetri perangkat diproses 100% secara lokal tanpa pelacakan eksternal.
" +
                "• Mendukung Android 10 hingga Android 15+.");
        aboutTv.setTextColor(AnimeTheme.TEXT_SECONDARY);
        aboutTv.setTextSize(12f);
        aboutCard.addView(aboutTv);
        body.addView(aboutCard);
    }

    private void refreshLiveViews() {
        if (liveFpsValue != null) liveFpsValue.setText(Math.round(measuredFps) + " FPS");
        if (liveTempValue != null) {
            liveTempValue.setText(String.format(Locale.US, "%.1f°C", currentTempC));
            liveTempValue.setTextColor(currentTempC >= 41f ? AnimeTheme.STATUS_HOT : AnimeTheme.STATUS_GOOD);
        }
        if (liveRamValue != null) {
            long usedRamMb = Math.max(0, totalRamMb - freeRamMb);
            liveRamValue.setText(usedRamMb + " / " + totalRamMb + " MB");
        }
        if (liveHzValue != null) liveHzValue.setText(currentRefreshHz + " Hz");
        if (fpsGauge != null) {
            fpsGauge.setMetric(measuredFps / Math.max(60f, currentRefreshHz),
                    String.valueOf(Math.round(measuredFps)), "FPS", AnimeTheme.ACCENT);
        }
        if (tempGauge != null) {
            tempGauge.setMetric((currentTempC - 20f) / 35f,
                    String.format(Locale.US, "%.1f°", currentTempC), "TEMP",
                    currentTempC >= 41f ? AnimeTheme.STATUS_HOT : AnimeTheme.STATUS_GOOD);
        }
        if (ramGauge != null && totalRamMb > 0) {
            float usedRatio = (float) (totalRamMb - freeRamMb) / totalRamMb;
            ramGauge.setMetric(usedRatio, Math.round(usedRatio * 100f) + "%", "RAM", AnimeTheme.PRIMARY);
        }
        if (perfGraph != null) perfGraph.setSamples(fpsHistory);
    }

    private TextView sectionHeader(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(AnimeTheme.TEXT_PRIMARY);
        tv.setTextSize(15f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(18);
        lp.bottomMargin = dp(8);
        tv.setLayoutParams(lp);
        return tv;
    }

    private boolean isPackageInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private int dp(float v) {
        return AnimeTheme.dp(this, v);
    }
}
